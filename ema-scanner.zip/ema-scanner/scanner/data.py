"""Where candles come from: TradingView first, Yahoo Finance as backup (config: data_source).

The engine only ever calls   fetcher(symbols, interval) -> ({symbol: DataFrame}, [symbols without data])
so the two sources are interchangeable.
"""
from __future__ import annotations

import logging
import time

import pandas as pd

from . import fyers as fyers_mod
from .tv import TradingViewFeed
from .universe import CACHE_DIR

log = logging.getLogger("scanner")


def _split(raw, batch):
    """Cut a multi-ticker download into {symbol: DataFrame}; copes with both column layouts."""
    out = {}
    if raw is None or len(raw) == 0:
        return out
    cols = raw.columns
    if isinstance(cols, pd.MultiIndex):
        l0, l1 = set(cols.get_level_values(0)), set(cols.get_level_values(1))
        for t in batch:
            if t in l0:
                out[t] = raw[t]
            elif t in l1:
                out[t] = raw.xs(t, axis=1, level=1)
    elif len(batch) == 1:
        out[batch[0]] = raw
    return {t: d for t, d in out.items() if d is not None and len(d.dropna(how="all")) > 0}


class _Catch(logging.Handler):
    """Collects yfinance's own log lines so we can notice 'Too Many Requests'."""

    def __init__(self):
        super().__init__(level=logging.WARNING)
        self.lines: list[str] = []

    def emit(self, record):
        try:
            self.lines.append(record.getMessage())
        except Exception:                                       # noqa: BLE001
            pass


def _is_throttle(text: str) -> bool:
    t = text.lower()
    return "too many" in t or "rate limit" in t or "ratelimit" in t


def _download(yf, batch, interval, period, ycfg, sleep):
    """One batch. Returns {symbol: df}, or None if Yahoo keeps throttling us."""
    for _ in range(2):
        catcher = _Catch()
        ylog = logging.getLogger("yfinance")
        ylog.addHandler(catcher)
        raw, problem = None, ""
        try:
            raw = yf.download(
                tickers=batch, period=period, interval=interval, group_by="ticker",
                auto_adjust=False, prepost=False, progress=False, timeout=30,
                threads=int(ycfg["threads"]) if len(batch) > 1 else False,
            )
        except Exception as e:                                  # noqa: BLE001
            problem = str(e)
            log.warning("Yahoo error (%s): %s", interval, problem[:200])
        finally:
            ylog.removeHandler(catcher)
        if _is_throttle(" ".join(catcher.lines) + " " + problem):
            log.warning("Yahoo is rate-limiting us - pausing 45 seconds")
            sleep(45)
            continue
        return _split(raw, batch)
    return None


def fetch_yahoo(symbols, interval, ycfg, sleep=None):
    """Returns ({symbol: DataFrame}, [symbols that failed])."""
    import yfinance as yf

    sleep = sleep or (lambda s: time.sleep(s))
    period = ycfg["periods"][interval]
    size = max(1, int(ycfg["batch_size"]))
    deadline = time.time() + float(ycfg["max_seconds"])
    todo = list(dict.fromkeys(symbols))
    out, stop = {}, False
    for attempt in range(int(ycfg["retries"]) + 1):
        if not todo or stop:
            break
        remaining = []
        for i in range(0, len(todo), size):
            batch = todo[i:i + size]
            if stop or time.time() > deadline:
                remaining.extend(batch)
                continue
            got = _download(yf, batch, interval, period, ycfg, sleep)
            if got is None:
                stop = True
                remaining.extend(batch)
                continue
            for t in batch:
                if t in got:
                    out[t] = got[t]
                else:
                    remaining.append(t)
            sleep(float(ycfg["pause_seconds"]))
        todo = remaining
        if todo and attempt < int(ycfg["retries"]) and not stop:
            sleep(5 * (attempt + 1))
    return out, todo


class Fetcher:
    """Where candles come from, per symbol:
         Indian symbols with a Fyers code -> Fyers (real time), then TradingView if Fyers cannot deliver them;
         everything else                  -> TradingView, then Yahoo for gaps (data_source: auto).
    The engine only ever calls   fetcher(symbols, interval) -> ({symbol: DataFrame}, [symbols without data])
    and may ask   fetcher.source_of(symbol, interval)   which feed really delivered a candle set (it needs to know,
    because a delayed feed must be given more time to finish its latest candle)."""

    def __init__(self, cfg, instruments=(), tv=None, yahoo=None, clock=None, fyers=None):
        self.cfg = cfg
        self.mode = cfg["data_source"]
        self.clock = clock or time.monotonic
        self.t0 = self.clock()
        self.invalid = set()               # symbols TradingView does not know (result of the latest call)
        self.invalid_all = set()           # ... over the whole run
        self.why = {}                      # {symbol: plain-English reason} for the symbols the latest call could not serve
        self.served = {"tradingview": 0, "yahoo": 0}
        self.events = []                   # plain-English notes for the health alert
        self._yahoo = yahoo
        self._noted = set()
        self.tv = None
        self.fy = fyers
        self.long_daily = False            # the engine sets this when weekly candles are wanted (they need 2 years of days)
        self._src = {}
        self._fmap = {}
        self._fmarkets = set()
        if fyers is not None:
            self.served["fyers"] = 0
            self._fmap = {i.symbol: i.fyers for i in instruments if getattr(i, "fyers", "")}
            self._fmarkets = {i.market for i in instruments if i.symbol in self._fmap}
        if self.mode != "yahoo":
            tvmap = {i.symbol: list(i.feed) for i in instruments if getattr(i, "feed", None)}
            self.tv = tv or TradingViewFeed(cfg["tradingview"], tvmap, cache_path=CACHE_DIR / "tv_symbols.json")

    def _note(self, key, text):
        if key not in self._noted:
            self._noted.add(key)
            self.events.append(text)
            log.warning(text)

    # -- which feed serves what
    def primary_source(self, market, interval):
        if self.fy is not None and market in self._fmarkets and self.fy.covers(interval):
            return "fyers"
        return "yahoo" if self.mode == "yahoo" else "tradingview"

    def source_of(self, symbol, interval):
        return self._src.get((symbol, interval)) or ("yahoo" if self.mode == "yahoo" else "tradingview")

    def attach_state(self, state):
        if self.fy is not None:
            self.fy.attach_state(state)

    def save_state(self, state):
        if self.fy is not None:
            self.fy.save_state(state)

    def _yahoo_fetch(self, symbols, interval):
        if self._yahoo:
            return self._yahoo(symbols, interval)
        y = dict(self.cfg["yahoo"])
        left = float(self.cfg["run_budget_seconds"]) - (self.clock() - self.t0)
        y["max_seconds"] = max(30.0, min(float(y["max_seconds"]), left))
        return fetch_yahoo(symbols, interval, y)

    def _from_fyers(self, symbols, interval):
        want = {s: self._fmap[s] for s in symbols if s in self._fmap}
        if not want or not self.fy.covers(interval):
            return {}
        got, _ = self.fy.fetch(want, interval, self.long_daily)
        for s in got:
            self._src[(s, interval)] = "fyers"
        self.served["fyers"] += len(got)
        for e in self.fy.events:
            self._note("fy:" + e[:60], e)
        self.fy.events.clear()
        if self.fy.down:
            self._note("fy-down", f"Fyers is not usable ({self.fy.down}) - Indian prices come from TradingView, "
                                  f"about 15 minutes late.")
        return got

    def __call__(self, symbols, interval):
        symbols = list(dict.fromkeys(symbols))
        out = {}
        self.invalid = set()
        self.why = {}
        if self.fy is not None:
            out.update(self._from_fyers(symbols, interval))
        failed = [s for s in symbols if s not in out]
        for s in failed:
            if self.fy is not None and s in self._fmap:
                self.why[s] = "Fyers: " + str(self.fy.reasons.get(s) or "no candles")[:70]
        if self.tv is not None and failed:
            got, failed = self.tv.fetch(failed, interval)
            out.update(got)
            for s in got:
                self._src[(s, interval)] = "tradingview"
            self.served["tradingview"] += len(got)
            if self.tv.down:
                tail = "using the Yahoo backup" if self.mode == "auto" else "no data this run"
                self._note("down", f"TradingView feed not reachable ({self.tv.down}) - {tail}.")
        if self.mode in ("auto", "yahoo") and failed:
            ysyms = [s for s in failed if ":" not in s]          # TradingView-style names cannot be asked of Yahoo
            if ysyms:
                got, _ = self._yahoo_fetch(ysyms, interval)
                out.update(got)
                for s in got:
                    self._src[(s, interval)] = "yahoo"
                self.served["yahoo"] += len(got)
                failed = [s for s in failed if s not in out]
        if self.tv is not None:
            self.invalid = self.tv.invalid & set(failed)
            self.invalid_all |= self.invalid
        for s in failed:
            if self.tv is None:
                tail = "Yahoo had no candles"
            else:
                tail = "TradingView does not know the code" if s in self.invalid else "TradingView had no candles"
            self.why[s] = f"{self.why[s]}; {tail}" if s in self.why else tail
        return out, failed


def make_fetcher(cfg, instruments=None, purpose="scan"):
    """purpose: scan | doctor (real-time Fyers) · report (Fyers only on the paid plan) · backtest (never Fyers)."""
    insts = instruments or ()
    fy = None
    try:
        fy = fyers_mod.setup(cfg, list(insts), purpose)
    except Exception as e:                                      # noqa: BLE001
        log.warning("Fyers could not be set up (%s) - using TradingView.", str(e)[:120])
    f = Fetcher(cfg, insts, fyers=fy)
    rep = getattr(fy, "report", None) or {}
    if rep.get("missing"):
        # commodities have no other source of prices, so each one that is missing matters; for shares and indices a few
        # names TradingView serves instead are normal, so only a large share of them is worth an alert
        no_mcx = [i.name for i in insts if i.market == "MCX" and not i.fyers and not getattr(i, "optional", False)]
        no_nse = [i.name for i in insts if i.market == "NSE" and not i.fyers]
        n_nse = sum(1 for i in insts if i.market == "NSE")
        if no_mcx:
            f._note("fy-missing-mcx", f"Fyers has no code for {len(no_mcx)} commodit{'y' if len(no_mcx) == 1 else 'ies'}: "
                                      f"{', '.join(no_mcx[:8])}{' …' if len(no_mcx) > 8 else ''}. Nothing else has MCX prices, "
                                      f"so they are skipped until the code is found.")
        if no_nse and len(no_nse) > 0.05 * max(1, n_nse):
            f._note("fy-missing", f"Fyers has no code for {len(no_nse)} of {n_nse} shares and indices: {', '.join(no_nse[:8])}"
                                  f"{' …' if len(no_nse) > 8 else ''}. They use TradingView instead (about 15 minutes late).")
    if rep.get("guessed"):
        f._note("fy-guessed", "Fyers' list of commodity contracts could not be read, so the contract codes for "
                              f"{', '.join(rep['guessed'][:6])}{' …' if len(rep['guessed']) > 6 else ''} are worked out from the "
                              "month; the scanner keeps the first one that has recent candles.")
    for note in rep.get("notes", []):
        if "download failed" in note:
            f._note("fy-list:" + note[:12], f"Fyers symbol list - {note}")
    if fy is None and fyers_mod.configured() and purpose in ("scan", "doctor") and (cfg.get("fyers") or {}).get("enabled") is not False:
        f._note("fy-setup", "Fyers could not be set up - Indian prices come from TradingView, about 15 minutes late.")
    return f
