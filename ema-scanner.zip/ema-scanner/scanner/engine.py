"""Core loop: decide what is due, fetch data, evaluate crossovers."""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field

import pandas as pd

from . import bars, signals
from .markets import BASE_INTERVAL, MARKETS, TF_SECONDS, expected_latest_end, settle_for

log = logging.getLogger("scanner")


@dataclass
class Result:
    inst: object
    tf: str
    summary: dict | None
    reason: str = ""


@dataclass
class Signal:
    inst: object
    tf: str
    direction: str                 # "bull" | "bear"
    bar_end: pd.Timestamp
    close: float
    ema_s: float
    ema_l: float

    @property
    def key(self) -> str:
        return f"{self.inst.symbol}|{self.tf}|{int(self.bar_end.timestamp())}|{self.direction}"


@dataclass
class Collected:
    results: list = field(default_factory=list)
    stats: dict = field(default_factory=dict)   # (market, interval) -> {"requested": n, "failed": [symbols]}
    invalid: set = field(default_factory=set)   # symbols the data feed does not recognise
    served: dict = field(default_factory=dict)  # {"tradingview": n, "yahoo": n} candle sets delivered


@dataclass
class ScanOutcome:
    signals: list
    collected: Collected
    checkpoints: dict
    health: list
    skipped: list
    wanted: dict
    expected: dict = field(default_factory=dict)    # {market: {timeframe: end time of the candle just processed}}


@dataclass
class Coverage:
    """How many symbols of one group were checked against one closed candle."""
    market: str
    universe: str
    label: str
    bar_end: pd.Timestamp
    total: int
    got: int                 # checked up to this candle
    late: int = 0            # checked, but only up to an older candle (a delayed feed was used)


@dataclass
class TfBatch:
    """Everything one Telegram message per timeframe is made from."""
    tf: str
    signals: list
    coverage: list
    keys: list = field(default_factory=list)        # checkpoint keys ("NSE|15m") that move on once the message is delivered
    gap_from: object = None                         # when the scanner last ran, if it was away longer than the alert-age limit


def market_tfs(cfg, instruments, market) -> list:
    return [tf for tf in cfg["timeframes"]
            if any(tf in i.tfs for i in instruments if i.market == market)]


def evaluate(raw_df, market_key, tf, cfg, now, source=None, scan_last=None):
    """`source` = the feed that delivered the candles (a delayed feed needs a longer settle time);
    `scan_last` = how many of the newest closed candles to look at for crossovers."""
    m = MARKETS[market_key]
    frame = bars.frame_for(tf, raw_df, m)
    if frame.empty:
        return None, "no usable candles"
    closed = bars.closed_only(frame, now, settle_for(cfg, market_key, tf, source))
    if len(closed) < cfg["min_bars"]:
        return None, f"only {len(closed)} closed candles (need {cfg['min_bars']})"
    return signals.analyse(closed, cfg["ema"]["short"], cfg["ema"]["long"], scan_last or cfg["scan_last_bars"][tf]), ""


def _ask(fetcher, name, *args):
    f = getattr(fetcher, name, None)
    return f(*args) if callable(f) else None


def collect(cfg, instruments, wanted, now, fetcher, windows=None) -> Collected:
    """wanted = {market: [timeframes]}. Downloads each needed interval once per market.
    windows = {(market, timeframe): number of newest candles to inspect} (longer after a late run)."""
    windows = windows or {}
    out = Collected()
    for market, tfs in wanted.items():
        insts = [i for i in instruments if i.market == market]
        raw = {}
        for itv in sorted({BASE_INTERVAL[tf] for tf in tfs}):
            syms = [i.symbol for i in insts
                    if any(BASE_INTERVAL[tf] == itv and tf in i.tfs for tf in tfs)]
            if not syms:
                continue
            if hasattr(fetcher, "long_daily"):
                fetcher.long_daily = "1w" in tfs               # weekly candles need two years of daily candles
            data, failed = fetcher(syms, itv)
            raw[itv] = data
            # symbols the feed says do not exist, and 'optional' ones, never count against data coverage
            bad = set(getattr(fetcher, "invalid", None) or ())
            out.invalid |= bad
            skip = bad | {i.symbol for i in insts if getattr(i, "optional", False)}
            required = [s for s in syms if s not in skip]
            out.stats[(market, itv)] = {"requested": len(required), "failed": [s for s in failed if s not in skip]}
            log.info("%s %s: %d/%d symbols downloaded", market, itv, len(syms) - len(failed), len(syms))
        for tf in tfs:
            itv = BASE_INTERVAL[tf]
            for i in insts:
                if tf not in i.tfs:
                    continue
                df = raw.get(itv, {}).get(i.symbol)
                if df is None:
                    out.results.append(Result(i, tf, None, "no data from the data feed"))
                    continue
                try:
                    summary, why = evaluate(df, market, tf, cfg, now, _ask(fetcher, "source_of", i.symbol, itv),
                                            windows.get((market, tf)))
                except Exception as e:                          # noqa: BLE001
                    summary, why = None, f"error: {str(e)[:80]}"
                out.results.append(Result(i, tf, summary, why))
    out.served = dict(getattr(fetcher, "served", None) or {})
    return out


def probe_ready(cfg, market, due, now, fetcher) -> dict:
    """Is the newest expected bar actually available? (Handles holidays and feed delays with 1 request.)"""
    m = MARKETS[market]
    ready, cache = {}, {}
    for tf, expected in due.items():
        itv = BASE_INTERVAL[tf]
        if itv not in cache:
            data, _ = fetcher([m.benchmark], itv)
            cache[itv] = (data.get(m.benchmark), _ask(fetcher, "source_of", m.benchmark, itv))
        df, src = cache[itv]
        if df is None:
            ready[tf] = True                    # cannot probe -> go ahead, coverage check protects us
            continue
        closed = bars.closed_only(bars.frame_for(tf, df, m), now, settle_for(cfg, market, tf, src))
        ready[tf] = (not closed.empty) and closed["end"].max() >= expected
    return ready


def signals_from(results, cfg, now) -> list:
    want = cfg["alerts"]["directions"]
    out = []
    for r in results:
        if not r.summary:
            continue
        max_age = pd.Timedelta(minutes=cfg["max_alert_age_minutes"][r.tf])
        for s in r.summary["recent"]:
            if (want == "bullish" and s["dir"] != "bull") or (want == "bearish" and s["dir"] != "bear"):
                continue
            if now - s["bar_end"] > max_age:
                continue
            out.append(Signal(r.inst, r.tf, s["dir"], s["bar_end"], s["close"], s["ema_s"], s["ema_l"]))
    return out


def window_for(cfg, tf, previous_iso, expected) -> int:
    """How many newest candles to inspect: normally a few, more when the previous run was a while ago (so a late
    run still finds every crossover it missed) - but never older than the alert-age limit."""
    base = int(cfg["scan_last_bars"][tf])
    if not previous_iso:
        return base
    try:
        gap = (expected - pd.Timestamp(previous_iso)).total_seconds()
    except (TypeError, ValueError):
        return base
    wanted = int(math.ceil(max(0.0, gap) / TF_SECONDS[tf])) + 1
    cap = int(cfg["max_alert_age_minutes"][tf] * 60 // TF_SECONDS[tf]) + 1
    return max(base, min(wanted, cap))


def scan_once(cfg, instruments, state, now, fetcher) -> ScanOutcome:
    wanted, expected, skipped, health, windows = {}, {}, [], [], {}
    for market in sorted({i.market for i in instruments}):
        m = MARKETS[market]
        due = {}
        for tf in market_tfs(cfg, instruments, market):
            src = _ask(fetcher, "primary_source", market, BASE_INTERVAL[tf])
            exp = expected_latest_end(m, tf, now, settle_for(cfg, market, tf, src))
            prev = state["checkpoints"].get(f"{market}|{tf}")
            if exp is None or prev == exp.isoformat():
                continue
            due[tf] = exp
            windows[(market, tf)] = window_for(cfg, tf, prev, exp)
        if not due:
            continue
        ready = probe_ready(cfg, market, due, now, fetcher)
        go = [tf for tf in due if ready.get(tf)]
        skipped += [f"{market} {tf}" for tf in due if not ready.get(tf)]
        if go:
            wanted[market] = go
            expected[market] = {tf: due[tf] for tf in go}
    coll = collect(cfg, instruments, wanted, now, fetcher, windows)
    checkpoints = {}
    for market, tfs in wanted.items():
        for tf in tfs:
            st = coll.stats.get((market, BASE_INTERVAL[tf]))
            if not st:
                continue
            got = st["requested"] - len(st["failed"])
            if st["requested"] == 0 or got / st["requested"] >= cfg["alerts"]["min_data_coverage"]:
                checkpoints[f"{market}|{tf}"] = expected[market][tf].isoformat()
            else:
                health.append(f"{market} {tf}: the data feed returned candles for only {got} of {st['requested']} symbols")
    return ScanOutcome(signals_from(coll.results, cfg, now), coll, checkpoints, health, skipped, wanted, expected)


TF_ORDER = ["1w", "1d", "4h", "1h", "15m"]       # the biggest timeframes are announced first


def outage_since(cfg, tf, previous_run, now):
    """When the scanner last ran - but only if it was away longer than this timeframe's alert-age limit, i.e. when
    crossovers on older candles were left out of this message. None in every normal case."""
    if not previous_run or now is None:
        return None
    try:
        last = pd.Timestamp(previous_run)
        if last.tzinfo is None:
            last = last.tz_localize("UTC")
        away = pd.Timestamp(now) - last
    except (TypeError, ValueError):
        return None
    return last if away > pd.Timedelta(minutes=cfg["max_alert_age_minutes"][tf]) else None


def make_batches(outcome, instruments, cfg, fresh, previous_run=None, now=None) -> list:
    """One TfBatch per timeframe that had a candle close (or a new crossover) in this run.
    previous_run / now: when the scanner last ran and the time now - used to say what a long absence left out."""
    results = {(r.inst.symbol, r.tf): r for r in outcome.collected.results}
    by_tf = {}
    for key in outcome.checkpoints:
        market, tf = key.split("|")
        bar_end = outcome.expected.get(market, {}).get(tf)
        if bar_end is None:
            continue
        b = by_tf.setdefault(tf, TfBatch(tf, [], []))
        b.keys.append(key)
        for ukey, u in cfg["universes"].items():
            members = [i for i in instruments if ukey in i.universes and i.market == market and tf in i.tfs]
            total = got = late = 0
            for i in members:
                r = results.get((i.symbol, tf))
                has = r is not None and r.summary is not None
                if i.optional and not has:
                    continue                               # symbols that may not exist never count against the group
                total += 1
                if has:
                    if r.summary["last_end"] >= bar_end:
                        got += 1
                    else:
                        late += 1
            if total:
                b.coverage.append(Coverage(market, ukey, u.get("label", ukey), bar_end, total, got, late))
    for s in fresh:
        by_tf.setdefault(s.tf, TfBatch(s.tf, [], [])).signals.append(s)
    batches = [by_tf[tf] for tf in TF_ORDER if tf in by_tf]
    for b in batches:
        b.gap_from = outage_since(cfg, b.tf, previous_run, now)
    return batches
