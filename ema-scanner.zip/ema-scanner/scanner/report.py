"""Markdown + CSV report: market breadth, fresh crossovers, data coverage."""
from __future__ import annotations

import html

import pandas as pd

from .fmt import bar_label, direction_text, price
from .markets import BASE_INTERVAL


def _by_universe(results) -> dict:
    out = {}
    for r in results:
        for k in r.inst.universes:
            out.setdefault(k, []).append(r)
    return out


def _breadth(rs, tf) -> str:
    ok = [r for r in rs if r.tf == tf and r.summary]
    if not ok:
        return "–"
    bull = sum(1 for r in ok if r.summary["state"] == "bull")
    return f"{bull * 100 / len(ok):.0f}% ({bull}/{len(ok)})"


def _fresh(rs, tf, cfg) -> list:
    n = cfg["report"]["fresh_bars"][tf]
    rows = [r for r in rs if r.tf == tf and r.summary
            and r.summary["bars_since_cross"] is not None and r.summary["bars_since_cross"] < n]
    rows.sort(key=lambda r: (r.summary["bars_since_cross"], r.inst.display))
    return rows


def _table(headers, rows) -> list:
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    out += ["| " + " | ".join(str(c) for c in row) + " |" for row in rows]
    return out


def _reason_key(reason: str) -> str:
    r = reason or ""
    if r.startswith("only "):                                   # "only 23 closed candles (need 60)"
        return "too little history"
    if r.startswith("no data from the data feed"):
        inner = r[len("no data from the data feed"):].strip().strip("()")
        return inner or "the data feed returned nothing"
    return r[:80] or "unknown reason"


def gaps(coll, cfg, notes) -> list:
    """Where data is missing, in plain words: [(universe, [timeframes], symbols without data, symbols asked, reason)].
    Symbols marked optional never count, and a few strays in a big list (Nifty 500, S&P 500) are not worth a line."""
    found = {}
    by_u = _by_universe(coll.results)
    for k, u in cfg["universes"].items():
        if not u.get("enabled", True) or k not in notes:
            continue
        rs = [r for r in by_u.get(k, []) if not getattr(r.inst, "optional", False)]
        for tf in cfg["timeframes"]:
            asked = [r for r in rs if r.tf == tf]
            bad = [r for r in asked if r.summary is None]
            if not bad or (len(asked) > 30 and len(bad) < 0.1 * len(asked)):
                continue
            why, example = {}, {}
            for r in bad:
                key = _reason_key(r.reason)
                why[key] = why.get(key, 0) + 1
                example.setdefault(key, r.reason)
            top = sorted(why.items(), key=lambda kv: -kv[1])[:2]
            text = "; ".join((f"{t} ×{n}" if n > 1 else t) + (f" (e.g. {example[t]})" if t == "too little history" else "")
                             for t, n in top)
            found.setdefault((u.get("label", k), len(bad), len(asked), text), []).append(tf)
    return [(label, tfs, bad, total, text) for (label, bad, total, text), tfs in found.items()]


def gap_lines(found) -> list:
    return [f"{label} {', '.join(tfs)}: {bad} of {total} without data - {text}"[:230] for label, tfs, bad, total, text in found]


def build_report(coll, instruments, cfg, now, notes):
    """Returns (markdown_text, csv_dataframe)."""
    tz = cfg["display_timezone"]
    s, l = cfg["ema"]["short"], cfg["ema"]["long"]
    stamp = now.tz_convert(tz).strftime("%d %b %Y %H:%M %Z")
    unis = [(k, u) for k, u in cfg["universes"].items() if u.get("enabled", True) and k in notes]
    by_u = _by_universe(coll.results)
    tfs = cfg["timeframes"]
    max_rows = int(cfg["report"]["max_rows_per_table"])

    md = [f"# EMA {s}/{l} Crossover Report", "",
          f"Generated **{stamp}** · closed candles only · EMA {s} = green line, EMA {l} = red line", ""]

    md += ["## 1. Market breadth", "",
           f"Share of symbols where EMA {s} is **above** EMA {l} (bullish) at the last closed candle.", ""]
    rows = []
    for k, u in unis:
        rs = by_u.get(k, [])
        n = len({r.inst.symbol for r in rs})
        rows.append([u.get("label", k), n] + [_breadth(rs, tf) for tf in tfs])
    md += _table(["Universe", "Symbols"] + [t.upper() for t in tfs], rows) + [""]

    fresh_cfg = cfg["report"]["fresh_bars"]
    fresh_desc = ", ".join(t.upper() + ": " + str(fresh_cfg[t]) for t in tfs)
    md += ["## 2. Fresh crossovers", "",
           f"Crossovers that happened within the last few closed candles ({fresh_desc}). Newest first.", ""]
    for k, u in unis:
        rs = by_u.get(k, [])
        md += [f"### {u.get('label', k)}", ""]
        any_rows = False
        for tf in tfs:
            fr = _fresh(rs, tf, cfg)
            if not fr:
                continue
            any_rows = True
            up = sum(1 for r in fr if r.summary["last_cross_dir"] == "bull")
            md += [f"**{tf.upper()}** — {up} bullish, {len(fr) - up} bearish", ""]
            trows = []
            for r in fr[:max_rows]:
                sm = r.summary
                trows.append([r.inst.display, direction_text(sm["last_cross_dir"]),
                              bar_label(tf, sm["last_cross_end"], r.inst.market, tz), sm["bars_since_cross"],
                              f"{r.inst.currency}{price(sm['close'])}", price(sm["ema_s"]), price(sm["ema_l"]),
                              f"{sm['gap_pct']:+.2f}%"])
            md += _table(["Symbol", "Cross", "Candle closed", "Bars ago", "Close", f"EMA {s}", f"EMA {l}", "Gap"], trows)
            if len(fr) > max_rows:
                md += ["", f"_+{len(fr) - max_rows} more - see the CSV._"]
            md += [""]
        if not any_rows:
            md += ["_No fresh crossovers._", ""]

    md += ["## 3. Data coverage", ""]
    rows = []
    for k, u in unis:
        rs = by_u.get(k, [])
        fail = sorted({r.inst.display for r in rs if r.summary is None and r.reason.startswith("no data")})
        short = sorted({r.inst.display for r in rs if r.summary is None and not r.reason.startswith("no data")})
        total = len({r.inst.symbol for r in rs})
        rows.append([u.get("label", k), total, notes.get(k, ""),
                     ", ".join(fail[:25]) + (f" … (+{len(fail) - 25})" if len(fail) > 25 else "") or "none",
                     len(short)])
    md += _table(["Universe", "Symbols", "List source", "No data", "Too little history"], rows) + [""]
    found = gaps(coll, cfg, notes)
    if found or coll.events:
        md += ["**Where data is missing, and why**", ""]
        md += [f"- {line}" for line in gap_lines(found)] + [f"- {e}" for e in coll.events] + [""]
    served = coll.served or {}
    if served:
        names = {"tradingview": "TradingView", "yahoo": "Yahoo"}
        md += ["Candle sets delivered: " + ", ".join(f"{names.get(k, k.capitalize())} {v}" for k, v in served.items() if v) + ".", ""]
    if coll.invalid:
        names = sorted(coll.invalid)
        md += ["**Not recognised by TradingView** (fix the code in config.yaml or ignore): " +
               ", ".join(names[:30]) + (f" … (+{len(names) - 30})" if len(names) > 30 else ""), ""]
    md += ["## 4. Notes", "",
           "- Signals use closed candles only (same as TradingView alert 'once per bar close')."]
    if cfg.get("data_source") == "yahoo":
        md += ["- Yahoo data can differ slightly from TradingView's feed; crossovers right on the edge may differ."]
    else:
        md += ["- Candles come from TradingView's free anonymous feed, which is **delayed about 15 minutes** for NSE, "
               "US and MCX (crypto is live). Yahoo is the backup when TradingView is unavailable."]
        if any(i.market == "MCX" for i in instruments):
            md += ["- MCX symbols are TradingView continuous front-month contracts (1!); prices jump when a contract rolls over."]
    if any(i.market == "FUT" for i in instruments):
        md += ["- Commodities are **global futures proxies** (COMEX/NYMEX/ICE from Yahoo), not MCX prices."]
    md += [""]

    recs = []
    for r in coll.results:
        base = {"universes": "; ".join(r.inst.universes), "symbol": r.inst.symbol, "name": r.inst.name,
                "timeframe": r.tf}
        if r.summary:
            sm = r.summary
            recs.append({**base, "state": sm["state"], "ema_short": sm["ema_s"], "ema_long": sm["ema_l"],
                         "gap_pct": sm["gap_pct"], "close": sm["close"],
                         "last_cross": sm["last_cross_dir"] or "",
                         "bars_since_cross": sm["bars_since_cross"] if sm["bars_since_cross"] is not None else "",
                         "last_cross_candle_closed": (bar_label(r.tf, sm["last_cross_end"], r.inst.market, tz)
                                                      if sm["last_cross_end"] is not None else ""),
                         "last_candle_closed": bar_label(r.tf, sm["last_end"], r.inst.market, tz), "note": ""})
        else:
            recs.append({**base, "state": "n/a", "note": r.reason})
    return "\n".join(md), pd.DataFrame(recs)


def summary_text(coll, cfg, now, notes) -> str:
    """Short Telegram digest (HTML)."""
    tz = cfg["display_timezone"]
    s, l = cfg["ema"]["short"], cfg["ema"]["long"]
    tfs = cfg["timeframes"]
    by_u = _by_universe(coll.results)
    lines = [f"📊 <b>EMA {s}/{l} report</b> · {now.tz_convert(tz).strftime('%d %b %H:%M %Z')}", ""]
    for k, u in cfg["universes"].items():
        if not u.get("enabled", True) or k not in notes:
            continue
        rs = by_u.get(k, [])
        lines.append(f"<b>{html.escape(u.get('label', k))}</b> — bullish share: " +
                     " · ".join(f"{t} {_breadth(rs, t).split(' ')[0]}" for t in tfs))
        fresh = []
        for t in tfs:
            fr = _fresh(rs, t, cfg)
            if fr:
                up = sum(1 for r in fr if r.summary["last_cross_dir"] == "bull")
                fresh.append(f"{t} ↑{up} ↓{len(fr) - up}")
        lines.append("  fresh: " + (" · ".join(fresh) if fresh else "none"))
    found = gap_lines(gaps(coll, cfg, notes))
    if found or coll.events:
        lines += ["", "⚠️ <b>Where data is missing</b>"]
        lines += ["• " + html.escape(t, quote=False) for t in found[:6]]
        if len(found) > 6:
            lines.append(f"• … and {len(found) - 6} more (see the report)")
        lines += ["• " + html.escape(str(e)[:230], quote=False) for e in coll.events[:3]]
    lines += ["", "Full report attached."]
    return "\n".join(lines)
