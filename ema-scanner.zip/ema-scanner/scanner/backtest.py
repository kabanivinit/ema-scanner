"""Backtest of the crossover rule on every security and timeframe (long-only).

The rule is the one in ema_crossover.pine and in the live scanner, judged on CLOSED candles only:
  * EMA short crosses above EMA long  -> BUY  at the open of the next candle
  * EMA short crosses below EMA long  -> SELL at the open of the next candle
One position at a time, the whole account in, never short, and a cost on every buy and every sell.
Candles are built exactly like the live scanner builds them (4h from 1h candles, weekly from daily ones).

`simulate` is pure maths on one series; `run_backtest` downloads the candles in small chunks (so memory stays
small), runs `simulate` for every security x timeframe and returns one plain dict per result row.
"""
from __future__ import annotations

import copy
import logging
import re
import time

import numpy as np
import pandas as pd

from . import bars
from .config import _merge
from .markets import BASE_INTERVAL, MARKETS, settle_for
from .signals import cross_flags, pine_ema

log = logging.getLogger("scanner")
YEAR = pd.Timedelta(days=365.25)
DEFAULT_COST_PCT = 0.05


# ------------------------------------------------------------------------------------------ the simulation
def simulate(frame: pd.DataFrame, short_len: int, long_len: int, cost: float, warmup: int, years: float):
    """`frame` = closed candles with columns open, close, end (UTC), oldest first.

    `cost` is the fraction paid on each buy and on each sell (0.0005 = 0.05%).
    Trading is allowed only on signals from the last `years` years, and never before `warmup` candles
    have been used to settle the averages. Returns a dict of results, or None when there is too little data.
    """
    f = frame[frame["close"] > 0].reset_index(drop=True)
    n = len(f)
    if n < warmup + 3:
        return None
    close = f["close"].to_numpy(dtype=float)
    open_ = f["open"].to_numpy(dtype=float)
    open_ = np.where(np.isfinite(open_) & (open_ > 0), open_, close)          # a missing open falls back to the close
    ends = pd.DatetimeIndex(f["end"])
    up, dn = cross_flags(pine_ema(pd.Series(close), short_len), pine_ema(pd.Series(close), long_len))

    first_in_window = int(np.argmax(np.asarray(ends >= ends[-1] - years * YEAR)))
    i0 = max(int(warmup), first_in_window)             # first candle whose close may produce a signal
    if i0 >= n - 1:
        return None

    ev = np.zeros(n, dtype=np.int8)
    ev[up.to_numpy()] = 1
    ev[dn.to_numpy()] = -1
    ev[:i0] = 0

    trades = []                                        # (entry candle, exit candle or None, entry price, exit price)
    holding, entry = False, -1
    for i in np.flatnonzero(ev):
        if ev[i] == 1:
            if not holding and i + 1 < n:              # a signal on the very last candle cannot be acted on yet
                holding, entry = True, i + 1
        elif holding and i + 1 < n:
            trades.append((entry, i + 1, open_[entry], open_[i + 1]))
            holding = False
    if holding:                                        # still in a trade: counted as sold at the latest close
        trades.append((entry, None, open_[entry], close[-1]))

    gross = np.array([xp / ep - 1.0 for _, _, ep, xp in trades], dtype=float)
    net = (1.0 + gross) * (1.0 - cost) ** 2 - 1.0

    factor = np.ones(n)                                # how the account changes during each candle
    held = 0
    for e, x, _, _ in trades:
        last = (x - 1) if x is not None else n - 1     # last candle that ends while we still hold
        factor[e] *= (1.0 - cost) * close[e] / open_[e]
        if last > e:
            factor[e + 1:last + 1] *= close[e + 1:last + 1] / close[e:last]
        if x is not None:
            factor[x] *= (1.0 - cost) * open_[x] / close[x - 1]
        else:
            factor[n - 1] *= (1.0 - cost)
        held += last - e + 1
    equity = np.concatenate(([1.0], np.cumprod(factor[i0 + 1:])))
    growth = float(equity[-1])
    max_dd = float((equity / np.maximum.accumulate(equity) - 1.0).min())

    path = np.concatenate(([open_[i0 + 1]], close[i0 + 1:]))        # buy & hold over exactly the same period
    bh_growth = float(path[-1] / path[0])
    bh_dd = float((path / np.maximum.accumulate(path) - 1.0).min())

    yrs = float((ends[-1] - ends[i0]) / YEAR)
    wins = int((net > 0).sum())
    pos = float(net[net > 0].sum() * 100.0)
    neg = float(net[net < 0].sum() * 100.0)
    count = len(trades)
    return {
        "years": round(yrs, 3), "bars": int(n - i0 - 1),
        "trades": count, "wins": wins, "win_rate_pct": (wins * 100.0 / count) if count else None,
        "avg_trade_pct": float(net.mean() * 100.0) if count else None,
        "gross_avg_trade_pct": float(gross.mean() * 100.0) if count else None,
        "pos_sum_pct": pos, "neg_sum_pct": neg,
        "profit_factor": (pos / -neg) if neg < 0 else None,
        "total_return_pct": (growth - 1.0) * 100.0, "cagr_pct": cagr_pct(growth, yrs),
        "max_dd_pct": max_dd * 100.0,
        "bh_return_pct": (bh_growth - 1.0) * 100.0, "bh_cagr_pct": cagr_pct(bh_growth, yrs),
        "bh_max_dd_pct": bh_dd * 100.0,
        "exposure_pct": held * 100.0 / (n - i0 - 1),
        "avg_bars_held": (held / count) if count else None,
        "open_trade": bool(trades and trades[-1][1] is None),
        "window_from": ends[i0].date().isoformat(), "window_to": ends[-1].date().isoformat(),
        "_trades": trades, "_net": net,                # kept for the tests; not written to the reports
    }


def cagr_pct(growth: float, years: float):
    """Average yearly return in % for a total growth factor over `years` (None when the period is far too short)."""
    if years < 0.05:
        return None
    if growth <= 0:
        return -100.0
    return (growth ** (1.0 / years) - 1.0) * 100.0


# ------------------------------------------------------------------------------------- one security, one timeframe
def backtest_series(raw, market: str, tf: str, cfg: dict, now: pd.Timestamp, years: float, cost: float) -> dict:
    """Raw candles -> bars of the timeframe -> closed bars only -> simulate. Always returns a dict with a `status`."""
    if raw is None:
        return {"status": "no data from the data feed"}
    bt = cfg["backtest"]
    frame = bars.frame_for(tf, raw, MARKETS[market])
    closed = bars.closed_only(frame, now, settle_for(cfg, market, tf))
    warm = int(bt["warmup_bars"])
    if len(closed) < warm + 20:
        return {"status": f"only {len(closed)} closed candles (need {warm + 20})"}
    short, long = cfg["ema"]["short"], cfg["ema"]["long"]
    res = simulate(closed, short, long, cost, warm, years)
    if res is None:
        return {"status": "too little history for this timeframe"}
    res["status"] = "ok"
    # The same candles once more over a short recent period that EVERY timeframe can cover, so the timeframes can be
    # compared like for like (15-minute candles only reach back months, daily ones years).
    recent = float(cfg["backtest"].get("recent_years") or 0)
    if 0 < recent < years:
        rec = simulate(closed, short, long, cost, warm, recent)
        if rec is not None and rec["years"] >= 0.9 * recent:
            rec["status"] = "ok"
            res["_recent"] = rec
    return res


def fetch_cfg(cfg: dict) -> dict:
    """The settings used to download candles for a backtest: far more candles per symbol, gentler batches."""
    b = cfg["backtest"]
    out = copy.deepcopy(cfg)
    out["tradingview"] = _merge(cfg["tradingview"], b["tradingview"])
    out["yahoo"] = _merge(cfg["yahoo"], b["yahoo"])
    out["run_budget_seconds"] = float(b["max_minutes"]) * 60.0 + 900.0
    return out


# ------------------------------------------------------------------------------------------------ data helpers
def span_years(df) -> float:
    if df is None or len(df) < 2:
        return 0.0
    return float((df.index.max() - df.index.min()) / YEAR)


def period_years(text: str) -> float:
    """'730d' -> 2.0, '5y' -> 5.0, '6mo' -> 0.5 (how far back a Yahoo request reaches)."""
    m = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*(d|mo|y)\s*", str(text))
    if not m:
        return 0.0
    v, unit = float(m.group(1)), m.group(2)
    return v / 365.25 if unit == "d" else v / 12.0 if unit == "mo" else v


def deepen(fetcher, cfg: dict, symbols, data: dict) -> dict:
    """TradingView's free feed stops at about 5,000 candles. Where that is clearly shorter than what Yahoo can give
    for hourly candles (about 2 years: crypto, global futures), ask Yahoo too and keep whichever reaches further back."""
    if not cfg["backtest"].get("extend_with_yahoo", True) or cfg.get("data_source") == "tradingview":
        return data
    ask = getattr(fetcher, "_yahoo_fetch", None)
    if ask is None:
        return data
    reach = period_years(cfg["yahoo"]["periods"].get("1h", ""))
    need = [s for s in symbols if ":" not in s and s in data and span_years(data[s]) < 0.8 * reach]
    if not need:
        return data
    try:
        got, _ = ask(need, "1h")
    except Exception as e:                                          # noqa: BLE001
        log.warning("Yahoo extension for hourly candles failed (%s) - keeping TradingView's shorter history", str(e)[:100])
        return data
    longer = 0
    for s, d in (got or {}).items():
        if span_years(d) > 1.2 * span_years(data[s]):
            data[s] = d
            longer += 1
    log.info("Hourly history extended with Yahoo for %d of %d symbols", longer, len(need))
    return data


def _revive_tv(fetcher, used: int, sleep, limit: int = 4, rest: int = 90) -> int:
    """If TradingView went quiet earlier in this long run, rest a little and try it again (a few times at most)."""
    tv = getattr(fetcher, "tv", None)
    if tv is not None and getattr(tv, "down", "") and used < limit:
        log.warning("TradingView stopped answering (%s) - resting %d seconds, then trying again", tv.down, rest)
        sleep(rest)
        tv.down = ""
        tv._streak = 0
        return used + 1
    return used


def _base(inst, tf: str) -> dict:
    return {"symbol": inst.symbol, "display": inst.display, "name": inst.name, "market": inst.market,
            "universes": ";".join(inst.universes), "timeframe": tf}


def _public(res: dict) -> dict:
    """Result rows keep the numbers only (the trade lists are for the tests)."""
    return {k: v for k, v in res.items() if not k.startswith("_")}


def _skipped(part, tfs, why: str) -> list:
    return [{**_base(i, tf), "window": "full", "status": why} for i in part for tf in tfs if tf in i.tfs]


def limit_instruments(instruments, cfg: dict, n: int) -> list:
    """Quick test mode: only the first `n` symbols of every group."""
    keep = set()
    for ukey in cfg["universes"]:
        keep.update([i.symbol for i in instruments if ukey in i.universes][:n])
    return [i for i in instruments if i.symbol in keep]


# ----------------------------------------------------------------------------------------------------- the run
def _chunk(cfg, part, tfs, now, fetcher, years, cost) -> list:
    raw = {}
    for itv in sorted({BASE_INTERVAL[tf] for tf in tfs}):
        syms = [i.symbol for i in part if any(BASE_INTERVAL[tf] == itv and tf in i.tfs for tf in tfs)]
        if not syms:
            continue
        data, _failed = fetcher(syms, itv)
        raw[itv] = deepen(fetcher, cfg, syms, data) if itv == "1h" else data
    out = []
    for i in part:
        for tf in tfs:
            if tf not in i.tfs:
                continue
            try:
                res = backtest_series(raw.get(BASE_INTERVAL[tf], {}).get(i.symbol), i.market, tf, cfg, now, years, cost)
            except Exception as e:                                  # noqa: BLE001
                res = {"status": f"error: {str(e)[:80]}"}
            recent = res.pop("_recent", None)
            out.append({**_base(i, tf), "window": "full", **_public(res)})
            if recent:
                out.append({**_base(i, tf), "window": "recent", **_public(recent)})
    return out


def run_backtest(cfg, instruments, now, fetcher, years, tfs, on_chunk=None, clock=time.monotonic, sleep=time.sleep) -> list:
    """Returns one dict per (security, timeframe). `cfg` must already be the one from `fetch_cfg`."""
    bt = cfg["backtest"]
    chunk = max(1, int(bt["chunk_symbols"]))
    budget = float(bt["max_minutes"]) * 60.0
    t0, rows, revived = clock(), [], 0
    by_market = {}
    for inst in instruments:
        by_market.setdefault(inst.market, []).append(inst)
    total = len(instruments)
    for market in sorted(by_market):
        insts = by_market[market]
        mtfs = [tf for tf in tfs if any(tf in i.tfs for i in insts)]
        cost = float(bt["cost_pct_per_side"].get(market, DEFAULT_COST_PCT)) / 100.0
        for start in range(0, len(insts), chunk):
            part = insts[start:start + chunk]
            if clock() - t0 > budget:
                rows += _skipped(part, mtfs, "not tested: the time limit was reached")
                continue
            revived = _revive_tv(fetcher, revived, sleep)
            try:
                rows += _chunk(cfg, part, mtfs, now, fetcher, years, cost)
            except Exception as e:                                  # noqa: BLE001
                log.error("%s symbols %d-%d failed: %s", market, start + 1, start + len(part), str(e)[:120])
                rows += _skipped(part, mtfs, f"error: {str(e)[:80]}")
            done = len({r["symbol"] for r in rows})
            log.info("Backtest progress: %d of %d securities (%s) after %.0f min", done, total, market,
                     (clock() - t0) / 60.0)
            if on_chunk:
                on_chunk(rows)
    return rows
