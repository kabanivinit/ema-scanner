"""Fyers market data: real-time candles for NSE / BSE / MCX (TradingView keeps serving US stocks and crypto).

How it works, in plain words
  * About every 15 days you log in to Fyers in your browser (workflow "4 - Fyers Login"). That hands the scanner a
    "refresh token". It is kept in the scanner's memory (state/fyers_token.enc), locked with a key that is made from
    your own GitHub secrets - nobody can read it from the public repository.
  * Every run turns that refresh token into a fresh day-pass (access token) and asks Fyers for candles.
  * The scanner counts its own requests and stays well below Fyers' limits, because Fyers blocks an account for the
    rest of the day after the per-minute limit has been broken three times.
  * If anything about Fyers fails, the affected symbols fall back to TradingView (about 15 minutes late) and the
    scanner tells you why on Telegram - it never goes silent.
"""
from __future__ import annotations

import base64
import csv
import hashlib
import io
import json
import logging
import math
import os
import re
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse

import pandas as pd
import requests

from .config import ROOT
from .markets import BASE_INTERVAL

log = logging.getLogger("scanner")

API = "https://api-t1.fyers.in/api/v3"
DATA = "https://api-t1.fyers.in/data"
MASTER_URL = "https://public.fyers.in/sym_details/{name}.csv"
DEFAULT_REDIRECT = "https://trade.fyers.in/api-login/redirect-uri/index.html"
RESOLUTION = {"15m": "15", "1h": "60", "1d": "D"}          # base intervals the scanner asks for
STATE_DIR = ROOT / "state"
TOKEN_FILE = "fyers_token.enc"
REFRESH_DAYS = 15                                            # Fyers refresh tokens live about 15 days
IST = timezone(timedelta(hours=5, minutes=30))
SECRET_NAMES = ("FYERS_APP_ID", "FYERS_SECRET_ID", "FYERS_PIN")


class FyersError(Exception):
    """Something Fyers answered (or did not answer). `kind` tells the caller what to do about it."""

    def __init__(self, message, code=None, status=None, kind="other"):
        super().__init__(message)
        self.code, self.status, self.kind = code, status, kind


# ------------------------------------------------------------------------------------------ talking to Fyers
def _body(r) -> dict:
    try:
        b = r.json()
        return b if isinstance(b, dict) else {"s": "error", "message": str(b)[:160]}
    except Exception:                                           # noqa: BLE001
        return {"s": "error", "message": (getattr(r, "text", "") or f"HTTP {r.status_code}")[:160]}


class RequestsHttp:
    """The only place that really talks to the internet (tests replace it with a fake)."""

    def get(self, url, params=None, headers=None, timeout=20):
        r = requests.get(url, params=params, headers=headers, timeout=timeout)
        return r.status_code, _body(r)

    def post(self, url, payload=None, headers=None, timeout=20):
        r = requests.post(url, json=payload, headers=headers, timeout=timeout)
        return r.status_code, _body(r)

    def text(self, url, timeout=60) -> str:
        r = requests.get(url, timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
        r.raise_for_status()
        return r.text


def classify(status, code, text) -> str:
    t = (text or "").lower()
    if status == 429 or code == -429 or "rate limit" in t or "limit exceed" in t or "too many" in t:
        return "rate"
    if status in (401, 403) or code in (-8, -15, -16, -17) or any(w in t for w in ("authenticate", "token", "unauthor", "expired")):
        return "auth"
    if code == -300 or ("symbol" in t and ("invalid" in t or "valid" in t)):
        return "invalid"
    return "other"


def raise_for(status, body) -> None:
    s = str(body.get("s", "")).lower()
    if s in ("ok", "no_data") and (status or 200) < 400:
        return
    msg = str(body.get("message") or body.get("msg") or f"HTTP {status}")[:160]
    code = body.get("code")
    raise FyersError(msg, code=code, status=status, kind=classify(status, code, msg))


# ------------------------------------------------------------------------------------------ credentials & login
@dataclass
class Creds:
    app_id: str
    secret: str
    pin: str
    redirect: str = DEFAULT_REDIRECT

    @classmethod
    def from_env(cls, env=None):
        env = os.environ if env is None else env
        a, s, p = (str(env.get(k, "")).strip() for k in SECRET_NAMES)
        if not (a and s and p):
            return None
        return cls(a, s, p, str(env.get("FYERS_REDIRECT_URI", "")).strip() or DEFAULT_REDIRECT)

    @property
    def app_hash(self) -> str:
        return hashlib.sha256(f"{self.app_id}:{self.secret}".encode()).hexdigest()

    def login_url(self) -> str:
        q = urlencode({"client_id": self.app_id, "redirect_uri": self.redirect, "response_type": "code",
                       "state": "ema_scanner"})
        return f"{API}/generate-authcode?{q}"

    def cipher(self):
        from cryptography.fernet import Fernet
        key = hashlib.sha256(f"ema-scanner|{self.app_id}|{self.secret}|{self.pin}".encode()).digest()
        return Fernet(base64.urlsafe_b64encode(key))


def missing_secrets(env=None) -> list:
    env = os.environ if env is None else env
    return [k for k in SECRET_NAMES if not str(env.get(k, "")).strip()]


def configured(env=None) -> bool:
    return not missing_secrets(env)


def parse_auth_code(text: str) -> str:
    """Accepts the whole address Fyers sent you to (…?s=ok&code=200&auth_code=eyJ…&state=…) or just the code."""
    t = (text or "").strip().strip("\"'")
    if "auth_code=" in t:
        q = parse_qs(urlparse(t).query)
        if q.get("auth_code"):
            return q["auth_code"][0].strip()
        m = re.search(r"auth_code=([^&\s#]+)", t)
        if m:
            return m.group(1)
    return t


def exchange_auth_code(creds: Creds, code: str, http) -> dict:
    status, body = http.post(f"{API}/validate-authcode",
                             {"grant_type": "authorization_code", "appIdHash": creds.app_hash, "code": code})
    raise_for(status, body)
    if not body.get("access_token"):
        raise FyersError("Fyers did not hand out an access token")
    return {"access_token": body["access_token"], "refresh_token": body.get("refresh_token") or ""}


def refresh_access_token(creds: Creds, refresh_token: str, http) -> dict:
    status, body = http.post(f"{API}/validate-refresh-token",
                             {"grant_type": "refresh_token", "appIdHash": creds.app_hash,
                              "refresh_token": refresh_token, "pin": creds.pin})
    raise_for(status, body)
    if not body.get("access_token"):
        raise FyersError("Fyers did not hand out an access token")
    return {"access_token": body["access_token"], "refresh_token": body.get("refresh_token") or ""}


def _iso(t: datetime) -> str:
    return t.astimezone(timezone.utc).isoformat()


def _parse_iso(s):
    try:
        t = datetime.fromisoformat(str(s))
        return t if t.tzinfo else t.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


class TokenStore:
    """The saved login, encrypted with a key made from your secrets (it sits in the scanner's memory, not in the repo)."""

    def __init__(self, creds: Creds, path=None):
        self.creds = creds
        self.path = Path(path) if path else STATE_DIR / TOKEN_FILE
        self.problem = ""

    def load(self) -> dict:
        self.problem = ""
        if not self.path.exists():
            return {}
        try:
            from cryptography.fernet import InvalidToken
            try:
                return json.loads(self.creds.cipher().decrypt(self.path.read_bytes()).decode("utf-8"))
            except InvalidToken:
                self.problem = "the saved Fyers login cannot be read (the Fyers secrets were changed) - log in again"
        except Exception as e:                                  # noqa: BLE001
            self.problem = f"the saved Fyers login is unreadable ({str(e)[:60]}) - log in again"
        return {}

    def save(self, **fields) -> None:
        data = self.load()
        data.update({k: v for k, v in fields.items() if v is not None})
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_bytes(self.creds.cipher().encrypt(json.dumps(data).encode("utf-8")))
        os.replace(tmp, self.path)


class Session:
    """Holds today's access token and renews it from the saved refresh token."""

    def __init__(self, creds: Creds, store: TokenStore, http, now=None):
        self.creds, self.store, self.http = creds, store, http
        self.now = now or (lambda: datetime.now(timezone.utc))
        self.token = ""
        self.problem = ""
        self.days_left = None            # days until you must log in again
        self._lock = threading.Lock()

    def start(self) -> bool:
        data = self.store.load()
        if not data.get("refresh_token"):
            self.problem = self.store.problem or "no Fyers login saved yet - run workflow '4 - Fyers Login'"
            return False
        saved = _parse_iso(data.get("refresh_at"))
        if saved:                                         # only a guide: Fyers itself decides whether the login still works
            self.days_left = REFRESH_DAYS - (self.now() - saved).total_seconds() / 86400.0
        at = _parse_iso(data.get("access_at"))
        if data.get("access_token") and at:
            same_day = at.astimezone(IST).date() == self.now().astimezone(IST).date()
            if same_day and (self.now() - at) < timedelta(hours=18):
                self.token = data["access_token"]
                return True
        return self.renew()

    def renew(self, failed_token: str = "") -> bool:
        """Gets a fresh access token. `failed_token` = the one that just stopped working (so threads renew only once)."""
        with self._lock:
            if failed_token and self.token and self.token != failed_token:
                return True
            data = self.store.load()
            try:
                new = refresh_access_token(self.creds, data.get("refresh_token", ""), self.http)
            except FyersError as e:
                if e.kind in ("auth", "other"):
                    old = self.days_left is not None and self.days_left <= 0
                    self.problem = ((f"the Fyers login has expired (it lasts about {REFRESH_DAYS} days; Fyers said: {e})" if old
                                     else f"Fyers refused the saved login ({e})") + " - run workflow '4 - Fyers Login' again")
                else:
                    self.problem = f"Fyers login check failed ({e})"
                return False
            except (requests.RequestException, ValueError) as e:
                self.problem = f"could not reach Fyers to renew the login ({str(e)[:80]})"
                return False
            fields = {"access_token": new["access_token"], "access_at": _iso(self.now())}
            if new["refresh_token"] and new["refresh_token"] != data.get("refresh_token"):
                fields.update(refresh_token=new["refresh_token"], refresh_at=_iso(self.now()))      # Fyers handed out a fresh one
                self.days_left = float(REFRESH_DAYS)
            self.store.save(**fields)
            self.token = new["access_token"]
            self.problem = ""
            return True


# ------------------------------------------------------------------------------------------ pacing
class BudgetExhausted(Exception):
    """Today's request allowance is used up."""


class BudgetReserved(BudgetExhausted):
    """What is left of today's allowance is kept for MCX (it has no other source of prices)."""


class Limiter:
    """Never lets the scanner go faster than the limits (per second / minute / day), across threads."""

    def __init__(self, per_second, per_minute, per_day, used_today=0, clock=time.monotonic, sleep=time.sleep):
        self.per_second, self.per_minute, self.per_day = int(per_second), int(per_minute), int(per_day)
        self.used = int(used_today)
        self._hits = deque()
        self._clock, self._sleep = clock, sleep
        self._lock = threading.Lock()

    def acquire(self, reserve: int = 0) -> None:
        """Waits for a free slot. `reserve` = how many of today's requests must stay untouched for others."""
        with self._lock:
            while True:
                if self.used >= self.per_day:
                    raise BudgetExhausted()
                if reserve and self.used >= self.per_day - reserve:
                    raise BudgetReserved()
                now = self._clock()
                while self._hits and now - self._hits[0] >= 60.0:
                    self._hits.popleft()
                wait = 0.0
                if len(self._hits) >= self.per_minute:
                    wait = self._hits[0] + 60.0 - now + 0.05
                else:
                    recent = [t for t in self._hits if now - t < 1.0]
                    if len(recent) >= self.per_second:
                        wait = recent[0] + 1.0 - now + 0.01
                if wait <= 0:
                    self._hits.append(now)
                    self.used += 1
                    return
                self._sleep(wait)


# ------------------------------------------------------------------------------------------ symbol master
TICKER_RE = re.compile(r"^(NSE|BSE|MCX):[A-Z0-9&_\-]+$")
MCX_FUT_RE = re.compile(r"^MCX:([A-Z]+)(\d{2})([A-Z]{3})FUT$")
MONTHS = {m: i for i, m in enumerate(["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"], 1)}


def _norm(s: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(s).upper())


class Master:
    """Fyers' public symbol lists (NSE_CM, BSE_CM, MCX_COM). Saved for a few days so most runs download nothing."""

    def __init__(self, fcfg, http, now=None, folder=None):
        self.fcfg, self.http = fcfg, http
        self.now = now or (lambda: datetime.now(timezone.utc))
        self.folder = Path(folder) if folder else STATE_DIR / "fyers"
        self._rows = {}
        self.notes = {}

    def rows(self, name):
        """Parsed rows (lists of text) or None when the list cannot be had."""
        if name in self._rows:
            return self._rows[name]
        path = self.folder / f"{name}.csv"
        days = float(self.fcfg.get("master_refresh_days", {}).get(name, 7))
        text, note = None, ""
        if path.exists() and (self.now().timestamp() - path.stat().st_mtime) < days * 86400:
            text, note = path.read_text(encoding="utf-8", errors="replace"), "saved copy"
        else:
            try:
                text = self.http.text(MASTER_URL.format(name=name))
                self.folder.mkdir(parents=True, exist_ok=True)
                path.write_text(text, encoding="utf-8")
                note = "downloaded"
            except Exception as e:                              # noqa: BLE001
                if path.exists():
                    text, note = path.read_text(encoding="utf-8", errors="replace"), f"download failed ({str(e)[:50]}) - old copy"
                else:
                    note = f"download failed ({str(e)[:70]})"
        rows = list(csv.reader(io.StringIO(text))) if text else None
        self.notes[name] = f"{name}: {note}" + (f", {len(rows)} rows" if rows else "")
        self._rows[name] = rows or None
        return self._rows[name]

    def ticker_col(self, name):
        rows = self.rows(name) or []
        width = max((len(r) for r in rows[:50]), default=0)
        best, best_n = None, 0
        for c in range(width):
            n = sum(1 for r in rows[:300] if len(r) > c and TICKER_RE.match(r[c].strip()))
            if n > best_n:
                best, best_n = c, n
        return best if best_n >= 5 else None

    def tickers(self, name):
        """{ticker: description} or None."""
        rows = self.rows(name)
        tc = self.ticker_col(name)
        if rows is None or tc is None:
            return None
        out = {}
        for r in rows:
            if len(r) > tc and TICKER_RE.match(r[tc].strip()):
                out[r[tc].strip()] = r[1].strip() if len(r) > 1 and tc != 1 else ""
        return out


# ------------------------------------------------------------------------------------------ our symbol -> Fyers symbol
INDEX_CODES = {                         # how config.yaml names an index -> Fyers codes to try (first that exists wins)
    "^NSEI": ["NSE:NIFTY50-INDEX"], "^NSEBANK": ["NSE:NIFTYBANK-INDEX"], "^BSESN": ["BSE:SENSEX-INDEX"],
    "^NSMIDCP": ["NSE:NIFTYNEXT50-INDEX"], "^NSEMDCP50": ["NSE:NIFTYMIDCAP50-INDEX"],
    "^CRSLDX": ["NSE:NIFTY500-INDEX"], "^CNXIT": ["NSE:NIFTYIT-INDEX"], "^CNXAUTO": ["NSE:NIFTYAUTO-INDEX"],
    "^CNXPHARMA": ["NSE:NIFTYPHARMA-INDEX"], "^CNXFMCG": ["NSE:NIFTYFMCG-INDEX"], "^CNXMETAL": ["NSE:NIFTYMETAL-INDEX"],
    "^CNXREALTY": ["NSE:NIFTYREALTY-INDEX"], "^CNXENERGY": ["NSE:NIFTYENERGY-INDEX"],
    "^CNXINFRA": ["NSE:NIFTYINFRA-INDEX"], "^CNXPSUBANK": ["NSE:NIFTYPSUBANK-INDEX"],
    "^CNXMEDIA": ["NSE:NIFTYMEDIA-INDEX"], "^CNXFIN": ["NSE:FINNIFTY-INDEX", "NSE:NIFTYFINSERVICE-INDEX"],
    "^CNXPSE": ["NSE:NIFTYPSE-INDEX"], "^CNXCMDT": ["NSE:NIFTYCOMMODITIES-INDEX"],
    "^CNXSERVICE": ["NSE:NIFTYSERVSECTOR-INDEX", "NSE:NIFTYSERVICES-INDEX"], "^CNXMNC": ["NSE:NIFTYMNC-INDEX"],
    "NSE:CNX100": ["NSE:NIFTY100-INDEX"], "NSE:CNX200": ["NSE:NIFTY200-INDEX"],
    "NSE:CNXMIDCAP": ["NSE:NIFTYMIDCAP100-INDEX"], "NSE:CNXSMALLCAP": ["NSE:NIFTYSMLCAP100-INDEX"],
    "NSE:NIFTYMIDCAP150": ["NSE:NIFTYMIDCAP150-INDEX"], "NSE:NIFTYSMLCAP250": ["NSE:NIFTYSMLCAP250-INDEX"],
    "NSE:NIFTYPVTBANK": ["NSE:NIFTYPVTBANK-INDEX"], "NSE:CNXCONSUMPTION": ["NSE:NIFTYCONSUMPTION-INDEX"],
    "NSE:INDIAVIX": ["NSE:INDIAVIX-INDEX"],
}
EQUITY_SERIES = ("EQ", "BE", "BZ", "SM", "ST")


def _pick(cands, pool):
    """First candidate listed by Fyers; with no list available (None) the first guess is used."""
    if pool is None:
        return cands[0] if cands else ""
    return next((c for c in cands if c in pool), "")


def mcx_root(inst) -> str:
    hint = [h for h in (getattr(inst, "fyers_hint", None) or []) if h]
    if hint:
        return _norm(hint[0].split(":")[-1])
    m = re.match(r"^MCX:([A-Z0-9]+?)1!$", inst.symbol)
    return m.group(1) if m else ""


def front_contracts(pool) -> dict:
    """{root: [(year, month, ticker)] oldest first} for MCX futures in the master."""
    out = {}
    for t in pool or ():
        m = MCX_FUT_RE.match(t)
        if m and m.group(3) in MONTHS:
            out.setdefault(m.group(1), []).append((2000 + int(m.group(2)), MONTHS[m.group(3)], t))
    return {k: sorted(v) for k, v in out.items()}


def resolve(instruments, fcfg, master: Master, today=None) -> dict:
    """Sets `inst.fyers` for every Indian instrument Fyers can serve. Returns a report for Check Setup."""
    today = today or datetime.now(IST).date()
    report = {"mapped": 0, "missing": [], "notes": [], "mcx": {}}
    nse = master.tickers("NSE_CM") if any(i.market in ("NSE", "MCX") for i in instruments) else None
    bse = None
    mcx = None
    futs = {}
    if any(i.market == "MCX" for i in instruments):
        mcx = master.tickers("MCX_COM")
        futs = front_contracts(mcx)
    idx_by_norm = {}
    for t, desc in (nse or {}).items():
        if t.endswith("-INDEX"):
            idx_by_norm.setdefault(_norm(t.split(":")[1][:-6]), t)
            if desc:
                idx_by_norm.setdefault(_norm(desc), t)
    roll = int(fcfg.get("mcx_roll_days", 3))
    for i in instruments:
        i.fyers = ""
        if i.market == "NSE":
            if i.symbol.endswith(".NS"):
                base = i.symbol[:-3]
                i.fyers = _pick([f"NSE:{base}-{s}" for s in EQUITY_SERIES], nse)
            else:
                hints = list(getattr(i, "fyers_hint", None) or []) + INDEX_CODES.get(i.symbol, [])
                pool = nse
                if any(h.startswith("BSE:") for h in hints):
                    bse = bse if bse is not None else master.tickers("BSE_CM")
                    pool = {**(nse or {}), **(bse or {})} if (nse is not None or bse is not None) else None
                i.fyers = _pick(hints, pool)
                if not i.fyers and nse:
                    i.fyers = idx_by_norm.get(_norm(i.name), "")
        elif i.market == "MCX":
            root = mcx_root(i)
            chain = futs.get(root, [])
            if chain:
                # the nearest contract; the next one once this one is within `roll` days of the end of its month
                pick = chain[0]
                if len(chain) > 1 and (pick[0], pick[1]) == (today.year, today.month):
                    last_day = (datetime(today.year + (today.month == 12), today.month % 12 + 1, 1).date() - timedelta(days=1))
                    if (last_day - today).days < roll:
                        pick = chain[1]
                i.fyers = pick[2]
                report["mcx"][i.name] = i.fyers
            elif mcx is None and root:
                i.fyers = ""                                   # no master -> cannot guess the month code
        if i.fyers:
            report["mapped"] += 1
        elif i.market in ("NSE", "MCX"):
            report["missing"].append(i.name)
    report["notes"] = list(master.notes.values())
    return report


# ------------------------------------------------------------------------------------------ the data feed
def candles_to_frame(candles):
    rows = [c[:6] for c in candles if isinstance(c, (list, tuple)) and len(c) >= 5]
    if not rows:
        return None
    width = len(rows[0])
    names = ["t", "open", "high", "low", "close", "volume"][:width]
    df = pd.DataFrame([r[:width] for r in rows], columns=names)
    df.index = pd.DatetimeIndex(pd.to_datetime(df.pop("t"), unit="s", utc=True))
    return df


class FyersFeed:
    """fetch({our_symbol: fyers_symbol}, interval) -> ({our_symbol: DataFrame}, [our symbols without data])."""

    name = "fyers"

    def __init__(self, fcfg, plan, creds: Creds, session: Session, http, limiter: Limiter, now=None):
        self.fcfg, self.plan = fcfg, plan
        self.creds, self.session, self.http, self.limiter = creds, session, http, limiter
        self.now = now or (lambda: datetime.now(timezone.utc))
        self.skip = set(fcfg["limits"][plan].get("skip_intervals") or ())
        self.reserve = int(fcfg["limits"][plan].get("reserve_mcx", 0))      # requests kept back for MCX every day
        self.clock = time.monotonic
        self._deadline = None                                               # set when the first request is made
        self.down = ""
        self.invalid = set()
        self.reasons = {}
        self.events = []
        self.calls = 0
        self._started = False
        self._halt = ""
        self.report = None                 # how our symbols were matched to Fyers codes (Check Setup prints it)
        self._lock = threading.Lock()

    # -- state shared between runs (the daily call counter)
    def attach_state(self, state: dict) -> None:
        today = self.now().astimezone(IST).date().isoformat()
        s = state.get("fyers") or {}
        self.limiter.used = int(s.get("calls", 0)) if s.get("day") == today else 0

    def save_state(self, state: dict) -> None:
        state["fyers"] = {"day": self.now().astimezone(IST).date().isoformat(), "calls": self.limiter.used}

    # -- availability
    def _start(self) -> bool:
        if not self._started:
            self._started = True
            if not self.session.start():
                self.down = self.session.problem or "not logged in"
            elif self.session.days_left is not None and self.session.days_left <= float(self.fcfg.get("warn_days", 2)):
                n = max(0, math.ceil(self.session.days_left))
                self.events.append(f"Fyers login ends in about {n} day{'s' if n != 1 else ''} - run workflow "
                                   f"'4 - Fyers Login' soon, or Indian prices fall back to delayed TradingView data.")
        return not self.down

    def covers(self, interval: str) -> bool:
        return interval in RESOLUTION and interval not in self.skip and not self.down

    # -- one request
    def _spans(self, interval, long_daily):
        days = int(self.fcfg["history_days"][interval])
        n = 2 if (interval == "1d" and long_daily) else 1
        end, out = self.now(), []
        for _ in range(n):
            start = end - timedelta(days=days)
            out.append((start, end))
            end = start - timedelta(days=1)
        return out

    def _get(self, fsym, interval, a, b):
        params = {"symbol": fsym, "resolution": RESOLUTION[interval], "date_format": "0",
                  "range_from": str(int(a.timestamp())), "range_to": str(int(b.timestamp())), "cont_flag": "1"}
        token = self.session.token
        headers = {"Authorization": f"{self.creds.app_id}:{token}", "version": "3"}
        self.limiter.acquire(0 if fsym.startswith("MCX:") else self.reserve)
        with self._lock:
            self.calls += 1
        status, body = self.http.get(f"{DATA}/history", params, headers, float(self.fcfg.get("timeout_seconds", 20)))
        try:
            raise_for(status, body)
        except FyersError as e:
            e.token = token
            raise
        return body.get("candles") or []

    def _halt_run(self, why: str) -> None:
        with self._lock:
            if not self._halt:
                self._halt = why
                self.events.append(f"Fyers: {why} - the rest of this run uses TradingView (about 15 minutes late).")

    def _one(self, our, fsym, interval, spans):
        """All candles for one symbol. Returns (our symbol, DataFrame or None, reason it failed)."""
        try:
            return self._collect(our, fsym, interval, spans)
        except Exception as e:                                  # noqa: BLE001
            return our, None, f"error: {str(e)[:80]}"

    def _collect(self, our, fsym, interval, spans):
        retries = int(self.fcfg.get("retries", 1))
        frames = []
        for a, b in spans:
            attempt, reauthed, last, candles = 0, False, None, []
            while True:
                if self._halt:
                    return our, None, self._halt
                if self._deadline is not None and self.clock() > self._deadline:
                    self._halt_run(f"this run's time allowance ({int(self.fcfg.get('max_seconds', 1100))} seconds) is used up")
                    return our, None, "time limit"
                try:
                    candles, last = self._get(fsym, interval, a, b), None
                    break
                except BudgetReserved:
                    return our, None, "daily limit (the rest is kept for MCX)"          # this symbol only; MCX carries on
                except BudgetExhausted:
                    self._halt_run(f"today's request allowance is used up ({self.limiter.used} of {self.limiter.per_day})")
                    return our, None, "daily limit"
                except FyersError as e:
                    last = e
                    if e.kind == "rate":
                        self._halt_run(f"Fyers said we are going too fast ({e})")
                        return our, None, "rate limit"
                    if e.kind == "auth":
                        if reauthed or not self.session.renew(getattr(e, "token", "")):
                            self._halt_run(f"login problem - {self.session.problem or e}")
                            self.down = self.session.problem or str(e)
                            return our, None, "login"
                        reauthed = True
                        continue                                # same request again with the renewed token
                    if e.kind == "invalid":
                        self.invalid.add(our)
                        return our, None, str(e)
                except (requests.RequestException, ValueError) as e:
                    last = FyersError(f"network: {str(e)[:70]}", kind="net")
                attempt += 1
                if attempt > retries:
                    break
                time.sleep(0.5 * attempt)
            if last is not None:
                return our, None, str(last)
            f = candles_to_frame(candles)
            if f is not None:
                frames.append(f)
        if not frames:
            return our, None, "no candles"
        df = pd.concat(frames)
        df = df[~df.index.duplicated(keep="last")].sort_index()
        return our, df, ""

    def fetch(self, symbols: dict, interval: str, long_daily: bool = False):
        out, failed = {}, []
        if not symbols or not self._start() or interval not in RESOLUTION:
            return out, list(symbols)
        if self._deadline is None:
            self._deadline = self.clock() + float(self.fcfg.get("max_seconds", 1100))
        spans = self._spans(interval, long_daily)
        workers = max(1, int(self.fcfg.get("workers", 4)))
        jobs = list(symbols.items())
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for our, df, why in pool.map(lambda kv: self._one(kv[0], kv[1], interval, spans), jobs):
                if df is not None:
                    out[our] = df
                else:
                    failed.append(our)
                    self.reasons[our] = why
        if self._halt and not self.down:
            self.down = self._halt
        return out, failed


# ------------------------------------------------------------------------------------------ set-up
def setup(cfg, instruments, purpose="scan", http=None, env=None, now=None, master=None, limiter=None):
    """Returns a FyersFeed (and sets `inst.fyers` on the Indian instruments), or None when Fyers is not in use."""
    creds = Creds.from_env(env)
    fcfg = cfg.get("fyers") or {}
    if creds is None or not instruments or fcfg.get("enabled") is False:
        return None
    plan = fcfg.get("plan", "standard")
    if purpose == "backtest":
        return None
    only_mcx = purpose == "report" and plan != "prime"       # an end-of-day report does not need real-time NSE prices,
    if only_mcx and not any(i.market == "MCX" for i in instruments):      # but MCX has no other source of prices
        return None
    http = http or RequestsHttp()
    master = master or Master(fcfg, http, now=now)
    lim = fcfg["limits"][plan]
    report = resolve([i for i in instruments if i.market == "MCX"] if only_mcx else instruments, fcfg, master)
    skip = set(lim.get("skip_intervals") or ())
    for i in instruments:
        if i.market == "MCX" and i.fyers:                    # candles the plan cannot serve do not exist for MCX at all
            i.tfs = {tf for tf in i.tfs if BASE_INTERVAL[tf] not in skip}
    limiter = limiter or Limiter(lim["per_second"], lim["per_minute"], lim["per_day"])
    session = Session(creds, TokenStore(creds), http, now=now)
    feed = FyersFeed(fcfg, plan, creds, session, http, limiter, now=now)
    feed.report = report
    return feed


def estimate_daily_calls(instruments, cfg) -> dict:
    """Rough number of history requests per trading day for the current lists (for Check Setup)."""
    fcfg = cfg["fyers"]
    skip = set(fcfg["limits"][fcfg["plan"]].get("skip_intervals") or ())
    per = {"NSE": {"15m": 25, "1h": 7, "1d": 1.2}, "MCX": {"15m": 58, "1h": 15, "1d": 1.2}}
    need = {BASE_INTERVAL[t] for t in cfg["timeframes"]}
    n = {"NSE": 0, "MCX": 0}
    for i in instruments:
        if getattr(i, "fyers", "") and i.market in n:
            n[i.market] += 1
    total = {itv: sum(n[m] * per[m][itv] for m in n) for itv in ("15m", "1h", "1d") if itv in need}
    return {"symbols": n, "per_interval": total, "skipped": sorted(skip & need),
            "total": int(sum(v for k, v in total.items() if k not in skip))}
