"""Fyers market data: real-time candles for NSE / BSE / MCX (TradingView keeps serving US stocks and crypto).

How it works, in plain words
  * Fyers (SEBI rules) wants a fresh two-step login every day. The scanner does it by itself, the way you would in the
    Fyers app: your user ID, then the 6-digit TOTP code (made from your TOTP key), then your PIN. The result is a
    day-pass (access token) that is kept in the scanner's memory (state/fyers_token.enc), locked with a key that is made
    from your own GitHub secrets - nobody can read it from the public repository.
  * The first Fyers request of the day finds no pass from today, logs in, and every later run reuses the pass. If Fyers
    drops the pass earlier, the scanner logs in once more.
  * A login that Fyers refuses is NOT repeated in a loop: a wrong PIN waits until tomorrow (wrong PINs can lock an
    account), other refusals wait a few hours, and there are at most six attempts a day.
  * The scanner counts its own requests and stays well below Fyers' limits, because Fyers blocks an account for the
    rest of the day after the per-minute limit has been broken three times.
  * If anything about Fyers fails, the affected symbols fall back to TradingView (about 15 minutes late) and the
    scanner tells you why on Telegram - it never goes silent.
"""
from __future__ import annotations

import base64
import binascii
import csv
import hashlib
import hmac
import io
import json
import logging
import os
import re
import struct
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse

import pandas as pd
import requests

from .config import ROOT
from .markets import BASE_INTERVAL

log = logging.getLogger("scanner")

API = "https://api-t1.fyers.in/api/v3"
DATA = "https://api-t1.fyers.in/data"
VAGATOR = "https://api-t2.fyers.in/vagator/v2"             # the servers behind Fyers' own login page
MASTER_URL = "https://public.fyers.in/sym_details/{name}.csv"
DEFAULT_REDIRECT = "https://trade.fyers.in/api-login/redirect-uri/index.html"
RESOLUTION = {"15m": "15", "1h": "60", "1d": "D"}          # base intervals the scanner asks for
STATE_DIR = ROOT / "state"
TOKEN_FILE = "fyers_token.enc"
IST = timezone(timedelta(hours=5, minutes=30))
SECRET_NAMES = ("FYERS_APP_ID", "FYERS_SECRET_ID", "FYERS_PIN")      # needed for Fyers to be switched on at all
LOGIN_SECRET_NAMES = ("FYERS_USER_ID", "FYERS_TOTP_KEY")             # needed for the automatic daily login
MAX_LOGINS_PER_DAY = 6                                               # automatic attempts per day, successful or not
TOKEN_MAX_HOURS = 18                                                 # a saved day-pass older than this is not reused
TOTP_SAFE_SECONDS = 5                                                # a code with less time left is not used - wait for the next


class FyersError(Exception):
    """Something Fyers answered (or did not answer). `kind` tells the caller what to do about it."""

    def __init__(self, message, code=None, status=None, kind="other"):
        super().__init__(message)
        self.code, self.status, self.kind = code, status, kind


# ------------------------------------------------------------------------------------------ talking to Fyers
def _body(r) -> dict:
    try:
        b = r.json()
        return b if isinstance(b, dict) else {"s": "error", "message": str(b)[:160]}
    except Exception:                                           # noqa: BLE001
        return {"s": "error", "message": (getattr(r, "text", "") or f"HTTP {r.status_code}")[:160]}


class RequestsHttp:
    """The only place that really talks to the internet (tests replace it with a fake)."""

    def __init__(self):
        self._local = threading.local()

    def get(self, url, params=None, headers=None, timeout=20):
        # each thread keeps its own connection open: no new handshake per request, so requests that were sent evenly
        # also arrive evenly (Fyers counts them when they arrive)
        sess = getattr(self._local, "session", None)
        if sess is None:
            sess = self._local.session = requests.Session()
        r = sess.get(url, params=params, headers=headers, timeout=timeout)
        return r.status_code, _body(r)

    def new_login(self):
        """A login starts: the steps of one login share their cookies (like a browser does), nothing is kept from the last."""
        self._local.poster = requests.Session()

    def post(self, url, payload=None, headers=None, timeout=20, follow=True):
        """`follow=False`: do not walk to the address Fyers redirects to (the login step that hands out the code answers
        with a redirect; the code is in the address and in the answer's body)."""
        poster = getattr(self._local, "poster", None) or requests
        r = poster.post(url, json=payload, headers=headers, timeout=timeout, allow_redirects=follow)
        body = _body(r)
        where = r.headers.get("Location")
        if not follow and where and "Url" not in body:
            body["Url"] = where
        return r.status_code, body

    def text(self, url, timeout=60) -> str:
        r = requests.get(url, timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
        r.raise_for_status()
        return r.text


def classify(status, code, text) -> str:
    """What kind of answer is this? Only the kinds that stop a whole run (too fast, login) need care: a wrong guess
    would silence every other symbol, so messages about dates, ranges or expired contracts are never taken for them."""
    t = (text or "").lower()
    about_data = any(w in t for w in ("range", "date", "period", "duration", "resolution", "symbol", "contract", "expired"))
    if status == 429 or code in (-429, 429) or (not about_data and any(
            w in t for w in ("rate limit", "limit exceed", "too many", "request limit", "limit reached"))):
        return "rate"
    if status in (401, 403) or code in (-8, -15, -16, -17) or any(
            w in t for w in ("authenticate", "unauthor", "token expired", "token has expired", "invalid token", "access token")):
        return "auth"
    if code == -300 or ("symbol" in t and ("invalid" in t or "valid" in t)):
        return "invalid"
    return "other"


def raise_for(status, body) -> None:
    s = str(body.get("s", "")).lower()
    if s in ("ok", "no_data") and (status or 200) < 400:
        return
    msg = str(body.get("message") or body.get("msg") or f"HTTP {status}")[:160]
    code = body.get("code")
    raise FyersError(msg, code=code, status=status, kind=classify(status, code, msg))


# ------------------------------------------------------------------------------------------ credentials & login
def totp_secret(key: str) -> bytes:
    """The TOTP key as Fyers shows it (letters A-Z and digits 2-7, spaces and dashes allowed) -> bytes."""
    hint = "the secret FYERS_TOTP_KEY must be the long code Fyers shows under the QR picture (letters A-Z and digits 2-7)"
    k = re.sub(r"[\s=-]", "", str(key or "")).upper()
    if not k or re.search(r"[^A-Z2-7]", k):
        raise ValueError(hint)
    try:
        return base64.b32decode(k + "=" * (-len(k) % 8))
    except (binascii.Error, ValueError):
        raise ValueError(hint + " - it looks incomplete, copy all of it") from None


def totp_code(key: str, at: float, digits: int = 6, step: int = 30) -> str:
    """The 6-digit code an authenticator app would show at time `at` (seconds since 1970). RFC 6238 / RFC 4226, SHA-1."""
    mac = hmac.new(totp_secret(key), struct.pack(">Q", int(at // step)), hashlib.sha1).digest()
    offset = mac[-1] & 0x0F
    number = struct.unpack(">L", mac[offset:offset + 4])[0] & 0x7FFFFFFF
    return str(number % 10 ** digits).zfill(digits)


@dataclass
class Creds:
    app_id: str
    secret: str
    pin: str
    redirect: str = DEFAULT_REDIRECT
    user_id: str = ""                  # your Fyers client ID, like XY12345 (for the automatic login)
    totp_key: str = ""                 # the long code under the TOTP QR picture (for the automatic login)

    @classmethod
    def from_env(cls, env=None):
        env = os.environ if env is None else env
        a, s, p = (str(env.get(k, "")).strip() for k in SECRET_NAMES)
        if not (a and s and p):
            return None
        u, t = (str(env.get(k, "")).strip() for k in LOGIN_SECRET_NAMES)
        return cls(a, s, p, str(env.get("FYERS_REDIRECT_URI", "")).strip() or DEFAULT_REDIRECT, u.upper(), t)

    @property
    def app_hash(self) -> str:
        return hashlib.sha256(f"{self.app_id}:{self.secret}".encode()).hexdigest()

    @property
    def can_log_in(self) -> bool:
        """True when the automatic daily login has everything it needs."""
        return bool(self.user_id and self.totp_key)

    def missing_login_secrets(self) -> list:
        return [n for n, v in zip(LOGIN_SECRET_NAMES, (self.user_id, self.totp_key)) if not v]

    def login_problem(self) -> str:
        """A secret that cannot be right, found without asking Fyers anything ('' when nothing is wrong)."""
        try:
            totp_secret(self.totp_key)
        except ValueError as e:
            return str(e)
        if "@" in self.user_id or " " in self.user_id:
            return "the secret FYERS_USER_ID must be your Fyers client ID (like XY12345) - not an e-mail address"
        if not re.fullmatch(r".+-\d{3}", self.app_id):
            return "the secret FYERS_APP_ID should look like ABCD1234-100 (the app ID Fyers shows, with the dash and 3 digits)"
        return ""

    def fingerprint(self) -> str:
        """Changes when any secret the login uses is changed (so a refused login is tried again after you fix it)."""
        raw = "|".join((self.app_id, self.secret, self.pin, self.redirect, self.user_id, self.totp_key))
        return hashlib.sha256(raw.encode()).hexdigest()[:12]

    def login_url(self) -> str:
        q = urlencode({"client_id": self.app_id, "redirect_uri": self.redirect, "response_type": "code",
                       "state": "ema_scanner"})
        return f"{API}/generate-authcode?{q}"

    def cipher(self):
        from cryptography.fernet import Fernet
        key = hashlib.sha256(f"ema-scanner|{self.app_id}|{self.secret}|{self.pin}".encode()).digest()
        return Fernet(base64.urlsafe_b64encode(key))


def missing_secrets(env=None) -> list:
    env = os.environ if env is None else env
    return [k for k in SECRET_NAMES if not str(env.get(k, "")).strip()]


def missing_login_secrets(env=None) -> list:
    env = os.environ if env is None else env
    return [k for k in LOGIN_SECRET_NAMES if not str(env.get(k, "")).strip()]


def configured(env=None) -> bool:
    return not missing_secrets(env)


def parse_auth_code(text: str) -> str:
    """Accepts the whole address Fyers sent you to (…?s=ok&code=200&auth_code=eyJ…&state=…) or just the code."""
    t = (text or "").strip().strip("\"'")
    if "auth_code=" in t:
        q = parse_qs(urlparse(t).query)
        if q.get("auth_code"):
            return q["auth_code"][0].strip()
        m = re.search(r"auth_code=([^&\s#]+)", t)
        if m:
            return m.group(1)
    return t


def exchange_auth_code(creds: Creds, code: str, http) -> dict:
    status, body = http.post(f"{API}/validate-authcode",
                             {"grant_type": "authorization_code", "appIdHash": creds.app_hash, "code": code})
    raise_for(status, body)
    if not body.get("access_token"):
        raise FyersError("Fyers did not hand out an access token")
    return {"access_token": body["access_token"], "refresh_token": body.get("refresh_token") or ""}


class LoginError(Exception):
    """The automatic login did not work. `kind` says why: user / totp / pin / app = a secret is probably wrong, other =
    Fyers or the network hiccuped. `hold` = hours the scanner waits before it tries again by itself (inf = until tomorrow:
    a wrong PIN, repeated, can lock the account)."""

    HOLD = {"user": 1.0, "totp": 3.0, "app": 1.0, "pin": float("inf"), "other": 0.0}

    def __init__(self, message, kind="other", hold=None):
        super().__init__(message)
        self.kind = kind
        self.hold = self.HOLD.get(kind, 0.0) if hold is None else hold


LOGIN_WORDS = {            # what you are told when Fyers refuses a step ({said} = Fyers' own words)
    "user": "Fyers did not accept the user ID (secret FYERS_USER_ID) - Fyers said: {said}",
    "totp": ("Fyers did not accept the 6-digit TOTP code - check the secret FYERS_TOTP_KEY, and that TOTP is switched "
             "on in your Fyers account (Fyers said: {said})"),
    "pin": "Fyers did not accept the PIN (secret FYERS_PIN) - Fyers said: {said}",
    "app": ("Fyers would not hand out the app login - check the secrets FYERS_APP_ID, FYERS_SECRET_ID and "
            "FYERS_REDIRECT_URI (Fyers said: {said})"),
}


def _b64(text) -> str:
    return base64.b64encode(str(text).encode()).decode()


def _login_step(http, kind, url, payload, headers=None, follow=True, expect=(200,)) -> dict:
    """One request of the automatic login: Fyers' answer, or a LoginError that says which secret is probably wrong."""
    try:
        status, body = (http.post(url, payload, headers=headers) if follow
                        else http.post(url, payload, headers=headers, follow=False))
    except (requests.RequestException, ValueError) as e:
        raise LoginError(f"could not reach Fyers' login servers ({type(e).__name__})") from None
    if status == 429:
        raise LoginError("Fyers' login servers said 'too many requests'", hold=0.5)
    if (status or 0) >= 500:
        raise LoginError(f"Fyers' login servers are busy (HTTP {status})")
    said = str(body.get("message") or body.get("msg") or body.get("error") or f"HTTP {status}")[:120]
    if status not in expect or str(body.get("s", "")).lower() == "error":
        raise LoginError(LOGIN_WORDS[kind].format(said=said), kind)
    return body


def _log_in_once(creds: Creds, http, now, sleep) -> dict:
    first = _login_step(http, "user", f"{VAGATOR}/send_login_otp_v2", {"fy_id": _b64(creds.user_id), "app_id": "2"})
    key = first.get("request_key")
    if not key:
        raise LoginError(LOGIN_WORDS["user"].format(said="Fyers sent no request key"), "user")
    t = now().timestamp()                              # the code is made only now, as late as possible
    left = 30 - t % 30
    if left < TOTP_SAFE_SECONDS:                       # that code is about to run out: wait for the next one
        sleep(left + 0.5)
        t = now().timestamp()
    second = _login_step(http, "totp", f"{VAGATOR}/verify_otp",
                         {"request_key": key, "otp": totp_code(creds.totp_key, t)})
    key = second.get("request_key")
    if not key:
        raise LoginError(LOGIN_WORDS["totp"].format(said="Fyers sent no request key"), "totp")
    third = _login_step(http, "pin", f"{VAGATOR}/verify_pin_v2",
                        {"request_key": key, "identity_type": "pin", "identifier": _b64(creds.pin)})
    data = third.get("data")
    bearer = data.get("access_token") if isinstance(data, dict) else None
    if not bearer:
        raise LoginError(LOGIN_WORDS["pin"].format(said="Fyers sent no pass after the PIN"), "pin")
    fourth = _login_step(http, "app", f"{API}/token",
                         {"fyers_id": creds.user_id, "app_id": creds.app_id[:-4], "redirect_uri": creds.redirect,
                          "appType": creds.app_id[-3:], "code_challenge": "", "state": "ema_scanner", "scope": "",
                          "nonce": "", "response_type": "code", "create_cookie": True},
                         headers={"authorization": f"Bearer {bearer}", "content-type": "application/json; charset=UTF-8"},
                         follow=False, expect=(308, 302, 303, 307, 200))
    address = str(fourth.get("Url") or "")
    if "auth_code=" not in address:
        raise LoginError(LOGIN_WORDS["app"].format(said="no login code came back"), "app")
    try:
        return exchange_auth_code(creds, parse_auth_code(address), http)
    except FyersError as e:
        if (e.status or 0) >= 500 or e.kind == "rate":
            raise LoginError(f"Fyers' login servers are busy ({str(e)[:80]})", hold=0.5 if e.kind == "rate" else 0.0) from None
        raise LoginError(LOGIN_WORDS["app"].format(said=str(e)[:120]), "app") from None
    except (requests.RequestException, ValueError) as e:
        raise LoginError(f"could not reach Fyers' login servers ({type(e).__name__})") from None


def totp_login(creds: Creds, http, now=None, sleep=None) -> dict:
    """The whole automatic login, the way the Fyers app does it: user ID -> TOTP code -> PIN -> app login code -> day-pass.
    Returns {'access_token', 'refresh_token'}. A hiccup (network, Fyers busy) is tried once more; a refusal is not
    (the answer would be the same)."""
    now = now or (lambda: datetime.now(timezone.utc))
    sleeper = sleep or time.sleep
    if hasattr(http, "new_login"):
        http.new_login()
    try:
        return _log_in_once(creds, http, now, sleeper)
    except LoginError as e:
        if e.kind != "other" or e.hold:
            raise
    sleeper(3.0)
    return _log_in_once(creds, http, now, sleeper)


def _iso(t: datetime) -> str:
    return t.astimezone(timezone.utc).isoformat()


def _parse_iso(s):
    try:
        t = datetime.fromisoformat(str(s))
        return t if t.tzinfo else t.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return None


class TokenStore:
    """The saved login, encrypted with a key made from your secrets (it sits in the scanner's memory, not in the repo)."""

    def __init__(self, creds: Creds, path=None):
        self.creds = creds
        self.path = Path(path) if path else STATE_DIR / TOKEN_FILE
        self.problem = ""

    def load(self) -> dict:
        self.problem = ""
        if not self.path.exists():
            return {}
        try:
            from cryptography.fernet import InvalidToken
            try:
                return json.loads(self.creds.cipher().decrypt(self.path.read_bytes()).decode("utf-8"))
            except InvalidToken:
                self.problem = "the saved Fyers login cannot be read (the Fyers secrets were changed) - log in again"
        except Exception as e:                                  # noqa: BLE001
            self.problem = f"the saved Fyers login is unreadable ({str(e)[:60]}) - log in again"
        return {}

    def _write(self, data: dict) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_bytes(self.creds.cipher().encrypt(json.dumps(data).encode("utf-8")))
        os.replace(tmp, self.path)

    def save(self, **fields) -> None:
        data = self.load()
        data.update({k: v for k, v in fields.items() if v is not None})
        self._write(data)

    def drop(self, *keys) -> None:
        """Forgets these saved fields (when there is nothing saved, nothing is written)."""
        data = self.load()
        if any(k in data for k in keys):
            for k in keys:
                data.pop(k, None)
            self._write(data)


class Session:
    """Holds today's access token (the day-pass). A pass saved today is reused; otherwise the scanner logs in by itself
    (user ID + TOTP code + PIN). Without the two login secrets it can only say what is missing."""

    def __init__(self, creds: Creds, store: TokenStore, http, now=None, sleep=None):
        self.creds, self.store, self.http, self.sleep = creds, store, http, sleep
        self.now = now or (lambda: datetime.now(timezone.utc))
        self.token = ""
        self.problem = ""
        self.how = ""                    # "saved" = today's pass from an earlier run, "login" = logged in during this run
        self.since = None                # when the pass in use was made
        self._fresh = ""                 # the pass this run got from a login (if Fyers refuses it, logging in again is pointless)
        self._gave_up = False            # a login already failed in this run: nobody tries again
        self._lock = threading.Lock()

    # -- using what is saved
    def _saved_today(self, data: dict):
        at = _parse_iso(data.get("access_at"))
        if data.get("access_token") and at:
            same_day = at.astimezone(IST).date() == self.now().astimezone(IST).date()
            if same_day and (self.now() - at) < timedelta(hours=TOKEN_MAX_HOURS):
                return data["access_token"], at
        return "", None

    def start(self, force: bool = False, fresh: bool = False) -> bool:
        """Makes sure there is a pass for today. force = ignore the waiting times after a refused login (Check Setup, the
        login workflow: you are looking at the answer). fresh = do not reuse a saved pass, log in now."""
        with self._lock:
            data = self.store.load()
            if not fresh:
                token, at = self._saved_today(data)
                if token:
                    self.token, self.since, self.how, self.problem = token, at, "saved", ""
                    return True
            return self._log_in(data, force)

    def renew(self, failed_token: str = "") -> bool:
        """The pass stopped working (Fyers dropped it): log in again. `failed_token` = the pass that just failed, so the
        workers of one run log in only once."""
        with self._lock:
            if failed_token and self.token and self.token != failed_token:
                return True                                   # another worker has already logged in
            if self._gave_up:
                return False
            if failed_token and failed_token == self._fresh:
                self.problem = ("Fyers refuses the day-pass it handed out a moment ago, so another login would not help "
                                "(guide, Section 10)")
                self._gave_up = True
                return False
            return self._log_in(self.store.load(), False)

    # -- logging in
    def _held(self, data: dict, today: str) -> str:
        """Why the scanner must not try a login right now ('' = it may)."""
        until = _parse_iso(data.get("hold_until"))
        if until and self.now() < until and data.get("hold_fp") == self.creds.fingerprint():
            when = until.astimezone(IST).strftime("%d %b %H:%M")
            return (f"{data.get('hold_why') or 'the automatic Fyers login failed'} - the scanner waits until {when} IST "
                    f"before it tries again (run '4 - Fyers Login' to try now)")
        if data.get("login_day") == today and int(data.get("login_n") or 0) >= MAX_LOGINS_PER_DAY:
            return (f"the automatic Fyers login was tried {MAX_LOGINS_PER_DAY} times today - it waits until tomorrow "
                    f"(run '4 - Fyers Login' to try now)")
        return ""

    def _log_in(self, data: dict, force: bool) -> bool:
        c = self.creds
        if not c.can_log_in:
            names = " and ".join(c.missing_login_secrets())
            self.problem = (f"Fyers wants a new login every day and the scanner cannot do it yet - add the GitHub "
                            f"secret{'s' if len(c.missing_login_secrets()) > 1 else ''} {names} (guide, Step E), or log in "
                            f"by hand today with workflow '4 - Fyers Login'")
            return False
        bad = c.login_problem()
        if bad:
            self.problem = bad
            return False
        if self._gave_up and not force:
            return False
        today = self.now().astimezone(IST).date().isoformat()
        if not force:
            wait = self._held(data, today)
            if wait:
                self.problem, self._gave_up = wait, True
                return False
        tries = int(data.get("login_n") or 0) if data.get("login_day") == today else 0
        if not force:                                          # counted before Fyers is asked: a run that dies half way still counts
            self.store.save(login_day=today, login_n=tries + 1)
        try:
            tokens = totp_login(c, self.http, self.now, self.sleep)
        except LoginError as e:
            self._failed(e)
            return False
        now = self.now()
        self.store.save(access_token=tokens["access_token"], access_at=_iso(now), login_day=today,
                        login_n=0 if force else tries + 1)
        self.store.drop("hold_until", "hold_why", "hold_fp")
        self.token, self.since, self.how = tokens["access_token"], now, "login"
        self._fresh, self.problem, self._gave_up = self.token, "", False
        return True

    def _failed(self, e: LoginError) -> None:
        now = self.now()
        self._gave_up = True
        if e.hold == float("inf"):
            until = (now.astimezone(IST) + timedelta(days=1)).replace(hour=0, minute=1, second=0, microsecond=0)
            tail = "the scanner will not try again before tomorrow, because wrong PINs can lock the account"
        elif e.hold > 0:
            until = now + timedelta(hours=e.hold)
            tail = f"the scanner waits until {until.astimezone(IST).strftime('%H:%M')} IST before it tries again"
        else:
            until, tail = None, "the scanner tries again on its next run"
        if until is not None:
            self.store.save(hold_until=_iso(until), hold_why=f"the automatic Fyers login failed: {e}"[:300],
                            hold_fp=self.creds.fingerprint())
        else:
            self.store.drop("hold_until", "hold_why", "hold_fp")
        self.problem = f"{e} - {tail} (after a fix, run '4 - Fyers Login')"


# ------------------------------------------------------------------------------------------ pacing
class BudgetExhausted(Exception):
    """Today's request allowance is used up."""


class BudgetReserved(BudgetExhausted):
    """What is left of today's allowance is kept for MCX (it has no other source of prices)."""


class Limiter:
    """Never lets the scanner go faster than the limits (per second / minute / day), across threads.

    Requests are spread out evenly instead of being sent in bursts: Fyers counts a request when it ARRIVES, and four
    sent together can land as five or six inside one second (that is what "5 requests/second" refuses)."""

    def __init__(self, per_second, per_minute, per_day, used_today=0, clock=time.monotonic, sleep=time.sleep):
        self.per_second, self.per_minute, self.per_day = int(per_second), int(per_minute), int(per_day)
        self.used = int(used_today)
        self.gap = 1.05 / max(1, self.per_second)          # least time between two requests
        self._next = 0.0                                    # no request may start before this moment
        self._until = 0.0                                   # everyone waits until this moment (after a refusal)
        self._hits = deque()
        self._clock, self._sleep = clock, sleep
        self._lock = threading.Lock()

    def slow_down(self, factor: float = 1.5, longest: float = 2.0) -> None:
        """Fyers said we are going too fast: widen the gap for the rest of the run."""
        self.gap = min(self.gap * factor, longest)

    def pause(self, seconds: float) -> None:
        """Nobody sends anything for this long (every thread waits in acquire)."""
        self._until = max(self._until, self._clock() + float(seconds))

    def acquire(self, reserve: int = 0) -> None:
        """Waits for a free slot. `reserve` = how many of today's requests must stay untouched for others."""
        with self._lock:
            while True:
                if self.used >= self.per_day:
                    raise BudgetExhausted()
                if reserve and self.used >= self.per_day - reserve:
                    raise BudgetReserved()
                now = self._clock()
                while self._hits and now - self._hits[0] >= 60.0:
                    self._hits.popleft()
                wait = max(self._next - now, self._until - now, 0.0)
                if len(self._hits) >= self.per_minute:
                    wait = max(wait, self._hits[0] + 60.0 - now + 0.05)
                if wait <= 0:
                    self._hits.append(now)
                    self.used += 1
                    self._next = now + self.gap
                    return
                self._sleep(wait)


def rate_scope(text) -> str:
    """Which limit did Fyers say we broke? 'second', 'minute', 'day' - or '' when the message does not say."""
    t = (text or "").lower()
    for scope, words in (("second", ("/second", "per second", "/sec", "per sec", " second")),
                         ("minute", ("/minute", "per minute", "/min", "per min", " minute")),
                         ("day", ("/day", "per day", "daily", " day"))):
        if any(w in t for w in words):
            return scope
    return ""


MAX_SLOWDOWNS = 8                       # times Fyers may say "too fast" in one run before the run stops using it


# ------------------------------------------------------------------------------------------ symbol master
TICKER_RE = re.compile(r"^(NSE|BSE|MCX):[A-Z0-9&_\-]+$")
MCX_FUT_RE = re.compile(r"^MCX:([A-Z]+)(\d{2})([A-Z]{3})FUT$")
MONTHS = {m: i for i, m in enumerate(["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"], 1)}


def _norm(s: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(s).upper())


def _epoch_date(text):
    """'1795989000' -> the date (in India) that moment falls on; None when the text is not such a number."""
    try:
        v = float(str(text).strip())
    except ValueError:
        return None
    if not 1.4e9 < v < 2.6e9:
        return None
    return datetime.fromtimestamp(v, IST).date()


STALE_DAYS = 6                          # a contract whose newest candle is older than this has expired (or never traded)


class Master:
    """Fyers' public symbol lists (NSE_CM, BSE_CM, MCX_COM). Saved for a few days so most runs download nothing."""

    def __init__(self, fcfg, http, now=None, folder=None):
        self.fcfg, self.http = fcfg, http
        self.now = now or (lambda: datetime.now(timezone.utc))
        self.folder = Path(folder) if folder else STATE_DIR / "fyers"
        self._rows = {}
        self.notes = {}

    def rows(self, name):
        """Parsed rows (lists of text) or None when the list cannot be had."""
        if name in self._rows:
            return self._rows[name]
        path = self.folder / f"{name}.csv"
        days = float(self.fcfg.get("master_refresh_days", {}).get(name, 7))
        text, note = None, ""
        if path.exists() and (self.now().timestamp() - path.stat().st_mtime) < days * 86400:
            text, note = path.read_text(encoding="utf-8", errors="replace"), "saved copy"
        else:
            try:
                text = self.http.text(MASTER_URL.format(name=name))
                self.folder.mkdir(parents=True, exist_ok=True)
                path.write_text(text, encoding="utf-8")
                note = "downloaded"
            except Exception as e:                              # noqa: BLE001
                if path.exists():
                    text, note = path.read_text(encoding="utf-8", errors="replace"), f"download failed ({str(e)[:50]}) - old copy"
                else:
                    note = f"download failed ({str(e)[:70]})"
        rows = list(csv.reader(io.StringIO(text))) if text else None
        self.notes[name] = f"{name}: {note}" + (f", {len(rows)} rows" if rows else "")
        self._rows[name] = rows or None
        return self._rows[name]

    def ticker_col(self, name):
        rows = self.rows(name) or []
        width = max((len(r) for r in rows[:50]), default=0)
        best, best_n = None, 0
        for c in range(width):
            n = sum(1 for r in rows[:300] if len(r) > c and TICKER_RE.match(r[c].strip()))
            if n > best_n:
                best, best_n = c, n
        return best if best_n >= 5 else None

    def tickers(self, name):
        """{ticker: description} or None."""
        rows = self.rows(name)
        tc = self.ticker_col(name)
        if rows is None or tc is None:
            return None
        out = {}
        for r in rows:
            if len(r) > tc and TICKER_RE.match(r[tc].strip()):
                out[r[tc].strip()] = r[1].strip() if len(r) > 1 and tc != 1 else ""
        return out

    def mcx_expiries(self, name="MCX_COM"):
        """{futures ticker: last trading day} - read from whichever column holds dates that agree with the month in the
        contract code. {} when no such column exists (the month in the code is used instead)."""
        rows = self.rows(name)
        tc = self.ticker_col(name)
        if rows is None or tc is None:
            return {}
        futs = []
        for r in rows:
            m = MCX_FUT_RE.match(r[tc].strip()) if len(r) > tc else None
            if m and m.group(3) in MONTHS:
                futs.append((r, (2000 + int(m.group(2)), MONTHS[m.group(3)])))
        if not futs:
            return {}
        best, best_n = None, 0
        for c in range(max(len(r) for r, _ in futs)):
            if c == tc:
                continue
            n = 0
            for r, ym in futs:
                d = _epoch_date(r[c]) if len(r) > c else None
                n += 1 if d and (d.year, d.month) == ym else 0
            if n > best_n:
                best, best_n = c, n
        if best is None or best_n < 0.6 * len(futs):
            return {}
        out = {}
        for r, _ in futs:
            d = _epoch_date(r[best]) if len(r) > best else None
            if d:
                out[r[tc].strip()] = d
        return out


# ------------------------------------------------------------------------------------------ our symbol -> Fyers symbol
INDEX_CODES = {                         # how config.yaml names an index -> Fyers codes to try (first that exists wins)
    "^NSEI": ["NSE:NIFTY50-INDEX"], "^NSEBANK": ["NSE:NIFTYBANK-INDEX"], "^BSESN": ["BSE:SENSEX-INDEX"],
    "^NSMIDCP": ["NSE:NIFTYNXT50-INDEX", "NSE:NIFTYNEXT50-INDEX", "NSE:NIFTYJR-INDEX"], "^NSEMDCP50": ["NSE:NIFTYMIDCAP50-INDEX"],
    "^CRSLDX": ["NSE:NIFTY500-INDEX"], "^CNXIT": ["NSE:NIFTYIT-INDEX"], "^CNXAUTO": ["NSE:NIFTYAUTO-INDEX"],
    "^CNXPHARMA": ["NSE:NIFTYPHARMA-INDEX"], "^CNXFMCG": ["NSE:NIFTYFMCG-INDEX"], "^CNXMETAL": ["NSE:NIFTYMETAL-INDEX"],
    "^CNXREALTY": ["NSE:NIFTYREALTY-INDEX"], "^CNXENERGY": ["NSE:NIFTYENERGY-INDEX"],
    "^CNXINFRA": ["NSE:NIFTYINFRA-INDEX"], "^CNXPSUBANK": ["NSE:NIFTYPSUBANK-INDEX"],
    "^CNXMEDIA": ["NSE:NIFTYMEDIA-INDEX"], "^CNXFIN": ["NSE:FINNIFTY-INDEX", "NSE:NIFTYFINSERVICE-INDEX"],
    "^CNXPSE": ["NSE:NIFTYPSE-INDEX"], "^CNXCMDT": ["NSE:NIFTYCOMMODITIES-INDEX"],
    "^CNXSERVICE": ["NSE:NIFTYSERVSECTOR-INDEX", "NSE:NIFTYSERVICES-INDEX"], "^CNXMNC": ["NSE:NIFTYMNC-INDEX"],
    "NSE:CNX100": ["NSE:NIFTY100-INDEX"], "NSE:CNX200": ["NSE:NIFTY200-INDEX"],
    "NSE:CNXMIDCAP": ["NSE:NIFTYMIDCAP100-INDEX"], "NSE:CNXSMALLCAP": ["NSE:NIFTYSMLCAP100-INDEX"],
    "NSE:NIFTYMIDCAP150": ["NSE:NIFTYMIDCAP150-INDEX"], "NSE:NIFTYSMLCAP250": ["NSE:NIFTYSMLCAP250-INDEX"],
    "NSE:NIFTYPVTBANK": ["NSE:NIFTYPVTBANK-INDEX"], "NSE:CNXCONSUMPTION": ["NSE:NIFTYCONSUMPTION-INDEX"],
    "NSE:INDIAVIX": ["NSE:INDIAVIX-INDEX"],
}
EQUITY_SERIES = ("EQ", "BE", "BZ", "SM", "ST", "RR", "IV")        # RR = REITs, IV = InvITs


def _pick(cands, pool):
    """First candidate listed by Fyers; with no list available (None) the first guess is used."""
    if pool is None:
        return cands[0] if cands else ""
    return next((c for c in cands if c in pool), "")


def mcx_root(inst) -> str:
    hint = [h for h in (getattr(inst, "fyers_hint", None) or []) if h]
    if hint:
        return _norm(hint[0].split(":")[-1])
    m = re.match(r"^MCX:([A-Z0-9]+?)1!$", inst.symbol)
    return m.group(1) if m else ""


def front_contracts(pool) -> dict:
    """{root: [(year, month, ticker)] oldest first} for MCX futures in the master."""
    out = {}
    for t in pool or ():
        m = MCX_FUT_RE.match(t)
        if m and m.group(3) in MONTHS:
            out.setdefault(m.group(1), []).append((2000 + int(m.group(2)), MONTHS[m.group(3)], t))
    return {k: sorted(v) for k, v in out.items()}


def pick_contracts(chain, today, expiry, roll_days) -> list:
    """Contract codes that can still be traded, nearest first. chain = [(year, month, ticker)], oldest first.
    With the last trading days from the list the nearest contract that has not expired is used (and the next one
    once fewer than `roll_days` days are left); without them the month written in the code decides."""
    if not chain:
        return []
    if any(c[2] in expiry for c in chain):
        live = [c for c in chain if c[2] not in expiry or expiry[c[2]] >= today]
        if not live:
            return [chain[-1][2]]
        if len(live) > 1 and live[0][2] in expiry and (expiry[live[0][2]] - today).days < roll_days:
            live = live[1:]
        return [c[2] for c in live]
    live = [c for c in chain if (c[0], c[1]) >= (today.year, today.month)] or chain[-1:]
    if len(live) > 1 and (live[0][0], live[0][1]) == (today.year, today.month):
        last_day = datetime(today.year + (today.month == 12), today.month % 12 + 1, 1).date() - timedelta(days=1)
        if (last_day - today).days < roll_days:
            live = live[1:]
    return [c[2] for c in live]


def guess_contracts(root: str, today, months: int = 7) -> list:
    """Codes for the next few months, for when Fyers' symbol list could not be read. The feed tries them in turn and
    keeps the first one that has recent candles (not every commodity trades every month)."""
    out = []
    for k in range(months):
        y, m = today.year + (today.month - 1 + k) // 12, (today.month - 1 + k) % 12 + 1
        out.append(f"MCX:{root}{y % 100:02d}{list(MONTHS)[m - 1]}FUT")
    return out


def resolve(instruments, fcfg, master: Master, today=None) -> dict:
    """Sets `inst.fyers` for every Indian instrument Fyers can serve. Returns a report for Check Setup."""
    today = today or datetime.now(IST).date()
    report = {"mapped": 0, "missing": [], "notes": [], "mcx": {}, "guessed": [], "mcx_rows": 0, "mcx_sample": []}
    nse = master.tickers("NSE_CM") if any(i.market in ("NSE", "MCX") for i in instruments) else None
    bse = None
    mcx = None
    futs = {}
    expiry = {}
    if any(i.market == "MCX" for i in instruments):
        mcx = master.tickers("MCX_COM")
        futs = front_contracts(mcx)
        expiry = master.mcx_expiries("MCX_COM") if mcx else {}
        report["mcx_rows"] = len(mcx or ())
        report["mcx_sample"] = list(mcx or ())[:4]
    idx_by_norm = {}
    for t, desc in (nse or {}).items():
        if t.endswith("-INDEX"):
            idx_by_norm.setdefault(_norm(t.split(":")[1][:-6]), t)
            if desc:
                idx_by_norm.setdefault(_norm(desc), t)
    roll = int(fcfg.get("mcx_roll_days", 3))
    for i in instruments:
        i.fyers = ""
        if i.market == "NSE":
            if i.symbol.endswith(".NS"):
                base = i.symbol[:-3]
                i.fyers = _pick([f"NSE:{base}-{s}" for s in EQUITY_SERIES], nse)
            else:
                hints = list(getattr(i, "fyers_hint", None) or []) + INDEX_CODES.get(i.symbol, [])
                pool = nse
                if any(h.startswith("BSE:") for h in hints):
                    bse = bse if bse is not None else master.tickers("BSE_CM")
                    pool = {**(nse or {}), **(bse or {})} if (nse is not None or bse is not None) else None
                i.fyers = _pick(hints, pool)
                if not i.fyers and nse:
                    i.fyers = idx_by_norm.get(_norm(i.name)) or idx_by_norm.get(_norm(i.name).replace("NEXT", "NXT"), "")
        elif i.market == "MCX":
            root = mcx_root(i)
            chain = futs.get(root, [])
            i.fyers_alts = []
            if chain:
                # the nearest contract that has not expired; the ones after it are the feed's spare codes
                order = pick_contracts(chain, today, expiry, roll)
                i.fyers, i.fyers_alts = order[0], order[1:3]
                report["mcx"][i.name] = i.fyers
            elif mcx is None and root:
                # Fyers' list of commodity contracts could not be read: guess the month codes, the feed picks the right one
                order = guess_contracts(root, today)
                i.fyers, i.fyers_alts = order[0], order[1:]
                report["mcx"][i.name] = i.fyers
                report["guessed"].append(i.name)
        if i.fyers:
            report["mapped"] += 1
        elif i.market in ("NSE", "MCX"):
            report["missing"].append(i.name)
    report["notes"] = list(master.notes.values())
    return report


# ------------------------------------------------------------------------------------------ the data feed
def candles_to_frame(candles):
    rows = [c[:6] for c in candles if isinstance(c, (list, tuple)) and len(c) >= 5]
    if not rows:
        return None
    width = len(rows[0])
    names = ["t", "open", "high", "low", "close", "volume"][:width]
    df = pd.DataFrame([r[:width] for r in rows], columns=names)
    df.index = pd.DatetimeIndex(pd.to_datetime(df.pop("t"), unit="s", utc=True))
    return df


class FyersFeed:
    """fetch({our_symbol: fyers_symbol}, interval) -> ({our_symbol: DataFrame}, [our symbols without data])."""

    name = "fyers"

    def __init__(self, fcfg, plan, creds: Creds, session: Session, http, limiter: Limiter, now=None):
        self.fcfg, self.plan = fcfg, plan
        self.creds, self.session, self.http, self.limiter = creds, session, http, limiter
        self.now = now or (lambda: datetime.now(timezone.utc))
        self.skip = set(fcfg["limits"][plan].get("skip_intervals") or ())
        self.reserve = int(fcfg["limits"][plan].get("reserve_mcx", 0))      # requests kept back for MCX every day
        self.clock = time.monotonic
        self._deadline = None                                               # set when the first request is made
        self.down = ""
        self.invalid = set()
        self.reasons = {}
        self.events = []
        self.calls = 0
        self._started = False
        self._halt = ""
        self.report = None                 # how our symbols were matched to Fyers codes (Check Setup prints it)
        self.alts = {}                     # our symbol -> spare Fyers codes to try when the first has no recent candles
        self.picked = {}                   # our symbol -> the code that turned out to work today (kept for the day)
        self.switched = []                 # plain-English notes about codes that were replaced
        self.slowdowns = 0                 # times Fyers said "too fast" and the scanner waited and carried on
        self.rate_hits = {"second": 0, "minute": 0}
        self.only_mcx = False              # report on the free plan: Fyers serves the commodities only
        self._lock = threading.Lock()

    # -- state shared between runs (the daily call counter, the contract codes found today)
    def attach_state(self, state: dict) -> None:
        today = self.now().astimezone(IST).date().isoformat()
        s = state.get("fyers") or {}
        self.limiter.used = int(s.get("calls", 0)) if s.get("day") == today else 0
        saved = s.get("picked") if s.get("day") == today else None
        if isinstance(saved, dict):
            self.picked = {str(k): str(v) for k, v in saved.items() if v}

    def save_state(self, state: dict) -> None:
        state["fyers"] = {"day": self.now().astimezone(IST).date().isoformat(), "calls": self.limiter.used}
        if self.picked:
            state["fyers"]["picked"] = dict(self.picked)

    # -- availability
    def _start(self) -> bool:
        if not self._started:
            self._started = True
            if not self.session.start():
                self.down = self.session.problem or "not logged in"
        return not self.down

    def covers(self, interval: str) -> bool:
        return interval in RESOLUTION and interval not in self.skip and not self.down

    # -- one request
    def _spans(self, interval, long_daily):
        days = int(self.fcfg["history_days"][interval])
        n = 2 if (interval == "1d" and long_daily) else 1
        end, out = self.now(), []
        for _ in range(n):
            start = end - timedelta(days=days)
            out.append((start, end))
            end = start - timedelta(days=1)
        return out

    def _get(self, fsym, interval, a, b):
        params = {"symbol": fsym, "resolution": RESOLUTION[interval], "date_format": "0",
                  "range_from": str(int(a.timestamp())), "range_to": str(int(b.timestamp())), "cont_flag": "1"}
        token = self.session.token
        headers = {"Authorization": f"{self.creds.app_id}:{token}", "version": "3"}
        self.limiter.acquire(0 if fsym.startswith("MCX:") else self.reserve)
        with self._lock:
            self.calls += 1
        status, body = self.http.get(f"{DATA}/history", params, headers, float(self.fcfg.get("timeout_seconds", 20)))
        try:
            raise_for(status, body)
        except FyersError as e:
            e.token = token
            raise
        return body.get("candles") or []

    def _slow_down(self, e) -> float | None:
        """Fyers refused a request for going too fast. Returns how long everybody now waits before going on (and the
        pace is lowered), or None when waiting will not help - a daily limit, or it keeps happening."""
        scope = rate_scope(str(e))
        if scope == "day":
            return None
        key = "minute" if scope == "minute" else "second"
        with self._lock:
            self.rate_hits[key] += 1
            n = self.rate_hits[key]
            self.slowdowns += 1
        if key == "minute":
            if n > 1:                                   # Fyers blocks an account that breaks the minute limit 3 times
                return None
            wait = 62.0
        else:
            if n > MAX_SLOWDOWNS:
                return None
            wait = min(1.5 + n, 6.0)
            self.limiter.slow_down()
        self.limiter.pause(wait)
        return wait

    def _halt_run(self, why: str) -> None:
        with self._lock:
            if not self._halt:
                self._halt = why
                self.events.append(f"Fyers: {why} - the rest of this run uses TradingView (about 15 minutes late).")

    def _stale(self, df) -> bool:
        return (self.now() - df.index.max().to_pydatetime()).total_seconds() > STALE_DAYS * 86400

    def _one(self, our, fsym, interval, spans):
        """All candles for one symbol. Returns (our symbol, DataFrame or None, reason it failed).
        Symbols with spare codes (MCX contracts) try them in turn when a code is unknown, has no candles or has expired."""
        try:
            known = self.picked.get(our)
            if known:
                return self._collect(our, known, interval, spans)
            codes = [fsym] + [c for c in self.alts.get(our, ()) if c and c != fsym]
            res = (our, None, "no candles")
            for n, code in enumerate(codes):
                res = self._collect(our, code, interval, spans)
                last = n == len(codes) - 1
                if res[1] is not None and (last or not self._stale(res[1])):
                    if len(codes) > 1:
                        with self._lock:
                            self.picked[our] = code
                            self.invalid.discard(our)
                            if code != fsym:
                                self.switched.append(f"{our}: {fsym} has no recent candles - using {code}")
                    return res
                if res[1] is None and not (our in self.invalid or res[2] == "no candles"):
                    break                       # a halt, a login problem, a network error: another code would not help
            return res
        except Exception as e:                                  # noqa: BLE001
            return our, None, f"error: {str(e)[:80]}"

    def _collect(self, our, fsym, interval, spans):
        retries = int(self.fcfg.get("retries", 1))
        frames = []

        def merged():
            df = pd.concat(frames)
            return df[~df.index.duplicated(keep="last")].sort_index()

        def fail(n, why):
            """The newest chunk failing fails the symbol; an older chunk failing only means less history."""
            return (our, merged(), "") if (n > 0 and frames) else (our, None, why)

        for n, (a, b) in enumerate(spans):
            attempt, reauthed, last, candles, refused = 0, False, None, [], 0
            while True:
                if self._halt:
                    return fail(n, self._halt)
                if self._deadline is not None and self.clock() > self._deadline:
                    self._halt_run(f"this run's time allowance ({int(self.fcfg.get('max_seconds', 1100))} seconds) is used up")
                    return fail(n, "time limit")
                try:
                    candles, last = self._get(fsym, interval, a, b), None
                    break
                except BudgetReserved:
                    return fail(n, "daily limit (the rest is kept for MCX)")           # this symbol only; MCX carries on
                except BudgetExhausted:
                    self._halt_run(f"today's request allowance is used up ({self.limiter.used} of {self.limiter.per_day})")
                    return fail(n, "daily limit")
                except FyersError as e:
                    last = e
                    if e.kind == "rate":
                        refused += 1
                        if refused > 3 or self._slow_down(e) is None:
                            self._halt_run(f"Fyers said we are going too fast ({e})")
                            return fail(n, "rate limit")
                        continue                                # everybody waits a little, then the same request again
                    if e.kind == "auth":
                        if reauthed or not self.session.renew(getattr(e, "token", "")):
                            self._halt_run(f"login problem - {self.session.problem or e}")
                            self.down = self.session.problem or str(e)
                            return fail(n, "login")
                        reauthed = True
                        continue                                # same request again with the renewed token
                    if e.kind == "invalid":
                        if n == 0:
                            self.invalid.add(our)
                        return fail(n, str(e))
                except (requests.RequestException, ValueError) as e:
                    last = FyersError(f"network: {str(e)[:70]}", kind="net")
                attempt += 1
                if attempt > retries:
                    break
                time.sleep(0.5 * attempt)
            if last is not None:
                return fail(n, str(last))
            f = candles_to_frame(candles)
            if f is not None:
                frames.append(f)
        if not frames:
            return our, None, "no candles"
        return our, merged(), ""

    def fetch(self, symbols: dict, interval: str, long_daily: bool = False):
        out, failed = {}, []
        if not symbols or not self._start() or interval not in RESOLUTION:
            return out, list(symbols)
        if self._deadline is None:
            self._deadline = self.clock() + float(self.fcfg.get("max_seconds", 1100))
        spans = self._spans(interval, long_daily)
        workers = max(1, int(self.fcfg.get("workers", 4)))
        jobs = list(symbols.items())
        with ThreadPoolExecutor(max_workers=workers) as pool:
            for our, df, why in pool.map(lambda kv: self._one(kv[0], kv[1], interval, spans), jobs):
                if df is not None:
                    out[our] = df
                else:
                    failed.append(our)
                    self.reasons[our] = why
        if self._halt and not self.down:
            self.down = self._halt
        return out, failed


# ------------------------------------------------------------------------------------------ set-up
def setup(cfg, instruments, purpose="scan", http=None, env=None, now=None, master=None, limiter=None):
    """Returns a FyersFeed (and sets `inst.fyers` on the Indian instruments), or None when Fyers is not in use."""
    creds = Creds.from_env(env)
    fcfg = cfg.get("fyers") or {}
    if creds is None or not instruments or fcfg.get("enabled") is False:
        return None
    plan = fcfg.get("plan", "standard")
    if purpose == "backtest":
        return None
    only_mcx = purpose == "report" and plan != "prime"       # an end-of-day report does not need real-time NSE prices,
    if only_mcx and not any(i.market == "MCX" for i in instruments):      # but MCX has no other source of prices
        return None
    http = http or RequestsHttp()
    master = master or Master(fcfg, http, now=now)
    lim = fcfg["limits"][plan]
    report = resolve([i for i in instruments if i.market == "MCX"] if only_mcx else instruments, fcfg, master)
    skip = set(lim.get("skip_intervals") or ())
    for i in instruments:
        if i.market == "MCX" and i.fyers:                    # candles the plan cannot serve do not exist for MCX at all
            i.tfs = {tf for tf in i.tfs if BASE_INTERVAL[tf] not in skip}
    limiter = limiter or Limiter(lim["per_second"], lim["per_minute"], lim["per_day"])
    session = Session(creds, TokenStore(creds), http, now=now)
    feed = FyersFeed(fcfg, plan, creds, session, http, limiter, now=now)
    feed.report = report
    feed.only_mcx = only_mcx
    feed.alts = {i.symbol: list(i.fyers_alts) for i in instruments if i.fyers and getattr(i, "fyers_alts", None)}
    return feed


def estimate_daily_calls(instruments, cfg) -> dict:
    """Rough number of history requests per trading day for the current lists (for Check Setup)."""
    fcfg = cfg["fyers"]
    skip = set(fcfg["limits"][fcfg["plan"]].get("skip_intervals") or ())
    per = {"NSE": {"15m": 25, "1h": 7, "1d": 1.2}, "MCX": {"15m": 58, "1h": 15, "1d": 1.2}}
    need = {BASE_INTERVAL[t] for t in cfg["timeframes"]}
    n = {"NSE": 0, "MCX": 0}
    for i in instruments:
        if getattr(i, "fyers", "") and i.market in n:
            n[i.market] += 1
    total = {itv: sum(n[m] * per[m][itv] for m in n) for itv in ("15m", "1h", "1d") if itv in need}
    return {"symbols": n, "per_interval": total, "skipped": sorted(skip & need),
            "total": int(sum(v for k, v in total.items() if k not in skip))}
