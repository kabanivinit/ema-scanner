"""Commands:  scan | report | doctor | test-telegram | backtest"""
from __future__ import annotations

import argparse
import logging
import os
import re
import sys
import time
from datetime import datetime, timezone

import pandas as pd

from . import __version__, alerts
from . import backtest as backtest_mod
from . import fyers as fyers_mod
from . import backtest_report as bt_report
from . import bars as bars_mod
from . import report as report_mod
from .config import ROOT, ConfigError, load_config
from .data import Fetcher, make_fetcher
from .engine import collect, evaluate, make_batches, market_tfs, scan_once
from .fmt import bar_label
from .markets import BASE_INTERVAL, MARKETS, expected_latest_end, settle_for
from .state import STATE_FORMAT, is_sent, load_state, mark_sent, prune, save_state
from .telegram import ConsoleSender, Telegram
from . import tv as tv_mod
from .universe import build

log = logging.getLogger("scanner")
PAUSE = 1.1          # seconds between Telegram messages (Telegram allows ~1/sec per chat)


def _now(args) -> pd.Timestamp:
    if getattr(args, "now", None):
        t = pd.Timestamp(args.now)
        return t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")
    return pd.Timestamp.now(tz="UTC")


def _only(args):
    return set(args.only.split(",")) if getattr(args, "only", None) else None


def _sender(args):
    if args.dry_run:
        return ConsoleSender()
    tg = Telegram.from_env()
    if tg is None:
        log.error("Telegram is not set up: add the secrets TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID "
                  "(GitHub > Settings > Secrets and variables > Actions). See section 4 of the guide.")
    return tg


def _feeds_text(cfg, fetcher) -> str:
    """One plain sentence for the first Telegram message: where the prices come from."""
    fy = getattr(fetcher, "fy", None)
    if fy is None:
        return "TradingView (Indian and US stocks about 15 minutes late, crypto live)"
    text = "Fyers (real time) for Indian stocks, indices and commodities · TradingView for US stocks (about 15 min late) and crypto (live)"
    late = sorted(fy.skip & {BASE_INTERVAL[t] for t in cfg["timeframes"]})
    if late:
        text += (f". On the free Fyers plan the {', '.join(late)} candles of Indian stocks and indices still come from "
                 f"TradingView, about 15 minutes late (commodities have no {', '.join(late)} candles on the free plan)")
    return text


FAST_MARKETS = ("CRYPTO", "US", "FUT")          # live or quick feeds


def _market_groups(instruments, fetcher) -> list:
    """Which markets are scanned (and announced) together.
    On Fyers' free plan the Indian markets are fetched slowly (about 40 symbols a minute, so a full round takes ~13 minutes).
    Crypto and US stocks are handled first and announced at once, so a slow Indian round never holds their alerts back.
    In every other case everything is one group, so each timeframe gets exactly one message."""
    present = {i.market for i in instruments}
    fy = getattr(fetcher, "fy", None)
    if fy is None or getattr(fy, "plan", "") != "standard":
        return [sorted(present)]
    fast = [m for m in FAST_MARKETS if m in present]
    slow = sorted(present - set(FAST_MARKETS))
    return [g for g in (fast, slow) if g]


def _advance(state, outcome, batches, delivered) -> None:
    """A timeframe moves on only when its message(s) were delivered; otherwise the next run tries again."""
    for batch in batches:
        if batch.tf in delivered:
            for key in batch.keys:
                state["checkpoints"][key] = outcome.checkpoints[key]
    for key, value in outcome.checkpoints.items():
        if not any(key in b.keys for b in batches):
            state["checkpoints"][key] = value


def cmd_scan(args, cfg) -> int:
    now = _now(args)
    sender = _sender(args)
    if sender is None:
        return 2
    state_path = os.environ.get("SCANNER_STATE")
    state = load_state(state_path)
    upgraded = state["created"] is not None and state.get("format") != STATE_FORMAT
    if upgraded:
        log.info("The saved alert memory comes from an older scanner version - starting fresh, silently "
                 "(its old alerts would only arrive late).")
        state["checkpoints"], state["sent"], state["last_run"] = {}, {}, None
    bootstrap = state["created"] is None or upgraded
    previous_run = None if bootstrap else state.get("last_run")      # when the scanner last ran
    instruments, notes = build(cfg, _only(args))
    if not instruments:
        sender.send(alerts.health_message([f"{k}: {v}" for k, v in notes.items()] or ["no symbols loaded"]))
        log.error("No symbols could be loaded: %s", notes)
        return 2

    fetcher = make_fetcher(cfg, instruments)
    if hasattr(fetcher, "attach_state"):
        fetcher.attach_state(state)                          # remembers how many Fyers requests today's runs already used

    pause = 0 if args.dry_run else PAUSE
    send_failed = False
    sent_n = msgs_n = evaluated = new_n = 0
    problems, skipped, rounds = [], [], []

    def checkpoint_progress():
        if hasattr(fetcher, "save_state"):
            fetcher.save_state(state)
        state["last_run"] = now.isoformat()
        prune(state, now, cfg)
        if not args.dry_run:
            save_state(state, state_path)

    for group in _market_groups(instruments, fetcher):
        subset = [i for i in instruments if i.market in group]
        outcome = scan_once(cfg, subset, state, now, fetcher)
        fresh = [s for s in outcome.signals if not is_sent(state, s)]
        batches = make_batches(outcome, subset, cfg, fresh, previous_run, now)
        problems += outcome.health
        skipped += outcome.skipped
        evaluated += len(outcome.collected.results)
        new_n += len(fresh)
        if bootstrap:
            rounds.append((outcome, batches, fresh))         # recorded silently below, after the "scanner is live" message
            continue
        delivered = set()                                    # timeframes whose message(s) reached Telegram
        for batch in batches:
            ok = True
            for msg in alerts.build_tf_messages(batch, cfg):
                if sender.send(msg.text):
                    for s in msg.signals:
                        mark_sent(state, s)
                    sent_n += len(msg.signals)
                    msgs_n += 1
                else:
                    ok = False
                    log.error("Telegram send failed: %s", getattr(sender, "last_error", ""))
                time.sleep(pause)
            if ok:
                delivered.add(batch.tf)
            else:
                send_failed = True
        _advance(state, outcome, batches, delivered)
        checkpoint_progress()                                # this group's progress is kept even if a later group runs long
    log.info("Evaluated %d results; %d new crossover(s)", evaluated, new_n)

    if bootstrap:
        if not sender.send(alerts.live_message(cfg, instruments, notes, _feeds_text(cfg, fetcher))):
            log.error("Could not send the first Telegram message: %s", getattr(sender, "last_error", ""))
            return 1
        for outcome, batches, fresh in rounds:
            for s in fresh:
                mark_sent(state, s)
            _advance(state, outcome, batches, {b.tf for b in batches})
        state["created"] = now.isoformat()
        state["format"] = STATE_FORMAT

    problems += [f"{k}: {v}" for k, v in notes.items() if v.startswith("FAILED")] + list(getattr(fetcher, "events", []))
    gap = float(cfg["alerts"]["health_alert_hours"]) * 3600
    if problems and now.timestamp() - state["health_last"] > gap:
        if sender.send(alerts.health_message(problems)):
            state["health_last"] = now.timestamp()
    if send_failed:
        log.warning("Some messages could not be delivered - they will be retried on the next run.")
    checkpoint_progress()
    log.info("Done: %d message(s) sent, %d crossover(s)%s. Skipped (not ready): %s. Candles from: %s", msgs_n, sent_n,
             " (first run: baseline recorded)" if bootstrap else "", skipped or "none", getattr(fetcher, "served", {}))
    return 1 if send_failed else 0


def cmd_report(args, cfg) -> int:
    now = _now(args)
    instruments, notes = build(cfg, _only(args))
    if not instruments:
        log.error("No symbols could be loaded: %s", notes)
        return 2
    wanted = {m: market_tfs(cfg, instruments, m) for m in sorted({i.market for i in instruments})}
    coll = collect(cfg, instruments, wanted, now, make_fetcher(cfg, instruments, purpose="report"))
    md, df = report_mod.build_report(coll, instruments, cfg, now, notes)

    out = ROOT / "reports"
    (out / "archive").mkdir(parents=True, exist_ok=True)
    day = now.tz_convert(cfg["display_timezone"]).strftime("%Y-%m-%d")
    (out / "latest.md").write_text(md, encoding="utf-8")
    (out / "archive" / f"{day}.md").write_text(md, encoding="utf-8")
    df.to_csv(out / "latest.csv", index=False)
    log.info("Report written: %s (%d rows in CSV)", out / "latest.md", len(df))

    if not args.no_telegram:
        sender = _sender(args)
        if sender is None:
            return 2
        sender.send(report_mod.summary_text(coll, cfg, now, notes))
        sender.send_document(str(out / "latest.md"), "EMA crossover report (Markdown)")
        sender.send_document(str(out / "latest.csv"), "Full data (open in Excel)")
    return 0


def cmd_backtest(args, cfg) -> int:
    """Replays the crossover rule over history on every timeframe and says which timeframe worked best."""
    now = _now(args)
    bt = cfg["backtest"]
    try:
        years = float(args.years) if args.years else float(bt["years"])
    except ValueError:
        log.error("--years must be a number such as 3")
        return 2
    if not 0.25 <= years <= 10:
        log.error("--years must be between 0.25 and 10")
        return 2
    sender = None
    if not args.no_telegram:
        sender = _sender(args)
        if sender is None:
            return 2
    instruments, notes = build(cfg, _only(args), purpose="backtest")
    if not instruments:
        log.error("No symbols could be loaded: %s", notes)
        return 2
    if args.limit:
        instruments = backtest_mod.limit_instruments(instruments, cfg, int(args.limit))
    tfs = list(bt.get("timeframes") or cfg["timeframes"])
    fcfg = backtest_mod.fetch_cfg(cfg)
    fetcher = make_fetcher(fcfg, instruments, purpose="backtest")
    out = ROOT / "reports" / "backtest"
    out.mkdir(parents=True, exist_ok=True)
    log.info("Backtest of EMA %d/%d: %d securities, timeframes %s, last %g years", cfg["ema"]["short"],
             cfg["ema"]["long"], len(instruments), ", ".join(tfs), years)

    def save_partial(rows):                       # a crash or a time-out later on still leaves the work done so far
        bt_report.results_frame(rows).round(4).to_csv(out / "results.csv", index=False)

    rows = backtest_mod.run_backtest(fcfg, instruments, now, fetcher, years, tfs, on_chunk=save_partial)
    df = bt_report.results_frame(rows)
    bests = bt_report.best_per_security(df, bt)
    groups = bt_report.analyse(df, bests, instruments, cfg, tfs)
    skipped = int((df["status"] != "ok").sum())
    md = bt_report.build_markdown(df, bests, groups, instruments, cfg, now, years, tfs, skipped)
    day = now.tz_convert(cfg["display_timezone"]).strftime("%Y-%m-%d")
    paths = bt_report.write_files(out, md, df, bests, day)
    text = bt_report.summary_text(groups, cfg, now, years, tfs, skipped)
    log.info("Backtest finished. Files are in %s\n%s", out, re.sub(r"<[^>]+>", "", text).replace("&amp;", "&"))
    served = getattr(fetcher, "served", {})
    log.info("Candle sets delivered: %s", served)

    failed = False
    if sender is not None:
        failed = not sender.send(text)
        if not failed:
            sender.send_document(str(paths["best"]), "Best timeframe for each security (open in Excel)")
            sender.send_document(str(paths["md"]), "Full backtest report (Markdown)")
        else:
            log.error("Telegram send failed: %s", getattr(sender, "last_error", ""))
    return 1 if failed else 0


def cmd_test_telegram(args, cfg) -> int:
    sender = _sender(args)
    if sender is None:
        return 2
    ok = sender.send(f"✅ <b>Telegram connected</b>\nEMA {cfg['ema']['short']}/{cfg['ema']['long']} scanner "
                     f"v{__version__} can reach this chat.")
    if not ok:
        log.error("Telegram rejected the message: %s", getattr(sender, "last_error", ""))
        return 1
    log.info("Test message sent.")
    return 0


def _fmt_time(t, tz):
    return t.tz_convert(tz).strftime("%d %b %H:%M %Z")


def _check_feed(name, fetcher, cfg, instruments, now, say, fail, backup):
    """Is this data source reachable, current, and does it know our symbols? (`fail` = level used for problems.)"""
    tz = cfg["display_timezone"]
    tag = f"{name} (backup)" if (backup and name == "Yahoo") else name
    probe_tf = {"15m": "15m", "1h": "1h", "1d": "1d"}
    markets = sorted({i.market for i in instruments})
    for market in markets:
        m = MARKETS[market]
        if name == "Yahoo" and (":" in m.benchmark):
            continue                                            # MCX contracts do not exist on Yahoo
        for itv, tf in probe_tf.items():
            data, _ = fetcher([m.benchmark], itv)
            df = data.get(m.benchmark)
            if df is None:
                note = ""
                if name == "TradingView" and getattr(fetcher.tv, "down", ""):
                    note = f" ({fetcher.tv.down})"
                say(fail, f"{tag}: no {itv} candles for {market} benchmark {m.benchmark}{note}")
                continue
            settle = settle_for(cfg if name == "TradingView" else dict(cfg, data_source="yahoo"), market, tf)
            frame = bars_mod.frame_for(tf, df, m)
            closed = bars_mod.closed_only(frame, now, settle)
            exp = expected_latest_end(m, tf, now, settle)
            if closed.empty:
                say("WARN", f"{tag} {market} {itv}: {len(df)} candles but none closed yet")
                continue
            last = closed["end"].max()
            ok = last >= exp
            say("PASS" if ok else "WARN",
                f"{tag} {market} {itv}: {len(df)} candles · newest usable candle ended {_fmt_time(last, tz)}"
                f" · expected {_fmt_time(exp, tz)}"
                + ("" if ok else "  (normal on weekends/holidays or while the feed catches up)"))
            if itv == "1d" and name == "TradingView":           # day candles must be stamped on the right calendar day
                d = bars_mod.daily_bars(df, m)
                if not d.empty:
                    lab = d["_label"].iloc[-1].strftime("%d %b")
                    st = _fmt_time(d["start"].iloc[-1], m.tz)
                    say("INFO", f"{market} newest day candle is labelled {lab} (starts {st}) - the label must be a "
                                f"trading day of that exchange")
    if name == "TradingView" and getattr(fetcher, "tv", None) is not None and not fetcher.tv.down:
        _check_delays(fetcher, cfg, markets, say)
    sample = _sample(instruments, 25)
    if name == "Yahoo":
        sample = [i for i in sample if ":" not in i.symbol]
    if sample:
        got, failed = fetcher([i.symbol for i in sample], "1d")
        invalid = set(getattr(fetcher, "invalid", ()) or ())
        unknown = [i for i in sample if i.symbol in invalid]
        testable = len(sample) - len(unknown)                 # codes the feed rejects are a separate problem
        ok = testable > 0 and len(got) >= 0.8 * testable
        level = "PASS" if ok else fail
        extra = f" (missing: {', '.join(failed[:8])})" if failed else ""
        if name == "TradingView" and unknown:
            extra += f" · TradingView does not recognise: {', '.join(sorted(i.symbol for i in unknown)[:8])}"
            replies = sorted(set(getattr(getattr(fetcher, "tv", None), "reasons", {}).values()))[:2]
            if replies:
                extra += f" (its reply: {'; '.join(replies)})"
            if ok and any(not i.optional for i in unknown):
                level = "WARN"
        say(level, f"{tag} sample test: data for {len(got)} of {len(sample)} spread-out symbols" + extra)
        return ok
    return None


def _sample(instruments, n):
    by_market = {}
    for i in instruments:
        by_market.setdefault(i.market, []).append(i)
    per = max(2, n // max(1, len(by_market)))
    out = []
    for items in by_market.values():
        step = max(1, len(items) // per)
        out += items[::step][:per]
    return out[:n + 5]


def _check_delays(fetcher, cfg, markets, say):
    """Asks TradingView how delayed each market's data is and compares it with feed_delay_minutes."""
    names = {}
    for market in markets:
        b = MARKETS[market].benchmark
        cand = fetcher.tv.cands.get(b)
        if cand:
            names[market] = cand[0]
    if not names:
        return
    try:
        modes = fetcher.tv.quote_modes(list(names.values()))
    except Exception as e:                                          # noqa: BLE001
        say("INFO", f"Could not ask TradingView about data delays ({str(e)[:80]})")
        return
    for market, sym in names.items():
        mode = (modes.get(sym) or {}).get("update_mode")
        delay = tv_mod.delay_minutes(mode)
        assumed = cfg["feed_delay_minutes"]["tradingview"].get(market, 0)
        if delay is None:
            say("INFO", f"{market}: TradingView did not report a delay mode (answer: {mode}); config assumes {assumed} min")
        elif delay == assumed:
            say("PASS", f"{market}: TradingView data mode '{mode}' = {delay} min delay (matches config)")
        else:
            say("WARN", f"{market}: TradingView data mode '{mode}' = {delay} min delay, but config.yaml assumes {assumed} "
                        f"min. Set feed_delay_minutes -> tradingview -> {market}: {delay}")


def _login_link_message(creds) -> str:
    url = html_escape(creds.login_url())
    return ("🔑 <b>Fyers login by hand</b> (good for today only)\n"
            f"1. Open <a href=\"{url}\">this link</a> and log in to Fyers.\n"
            "2. You land on a page that may look empty or show an error - that is fine.\n"
            "3. Copy the full web address from the browser's address bar.\n"
            "4. Actions tab → <b>4 - Fyers Login</b> → Run workflow → paste that address into the box.\n"
            "To stop doing this every day, add the GitHub secrets FYERS_USER_ID and FYERS_TOTP_KEY (guide, Step E): "
            "the scanner then logs in by itself.")


def html_escape(text: str) -> str:
    import html
    return html.escape(text, quote=True)


def _check_fyers(cfg, instruments, now, say, tg=None):
    """Check Setup for Fyers: secrets, symbol codes, login, real candles, daily request budget. Returns the feed or None."""
    tz = cfg["display_timezone"]
    creds = fyers_mod.Creds.from_env()
    if creds is None:
        say("INFO", "Fyers is NOT set up (missing secrets: " + ", ".join(fyers_mod.missing_secrets()) + "). Indian prices "
                    "come from TradingView, about 15 minutes late. Setup steps: guide, section 'Fyers'.")
        return None
    if (cfg.get("fyers") or {}).get("enabled") is False:
        say("INFO", "Fyers is switched off in config.yaml (fyers -> enabled: false).")
        return None
    fcfg = cfg["fyers"]
    lim = fcfg["limits"][fcfg["plan"]]
    say("INFO", f"Fyers plan: {fcfg['plan']} (change it with the GitHub secret FYERS_PLAN = standard or prime) · pace "
                f"{lim['per_minute']} requests/minute, {lim['per_day']}/day"
                + (f" · {', '.join(lim['skip_intervals'])} candles stay on TradingView" if lim.get("skip_intervals") else ""))
    feed = fyers_mod.setup(cfg, instruments, "doctor")
    rep = getattr(feed, "report", None) or {}
    indian = [i for i in instruments if i.market in ("NSE", "MCX")]
    mapped = [i for i in indian if i.fyers]
    for note in rep.get("notes", []):
        say("INFO", f"Fyers symbol list - {note}")
    say("PASS" if indian and len(mapped) >= 0.9 * len(indian) else "WARN",
        f"Fyers codes found for {len(mapped)} of {len(indian)} Indian symbols"
        + (f" · not found: {', '.join(rep.get('missing', [])[:10])}{' …' if len(rep.get('missing', [])) > 10 else ''}"
           if rep.get("missing") else ""))
    if any(i.market == "MCX" for i in indian) and not rep.get("mcx"):
        say("WARN", f"No Fyers contract code was found for any commodity (the list had {rep.get('mcx_rows', 0)} usable entries"
                    + (f"; first ones: {', '.join(rep['mcx_sample'])}" if rep.get("mcx_sample") else "")
                    + "). Commodities will use TradingView, about 15 minutes late, or have no data.")
    ok = feed.session.start(force=True) if feed else False
    if feed is not None:
        feed._started = True                          # the login was just checked; the sample reads below reuse it
    if not ok:
        say("FAIL", f"Fyers login: {feed.session.problem if feed else 'could not start'}")
        if creds.can_log_in:
            say("INFO", "Fix the secret named above (Settings → Secrets and variables → Actions), then run '0 - Check Setup' "
                        "again. '4 - Fyers Login' (box left empty) tests the automatic login on its own.")
        else:
            say("INFO", "To log in by hand for today: Actions tab → '4 - Fyers Login' → Run workflow with the box left empty - "
                        "the login link arrives on Telegram (it is never printed here because this log is public)."
                        + (" A link was also just sent to your Telegram." if tg else ""))
            if tg:
                tg.send(_login_link_message(creds))
        return feed
    session = feed.session
    if session.how == "login":
        say("PASS", "Fyers login works · the scanner logged in by itself just now (user ID + TOTP code + PIN)")
    else:
        since = pd.Timestamp(session.since).tz_convert(tz).strftime("%d %b %H:%M %Z") if session.since is not None else "earlier"
        say("PASS", f"Fyers login works · today's saved login, made {since}")
    if not creds.can_log_in:
        say("WARN", f"The automatic daily login is NOT set up (missing secrets: {', '.join(creds.missing_login_secrets())}) - "
                    f"today's login was made by hand and ends tonight; Fyers needs a new one every day (guide, Step E).")
    sample = []
    bench = next((i for i in indian if i.symbol == "^NSEI" and i.fyers), None)
    stocks = [i for i in indian if i.symbol.endswith(".NS") and i.fyers][:4]
    mcx_all = [i for i in indian if i.market == "MCX" and i.fyers]
    mcx = mcx_all[0] if mcx_all else None
    for i in [bench] + stocks[:1] + [mcx]:
        if i is not None:
            sample.append(i)
    for i in sample:
        for itv in ("15m", "1h", "1d"):
            got, failed = feed.fetch({i.symbol: i.fyers}, itv)
            df = got.get(i.symbol)
            if df is None:
                say("FAIL", f"Fyers {i.name} ({i.fyers}) {itv}: no candles - {feed.reasons.get(i.symbol, 'no reason given')}")
                continue
            last = df.index.max().tz_convert(tz).strftime("%d %b %H:%M %Z")
            say("PASS", f"Fyers {i.name} ({i.fyers}) {itv}: {len(df)} candles · newest candle starts {last}")
    more = stocks[1:]                                          # a few more shares: one hourly request each
    bad = []
    for i in more:
        got, _ = feed.fetch({i.symbol: i.fyers}, "1h")
        if i.symbol not in got:
            bad.append(f"{i.name} ({feed.reasons.get(i.symbol, 'no reason given')})")
    if more:
        say("WARN" if bad else "PASS", f"Fyers hourly candles for {len(more) - len(bad)} of {len(more)} more shares"
                                        + (f" · missing: {'; '.join(bad)}" if bad else ""))
    if bench is not None:                                       # the weekly view needs two years of day candles = two requests
        got, _ = feed.fetch({bench.symbol: bench.fyers}, "1d", long_daily=True)
        df = got.get(bench.symbol)
        n = 0 if df is None else len(df)
        say("PASS" if n >= 300 else "WARN", f"Fyers {bench.name} day candles for the weekly view: {n} candles (two requests; "
                                            f"about 2 years are needed)"
            + ("" if df is not None else f" - {feed.reasons.get(bench.symbol, 'no reason given')}"))
    if mcx_all:                                                # every commodity contract, asked exactly the way the report asks
        tfs = [t for t in cfg["timeframes"] if BASE_INTERVAL[t] not in (lim.get("skip_intervals") or ())]
        ok, trouble, events = _mcx_like_the_report(cfg, mcx_all, feed, now, tfs)
        per_tf = " · ".join(f"{alerts.tf_name(t)} {ok[t]}/{sum(1 for i in mcx_all if t in i.tfs)}" for t in tfs)
        extra = ""
        if trouble:
            extra = (" · problems: " + "; ".join(f"{k} ({v})" for k, v in list(trouble.items())[:8])
                     + (" …" if len(trouble) > 8 else ""))
        say("WARN" if trouble else "PASS", f"Fyers commodity candles, requested the way the daily report does ({per_tf}){extra}")
        for e in events:
            say("WARN", e)
        for note in feed.switched:
            say("INFO", f"MCX contract change - {note}")
        use = {i.name: feed.picked.get(i.symbol, i.fyers) for i in mcx_all}
        say("INFO", "MCX contracts in use: " + "; ".join(f"{k} → {v.split(':')[1]}" for k, v in use.items())
            + (f" · codes worked out from the month, because Fyers' list could not be read: {', '.join(rep['guessed'][:6])}"
               if rep.get("guessed") else ""))
    if lim.get("skip_intervals") and any(i.market == "MCX" and i.fyers for i in indian):
        served = [alerts.tf_name(t) for t in cfg["timeframes"] if BASE_INTERVAL[t] not in lim["skip_intervals"]]
        left_out = [alerts.tf_name(t) for t in cfg["timeframes"] if BASE_INTERVAL[t] in lim["skip_intervals"]]
        say("INFO", f"MCX commodities: on the free Fyers plan they are scanned on {', '.join(served)} only - their "
                    f"{', '.join(left_out)} candles need the paid plan (no other data source has MCX prices).")
    est = fyers_mod.estimate_daily_calls(instruments, cfg)
    msg = (f"Fyers requests needed per trading day ≈ {est['total']:,} (allowance in use: {lim['per_day']:,} on the "
           f"{fcfg['plan']} plan) · {est['symbols']['NSE']} NSE/BSE and {est['symbols']['MCX']} MCX symbols")
    if est["skipped"]:
        msg += f" · {', '.join(est['skipped'])} candles are NOT counted: they come from TradingView on this plan"
    say("PASS" if est["total"] <= lim["per_day"] else "WARN", msg)
    if feed.slowdowns:
        say("INFO", f"Fyers asked the scanner to slow down {feed.slowdowns} time(s) during this check - it waited, lowered its "
                    f"pace and carried on")
    say("INFO", f"Fyers requests used by this check: {feed.calls}")
    return feed


def _mcx_like_the_report(cfg, mcx_all, feed, now, tfs):
    """Asks Fyers for every commodity contract exactly the way the daily report does (all together, two chunks of day
    candles for the weekly view) and reads the candles the way the scanner does - this is what went wrong before, so
    this is what the check proves. Returns ({timeframe: contracts that worked}, {commodity: first thing that went wrong},
    plain-English notes from the feed, e.g. that Fyers had to be given up for the rest of the run)."""
    fetcher = Fetcher(dict(cfg, data_source="yahoo"), mcx_all, fyers=feed)      # only Fyers: no TradingView, no Yahoo for MCX
    fetcher.long_daily = "1w" in tfs
    names = {i.symbol: i.name for i in mcx_all}
    ok, trouble = {t: 0 for t in tfs}, {}
    for itv in sorted({BASE_INTERVAL[t] for t in tfs}):
        wanted = [i for i in mcx_all if any(BASE_INTERVAL[t] == itv and t in i.tfs for t in tfs)]
        got, failed = fetcher([i.symbol for i in wanted], itv)
        for sym in failed:
            trouble.setdefault(names[sym], f"{itv}: {feed.reasons.get(sym) or feed.down or 'no candles'}")
        for t in (t for t in tfs if BASE_INTERVAL[t] == itv):
            for i in wanted:
                if i.symbol not in got or t not in i.tfs:
                    continue
                try:
                    summary, why = evaluate(got[i.symbol], "MCX", t, cfg, now, "fyers")
                except Exception as e:                                  # noqa: BLE001
                    summary, why = None, f"error: {str(e)[:80]}"
                if summary is None:
                    trouble.setdefault(i.name, f"{alerts.tf_name(t)}: {why}")
                else:
                    ok[t] += 1
    return ok, trouble, list(fetcher.events)


def _annotate(level, msg) -> None:
    """In GitHub Actions a warning or failure also shows at the top of the run page (the log lines stay as they are)."""
    if level in ("WARN", "FAIL") and os.environ.get("GITHUB_ACTIONS") == "true":
        text = str(msg).replace("%", "%25").replace("\r", "%0D").replace("\n", "%0A")
        print(f"::{'error' if level == 'FAIL' else 'warning'} title=Setup check::{text}", flush=True)


GOOD_NEWS = ("Fyers login works", "Fyers codes found", "Fyers commodity candles", "Fyers hourly candles", "Fyers requests needed")
CONTEXT = ("Fyers plan", "Fyers symbol list", "Fyers asked", "MCX contract", "MCX commodities", "Data source")


def setup_message(lines) -> str:
    """The Telegram text of the setup check: the verdict, everything that needs a look, and the facts worth knowing -
    so nobody has to open the GitHub run log."""
    n = {lvl: sum(1 for lv, _ in lines if lv == lvl) for lvl in ("PASS", "WARN", "FAIL")}
    out = [f"🩺 <b>Setup check</b> · scanner v{__version__}",
           f"{n['PASS']} passed · {n['WARN']} warnings · {n['FAIL']} failed", ""]
    attention = [(lv, m) for lv, m in lines if lv in ("FAIL", "WARN")]
    if attention:
        out.append("<b>Needs a look</b>")
        out += [("❌ " if lv == "FAIL" else "⚠️ ") + html_escape(m[:300]) for lv, m in attention]
        out.append("")
    facts = [m for lv, m in lines if (lv == "PASS" and m.startswith(GOOD_NEWS)) or (lv == "INFO" and m.startswith(CONTEXT))
             or (lv == "PASS" and "data mode" in m)]
    if facts:
        out.append("<b>Facts</b>")
        out += ["• " + html_escape(m[:800 if m.startswith("MCX contracts in use") else 300]) for m in facts]
    text = "\n".join(out).rstrip()
    if len(text) > 3900:
        text = text[:3880].rsplit("\n", 1)[0] + "\n…"
    return text


def cmd_doctor(args, cfg) -> int:
    now = _now(args)
    results, lines = [], []

    def say(level, msg):
        print(f"[{level}] {msg}", flush=True)
        _annotate(level, msg)
        results.append(level)
        lines.append((level, str(msg)))

    say("INFO", f"Scanner v{__version__} · Python {sys.version.split()[0]} · pandas {pd.__version__}")
    tg = Telegram.from_env()
    if tg is None:
        say("FAIL", "Telegram secrets are missing (TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID).")
    else:
        me = tg.get_me()
        say("PASS" if me else "FAIL",
            f"Telegram bot found: @{me.get('username')}" if me else f"Telegram rejected the token: {tg.last_error}")

    instruments, notes = build(cfg, _only(args))
    for k, v in notes.items():
        label = cfg["universes"][k].get("label", k)
        say("FAIL" if v.startswith("FAILED") else "PASS", f"{label}: {v}")

    fy_feed = None
    if instruments:
        fy_feed = _check_fyers(cfg, instruments, now, say, tg if args.send_test else None)
    if fy_feed is not None:
        # MCX prices exist only on Fyers - do not ask TradingView about them
        instruments = [i for i in instruments if i.market != "MCX"]

    mode = cfg["data_source"]
    say("INFO", {"auto": "Data source: TradingView first, Yahoo as backup (data_source: auto)",
                 "tradingview": "Data source: TradingView only (data_source: tradingview)",
                 "yahoo": "Data source: Yahoo only (data_source: yahoo)"}[mode])
    if instruments:
        ok = {}
        if mode in ("auto", "tradingview"):
            ok["TradingView"] = _check_feed("TradingView", make_fetcher(dict(cfg, data_source="tradingview"), instruments,
                                                                          purpose="backtest"),
                                            cfg, instruments, now, say, fail="FAIL" if mode == "tradingview" else "WARN",
                                            backup=(mode == "auto"))
        if mode in ("auto", "yahoo"):
            ok["Yahoo"] = _check_feed("Yahoo", make_fetcher(dict(cfg, data_source="yahoo"), instruments, purpose="backtest"), cfg,
                                      instruments, now, say, fail="FAIL" if mode == "yahoo" else "WARN",
                                      backup=(mode == "auto"))
        if mode == "auto":
            if not any(ok.values()):
                say("FAIL", "Neither TradingView nor Yahoo returned usable data - alerts cannot work until one of them does.")
            elif not ok.get("TradingView"):
                say("WARN", "TradingView is not working from here - the scanner will use the Yahoo backup.")
            elif not ok.get("Yahoo"):
                say("INFO", "Yahoo backup did not answer - fine while TradingView works, but there is no safety net.")

    if args.send_test and tg:
        tg.send(setup_message(lines))
    fails = results.count("FAIL")
    print(f"\nSUMMARY: {results.count('PASS')} passed, {results.count('WARN')} warnings, {fails} failed", flush=True)
    return 1 if fails else 0


def cmd_fyers_login(args, cfg) -> int:
    """Logs in to Fyers now and proves it with a test read of the Nifty 50.
    With the secrets FYERS_USER_ID and FYERS_TOTP_KEY the scanner logs in by itself; with an address pasted from the
    browser it finishes a login you did by hand; with neither it sends the login link to Telegram."""
    creds = fyers_mod.Creds.from_env()
    if creds is None:
        log.error("Add these GitHub secrets first: %s (see the guide, section 'Fyers').", ", ".join(fyers_mod.missing_secrets()))
        return 2
    sender = _sender(args)
    if sender is None:
        return 2
    raw = (args.url or os.environ.get("FYERS_LOGIN_URL", "")).strip()
    http = fyers_mod.RequestsHttp()
    store = fyers_mod.TokenStore(creds)
    session = fyers_mod.Session(creds, store, http)
    if raw.lower() in ("link", "by hand", "byhand"):                      # the way out if the automatic login ever breaks
        log.info("Sending the by-hand Fyers login link to your Telegram (it is not printed here because this log is public).")
        return 0 if sender.send(_login_link_message(creds)) else 1
    if raw:                                                              # a login done by hand in the browser
        try:
            tokens = fyers_mod.exchange_auth_code(creds, fyers_mod.parse_auth_code(raw), http)
        except (fyers_mod.FyersError, Exception) as e:                  # noqa: BLE001
            why = str(e)[:160]
            log.error("Fyers did not accept the login: %s", why)
            sender.send(f"❌ <b>Fyers login failed</b>\nFyers said: {html_escape(why)}\nEach login link works only once and "
                        f"only for a few minutes - run '4 - Fyers Login' with an empty box to get a fresh link, then try again.")
            return 1
        store.save(access_token=tokens["access_token"], access_at=fyers_mod._iso(datetime.now(timezone.utc)))
        store.drop("hold_until", "hold_why", "hold_fp")
        by_hand = True
    elif creds.can_log_in:                                               # the scanner logs in by itself
        if not session.start(force=True, fresh=True):
            log.error("Fyers login failed: %s", session.problem)
            sender.send(f"❌ <b>Fyers login failed</b>\n{html_escape(session.problem)}")
            return 1
        by_hand = False
    else:
        log.info("Sending the Fyers login link to your Telegram (it is not printed here because this log is public).")
        return 0 if sender.send(_login_link_message(creds)) else 1
    # prove it works: read one index with the pass that was just saved
    fcfg = cfg["fyers"]
    lim = fcfg["limits"][fcfg["plan"]]
    feed = fyers_mod.FyersFeed(fcfg, fcfg["plan"], creds, session, http,
                               fyers_mod.Limiter(lim["per_second"], lim["per_minute"], lim["per_day"]))
    got, _ = feed.fetch({"nifty": "NSE:NIFTY50-INDEX"}, "1d")
    if "nifty" in got:
        if not by_hand:
            sender.send("✅ <b>Fyers login works</b>\nThe scanner logged in by itself (user ID + TOTP code + PIN) and read the "
                        "Nifty 50. It repeats this on its own every day - there is nothing more to do. Indian prices now "
                        "come from Fyers (real time).")
        elif creds.can_log_in:
            sender.send("✅ <b>Fyers login saved</b> (made by hand)\nIndian prices come from Fyers (real time). From tomorrow "
                        "the scanner logs in by itself.")
        else:
            sender.send("✅ <b>Fyers login saved</b> - good for today only\nIndian prices come from Fyers (real time) until "
                        "tonight. Fyers needs a new login every day: add the GitHub secrets FYERS_USER_ID and FYERS_TOTP_KEY "
                        "(guide, Step E) and the scanner does it for you.")
        log.info("Fyers login saved; test read of NIFTY 50 worked.")
        return 0
    why = feed.reasons.get("nifty", "unknown")
    sender.send(f"⚠️ <b>Fyers login worked, but the test read failed</b>\nReason: {html_escape(str(why))}\n"
                f"Run '0 - Check Setup' and send me the Fyers lines.")
    log.error("Logged in, but reading NIFTY 50 failed: %s", why)
    return 1


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="scanner", description="EMA crossover scanner")
    sub = parser.add_subparsers(dest="cmd", required=True)
    for name in ("scan", "report", "doctor", "test-telegram", "backtest", "fyers-login"):
        sp = sub.add_parser(name)
        sp.add_argument("--config", help="path to config.yaml")
        sp.add_argument("--dry-run", action="store_true", help="print messages instead of sending; no state saved")
        sp.add_argument("--only", help="comma-separated universe keys, e.g. crypto,indian_indices")
        sp.add_argument("--now", help=argparse.SUPPRESS)
        if name in ("report", "backtest"):
            sp.add_argument("--no-telegram", action="store_true")
        if name == "backtest":
            sp.add_argument("--years", help="how many years back to test (default: backtest -> years in config.yaml)")
            sp.add_argument("--limit", type=int, help="quick test: only the first N securities of each group")
        if name == "doctor":
            sp.add_argument("--send-test", action="store_true", help="also send a Telegram test message")
        if name == "fyers-login":
            sp.add_argument("--url", help="the web address Fyers sent you to after you logged in (or just the auth_code)")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(message)s", stream=sys.stdout)
    try:
        cfg = load_config(args.config)
    except ConfigError as e:
        print(f"[FAIL] {e}")
        return 2
    return {"scan": cmd_scan, "report": cmd_report, "doctor": cmd_doctor, "test-telegram": cmd_test_telegram,
            "backtest": cmd_backtest, "fyers-login": cmd_fyers_login}[args.cmd](args, cfg)
