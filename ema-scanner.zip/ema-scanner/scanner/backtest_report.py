"""Turns backtest rows into: the best timeframe per security, group summaries, a Markdown report, CSV files and a
short Telegram digest.

Two views of the same rule are reported, because the free data reaches back very differently per timeframe:
  * "long run"  - each timeframe over the longest stretch available (up to the target years). Daily and weekly candles
                  give about 3 years, 15-minute candles only months.
  * "same period" - every timeframe replayed over the SAME recent stretch (backtest -> recent_years), the fair way to
                  put 15-minute and weekly candles side by side.
"""
from __future__ import annotations

import html

import numpy as np
import pandas as pd

from .report import _table

TF_ORDER = ("15m", "1h", "4h", "1d", "1w")
TEXT_COLS = ["universes", "symbol", "display", "name", "market", "timeframe", "window", "status", "open_trade",
             "window_from", "window_to"]
NUM_COLS = ["years", "bars", "trades", "wins", "win_rate_pct", "avg_trade_pct", "gross_avg_trade_pct", "profit_factor",
            "pos_sum_pct", "neg_sum_pct", "total_return_pct", "cagr_pct", "max_dd_pct", "bh_return_pct", "bh_cagr_pct",
            "bh_max_dd_pct", "exposure_pct", "avg_bars_held"]
ROW_COLS = TEXT_COLS + NUM_COLS
FEW_TRADES = 10          # a "best timeframe" resting on fewer trades than this gets a warning flag
SHORT_YEARS = 1.0        # less history than this gets a ⚠ in the tables
MIN_GROUP_TRADES = 30    # a timeframe needs this many trades in a whole group before it can be named that group's best


# ------------------------------------------------------------------------------------------------- formatting
def _num(x) -> bool:
    try:
        return x is not None and bool(np.isfinite(x))
    except TypeError:
        return False


def pct(x, digits: int = 1, sign: bool = True) -> str:
    if not _num(x):
        return "–"
    if abs(x) >= 1000:
        digits = 0
    return f"{x:+,.{digits}f}%" if sign else f"{x:,.{digits}f}%"


def drop(x) -> str:
    """A fall from a peak, shown as a plain size ('15%'), not as a negative number."""
    return pct(abs(x), 0, False) if _num(x) else "–"


def flt(x, digits: int = 2) -> str:
    return f"{x:,.{digits}f}" if _num(x) else "–"


def _cell(text) -> str:
    return str(text).replace("|", "/")


def months(years: float) -> str:
    m = round(float(years) * 12)
    return f"{m} months" if m != 12 else "year"


# ---------------------------------------------------------------------------------------------------- tables
def results_frame(rows) -> pd.DataFrame:
    df = pd.DataFrame(rows)
    for c in ROW_COLS:
        if c not in df.columns:
            df[c] = None
    df = df[ROW_COLS].copy()
    df["window"] = df["window"].fillna("full")
    for c in NUM_COLS:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df


def _eligible(recs, min_trades: int, min_years: float, col: str) -> list:
    return [r for r in recs if r["status"] == "ok" and _num(r[col]) and r["trades"] >= min_trades
            and r["years"] >= min_years]


def _best(cands, col: str):
    return max(cands, key=lambda r: (r[col], r["profit_factor"] if _num(r["profit_factor"]) else 0.0))


def best_per_security(df: pd.DataFrame, bt: dict) -> pd.DataFrame:
    """One row per security. `best_*` = the timeframe with the best yearly return over its longest stretch (among those
    with enough trades and at least `min_years` of candles); `recent_*` = the same comparison over the common recent
    period, which is the only fair place for 15-minute candles."""
    min_trades, min_years = int(bt["min_trades"]), float(bt["min_years"])
    out = []
    for sym, g in df.groupby("symbol", sort=False):
        full = {r["timeframe"]: r for r in g[g["window"] == "full"].to_dict("records")}
        recent = {r["timeframe"]: r for r in g[g["window"] == "recent"].to_dict("records")}
        first = g.iloc[0]
        rec = {"universes": first["universes"], "symbol": sym, "display": first["display"], "name": first["name"],
               "market": first["market"]}
        for tf in TF_ORDER:
            r, q = full.get(tf), recent.get(tf)
            good = r is not None and r["status"] == "ok"
            rec[f"cagr_{tf}"] = r["cagr_pct"] if good else None
            rec[f"trades_{tf}"] = r["trades"] if good else None
            rec[f"years_{tf}"] = r["years"] if good else None
            rec[f"recent_{tf}"] = q["total_return_pct"] if q is not None and q["status"] == "ok" else None
        flags = []
        eligible = _eligible(full.values(), min_trades, min_years, "cagr_pct")
        if eligible:
            b = _best(eligible, "cagr_pct")
            rec.update({"best_timeframe": b["timeframe"], "best_cagr_pct": b["cagr_pct"],
                        "best_profit_factor": b["profit_factor"], "best_win_rate_pct": b["win_rate_pct"],
                        "best_trades": b["trades"], "best_max_dd_pct": b["max_dd_pct"],
                        "best_bh_cagr_pct": b["bh_cagr_pct"], "best_years": b["years"]})
            if b["cagr_pct"] <= 0:
                flags.append("lost money on every timeframe")
            elif _num(b["bh_cagr_pct"]) and b["cagr_pct"] < b["bh_cagr_pct"]:
                flags.append("buy & hold did better")
            if b["trades"] < FEW_TRADES:
                flags.append("few trades")
            if b["years"] < SHORT_YEARS:
                flags.append("under 1 year of data")
        else:
            rec.update({"best_timeframe": "", "best_cagr_pct": None, "best_profit_factor": None,
                        "best_win_rate_pct": None, "best_trades": None, "best_max_dd_pct": None,
                        "best_bh_cagr_pct": None, "best_years": None})
            flags.append("no data" if not any(r["status"] == "ok" for r in full.values())
                         else "too few trades or too little history")
        rec["flags"] = "; ".join(flags)
        rb = _eligible(recent.values(), min_trades, 0.0, "total_return_pct")
        if rb:
            q = _best(rb, "total_return_pct")
            rec.update({"recent_best_timeframe": q["timeframe"], "recent_best_return_pct": q["total_return_pct"],
                        "recent_best_bh_return_pct": q["bh_return_pct"], "recent_best_trades": q["trades"]})
        else:
            rec.update({"recent_best_timeframe": "", "recent_best_return_pct": None,
                        "recent_best_bh_return_pct": None, "recent_best_trades": None})
        out.append(rec)
    cols = (["universes", "symbol", "display", "name", "market", "best_timeframe", "best_cagr_pct", "best_profit_factor",
             "best_win_rate_pct", "best_trades", "best_max_dd_pct", "best_bh_cagr_pct", "best_years", "flags"]
            + [f"{k}_{tf}" for k in ("cagr", "trades", "years") for tf in TF_ORDER]
            + ["recent_best_timeframe", "recent_best_return_pct", "recent_best_bh_return_pct", "recent_best_trades"]
            + [f"recent_{tf}" for tf in TF_ORDER])
    return pd.DataFrame(out, columns=cols)


def group_stats(sub: pd.DataFrame, bests: pd.DataFrame, tfs, recent: bool = False) -> dict:
    """{timeframe: numbers for the whole group, or None when nothing could be tested}.
    Long run: `ret_med` is the median yearly return. Same period: the median total return over the recent period."""
    win = "recent" if recent else "full"
    rcol, bcol = ("total_return_pct", "bh_return_pct") if recent else ("cagr_pct", "bh_cagr_pct")
    pick = "recent_best_timeframe" if recent else "best_timeframe"
    stats = {}
    for tf in tfs:
        g = sub[(sub["window"] == win) & (sub["timeframe"] == tf) & (sub["status"] == "ok")]
        if g.empty:
            stats[tf] = None
            continue
        trades = float(g["trades"].sum())
        pos, neg = float(g["pos_sum_pct"].sum()), float(g["neg_sum_pct"].sum())
        both = g[g[rcol].notna() & g[bcol].notna()]
        stats[tf] = {
            "symbols": int(len(g)), "years": float(g["years"].median()), "trades_med": float(g["trades"].median()),
            "trades_total": int(trades),
            "win_rate": float(g["wins"].sum()) * 100.0 / trades if trades else None,
            "avg_trade": (pos + neg) / trades if trades else None,
            "profit_factor": pos / -neg if neg < 0 else None,
            "ret_med": float(g[rcol].median()), "bh_ret_med": float(g[bcol].median()),
            "profitable": float((g["total_return_pct"] > 0).mean() * 100.0),
            "beat_bh": float((both[rcol] > both[bcol]).mean() * 100.0) if len(both) else None,
            "dd_med": float(g["max_dd_pct"].median()), "bh_dd_med": float(g["bh_max_dd_pct"].median()),
            "best_for": int((bests[pick] == tf).sum()),
        }
    return stats


def group_best(stats: dict, bt: dict, recent: bool = False):
    """The timeframe with the best typical (median) return among those with enough trades (and, for the long run,
    enough history)."""
    min_years = 0.0 if recent else float(bt["min_years"])
    cand = {tf: s for tf, s in stats.items()
            if s and _num(s["ret_med"]) and s["years"] >= min_years and s["trades_total"] >= MIN_GROUP_TRADES}
    return max(cand, key=lambda tf: cand[tf]["ret_med"]) if cand else None


def verdict(stats: dict, best_tf, recent: bool = False) -> str:
    if best_tf is None:
        return "not enough trades or history to compare the timeframes"
    s = stats[best_tf]
    c, b = s["ret_med"], s["bh_ret_med"]
    unit = "" if recent else " a year"
    if c <= 0:
        return "lost money after costs on every timeframe that could be compared"
    if _num(b) and c >= b:
        return f"beat buy & hold ({pct(c, 0)} vs {pct(b, 0)}{unit})"
    text = f"made money ({pct(c, 0)}{unit}) but buy & hold made more ({pct(b, 0)})"
    if _num(s["dd_med"]) and _num(s["bh_dd_med"]) and s["dd_med"] > s["bh_dd_med"]:
        text += f", with a smaller worst drop ({drop(s['dd_med'])} vs {drop(s['bh_dd_med'])})"
    return text


def _members(instruments, cfg) -> list:
    """[(key, label, set of symbols)] for every enabled group that has securities."""
    out = []
    for key, u in cfg["universes"].items():
        syms = {i.symbol for i in instruments if key in i.universes}
        if u.get("enabled", True) and syms:
            out.append((key, u.get("label", key), syms))
    return out


def analyse(df: pd.DataFrame, bests: pd.DataFrame, instruments, cfg: dict, tfs) -> list:
    """Per group: dict(key, label, listed, tested, stats/best/verdict for the long run, recent_* for the same period)."""
    bt = cfg["backtest"]
    groups = []
    for key, label, syms in _members(instruments, cfg):
        sub = df[df["symbol"].isin(syms)]
        b = bests[bests["symbol"].isin(syms)]
        stats, rstats = group_stats(sub, b, tfs), group_stats(sub, b, tfs, recent=True)
        best, rbest = group_best(stats, bt), group_best(rstats, bt, recent=True)
        tested = int(sub[(sub["status"] == "ok") & (sub["window"] == "full")]["symbol"].nunique())
        groups.append({"key": key, "label": label, "listed": len(syms), "tested": tested, "bests": b,
                       "stats": stats, "best": best, "verdict": verdict(stats, best),
                       "recent_stats": rstats, "recent_best": rbest, "recent_verdict": verdict(rstats, rbest, True)})
    return groups


# --------------------------------------------------------------------------------------------------- markdown
def _cell_ret(s, best, recent: bool) -> str:
    if not s:
        return "–"
    v = s["ret_med"]
    text = pct(v, 0 if abs(v) >= 10 else 1)
    if not recent and s["years"] < SHORT_YEARS:
        text += " ⚠"
    return f"**{text}**" if best else text


def _bh_ref(stats: dict, best=None):
    """Buy & hold for the summary lines: the one over the best timeframe's own period, else the middle one."""
    if best and stats.get(best) and _num(stats[best]["bh_ret_med"]):
        return float(stats[best]["bh_ret_med"])
    vals = [s["bh_ret_med"] for s in stats.values() if s and _num(s["bh_ret_med"])]
    return float(np.median(vals)) if vals else None


def _group_table(g, tfs, recent: bool) -> list:
    stats, best = (g["recent_stats"], g["recent_best"]) if recent else (g["stats"], g["best"])
    rows = []
    for tf in tfs:
        st = stats.get(tf)
        label = f"**{tf.upper()}**" if tf == best else tf.upper()
        if not st:
            rows.append([label, "no data"] + ["–"] * 10)
            continue
        rows.append([label, f"{st['years']:.1f} y" + (" ⚠" if not recent and st["years"] < SHORT_YEARS else ""),
                     f"{st['trades_med']:g}", pct(st["win_rate"], 0, False), pct(st["avg_trade"], 2),
                     flt(st["profit_factor"]), pct(st["ret_med"]), pct(st["bh_ret_med"]),
                     pct(st["profitable"], 0, False), pct(st["beat_bh"], 0, False),
                     drop(st["dd_med"]) + " vs " + drop(st["bh_dd_med"]), st["best_for"]])
    heads = ["Timeframe", "Period tested", "Trades per security", "Win rate", "Avg trade", "Profit factor",
             "Return over the period" if recent else "Yearly return", "Buy & hold", "Securities in profit",
             "Beat buy & hold", "Worst drop (rule vs buy & hold)", "Best for"]
    return _table(heads, rows)


def build_markdown(df, bests, groups, instruments, cfg, now, years, tfs, skipped: int) -> str:
    bt = cfg["backtest"]
    s, l = cfg["ema"]["short"], cfg["ema"]["long"]
    rec_y = float(bt.get("recent_years") or 0)
    has_recent = any(any(g["recent_stats"].values()) for g in groups) and rec_y > 0
    stamp = now.tz_convert(cfg["display_timezone"]).strftime("%d %b %Y %H:%M %Z")
    costs = ", ".join(f"{k} {v}%" for k, v in bt["cost_pct_per_side"].items()
                      if any(i.market == k for i in instruments))
    md = [f"# EMA {s}/{l} Crossover – Backtest", "",
          f"Generated **{stamp}** · rule: buy when EMA {s} crosses above EMA {l}, sell when it crosses below · "
          f"long only · candle closes only · target period: last **{years:g} years** "
          f"(shorter where the free data does not reach back that far) · cost per buy and per sell: {costs}", ""]
    if skipped:
        md += [f"> ⚠ {skipped} security/timeframe results are missing (time limit, data feed problems). "
               f"See the `status` column in `results.csv`.", ""]

    md += ["## 1. The short answer", "",
           f"**A. Longest history available (up to {years:g} years).** Typical (median) **yearly return after costs** of the "
           "rule on each timeframe; the best timeframe of each group is in bold. ⚠ = less than 1 year of candles behind "
           "the number - such a timeframe is shown but cannot be named best, because a few months cannot be compared "
           "fairly with years.", ""]
    rows = [[g["label"], f"{g['tested']} of {g['listed']}"]
            + [_cell_ret(g["stats"].get(tf), tf == g["best"], False) for tf in tfs]
            + [pct(_bh_ref(g["stats"], g["best"]), 0), f"**{g['best']}**" if g["best"] else "–"] for g in groups]
    md += _table(["Group", "Tested"] + [t.upper() for t in tfs] + ["Buy & hold", "Best"], rows) + [""]
    if has_recent:
        md += [f"**B. Same period for every timeframe (the last {months(rec_y)}).** Median **total return** over just that "
               "stretch, so 15-minute and weekly candles are compared on equal terms. Short, so treat it as a hint, "
               "not a proof.", ""]
        rows = [[g["label"], f"{g['tested']} of {g['listed']}"]
                + [_cell_ret(g["recent_stats"].get(tf), tf == g["recent_best"], True) for tf in tfs]
                + [pct(_bh_ref(g["recent_stats"], g["recent_best"]), 0), f"**{g['recent_best']}**" if g["recent_best"] else "–"]
                for g in groups]
        md += _table(["Group", "Tested"] + [t.upper() for t in tfs] + ["Buy & hold", "Best"], rows) + [""]
    md += ["What this says, group by group:", ""]
    for g in groups:
        line = f"- **{g['label']}**: longest history - " + (f"best **{g['best']}**, " if g["best"] else "") + g["verdict"] + "."
        if has_recent:
            line += (f" Last {months(rec_y)} - " + (f"best **{g['recent_best']}**, " if g["recent_best"] else "")
                     + g["recent_verdict"] + ".")
        md += [line]
    md += [""]

    md += ["## 2. Each group in detail", "",
           "Each row is one timeframe. Win rate, average trade and profit factor pool every trade of the group; the return, "
           "worst drop and the two shares are medians over the group's securities.", ""]
    for g in groups:
        md += [f"### {g['label']} ({g['tested']} securities tested)", "", "Longest history:", ""]
        md += _group_table(g, tfs, False) + [""]
        if has_recent:
            md += [f"Same period for every timeframe (last {months(rec_y)}):", ""]
            md += _group_table(g, tfs, True) + [""]

    md += ["## 3. Best timeframe for each security", "",
           "Sorted by name. *Best* = highest yearly return after costs among the timeframes with at least "
           f"{bt['min_trades']} trades and {bt['min_years']:g} year(s) of candles. The columns 15M to 1W show the yearly return "
           "on every timeframe (the CSV also has the same-period numbers). Treat the pick of a single security with care "
           "(see section 4).", ""]
    heads = ["Security", "Best", "Yearly return", "Profit factor", "Win rate", "Trades", "Worst drop", "Buy & hold"] \
        + [t.upper() for t in TF_ORDER] + ["Flags"]
    for g in groups:
        md += [f"### {g['label']}", ""]
        b = g["bests"].copy()
        b["_k"] = b["display"].astype(str).str.lower()
        rows = []
        for r in b.sort_values("_k").to_dict("records"):
            has = bool(r["best_timeframe"])
            rows.append([_cell(r["display"]), f"**{r['best_timeframe']}**" if has else "–",
                         pct(r["best_cagr_pct"], 0 if _num(r["best_cagr_pct"]) and abs(r["best_cagr_pct"]) >= 10 else 1),
                         flt(r["best_profit_factor"]), pct(r["best_win_rate_pct"], 0, False),
                         int(r["best_trades"]) if _num(r["best_trades"]) else "–",
                         drop(r["best_max_dd_pct"]), pct(r["best_bh_cagr_pct"], 0)]
                        + [pct(r[f"cagr_{tf}"], 0) + (" ⚠" if _num(r[f"years_{tf}"]) and r[f"years_{tf}"] < SHORT_YEARS else "")
                           if _num(r[f"cagr_{tf}"]) else "–" for tf in TF_ORDER]
                        + [r["flags"]])
        md += _table(heads, rows) + [""]

    md += ["## 4. How to read this – and what it cannot tell you", "",
           "- **Yearly return** is the average yearly growth of the account after costs, compounded. **Profit factor** is "
           "total profit of the winning trades divided by total loss of the losing ones (above 1 = made money). "
           "**Worst drop** is the largest fall from a previous high of the account.",
           "- **Different timeframes have different amounts of history.** The free TradingView feed holds about 5,000 candles "
           "per series: roughly 3 years of hourly candles for stocks but only about 9 months of 15-minute candles "
           "(crypto: about 7 months of hourly, 7 weeks of 15-minute candles; hourly crypto and futures are extended with "
           "Yahoo where possible). That is why there are two views: A uses the longest stretch of each timeframe, B puts "
           "all timeframes on the same recent stretch. Where they disagree, trust neither fully.",
           "- **The best timeframe of one security is the winner of several tries, so it looks better than it will be in "
           "future.** The group medians in sections 1-2 are far more reliable than the pick for a single security.",
           "- **One market phase.** Three years is a single stretch of market history (and a few months far less); a rule "
           "that did well in it may do badly in a different phase.",
           "- **Long only.** A bearish crossover only means 'sell and wait'; there are no short trades.",
           "- **Costs are assumptions** (see the header). Real costs depend on your broker, taxes and slippage and hurt the "
           "short timeframes most because they trade the most.",
           "- **Survivorship:** the lists are today's members of each index; companies that dropped out earlier are not "
           "included, which makes stock results look somewhat better than they were.",
           "- Orders are assumed to fill at the next candle's open, always, in full. 4h candles are built from hourly "
           "candles and weekly candles from daily ones, exactly as the live scanner does. Prices are adjusted for splits, "
           "not for dividends. Commodities are global futures (COMEX/NYMEX/ICE), not MCX prices.",
           "- Past results do not promise future results. This is an experiment about the rule, not advice.", ""]

    if (df["status"] != "ok").any():
        miss = df[df["status"] != "ok"]["status"].str.slice(0, 40).value_counts().head(6)
        md += ["## 5. What could not be tested", ""]
        md += _table(["Reason", "Results"], [[k, int(v)] for k, v in miss.items()]) + [""]
    return "\n".join(md)


# ---------------------------------------------------------------------------------------------------- telegram
def _tf_line(stats: dict, tfs, recent: bool) -> str:
    parts = []
    for tf in tfs:
        st = stats.get(tf)
        if st:
            parts.append(f"{tf} {pct(st['ret_med'], 0)}" + ("⚠" if not recent and st["years"] < SHORT_YEARS else ""))
    return " · ".join(parts)


def summary_text(groups, cfg, now, years, tfs, skipped: int) -> str:
    s, l = cfg["ema"]["short"], cfg["ema"]["long"]
    rec_y = float(cfg["backtest"].get("recent_years") or 0)
    lines = [f"🧪 <b>Backtest finished</b> · EMA {s}/{l} · long only · after costs", ""]
    for g in groups:
        lines.append(f"<b>{html.escape(g['label'])}</b> ({g['tested']} tested)")
        best = g["best"]
        head = f"  Longest history ({years:g}y max): " + (f"best <b>{best}</b> · " if best else "no clear best · ")
        lines.append(head + _tf_line(g["stats"], tfs, False) + " per year"
                     + (f" (buy &amp; hold {pct(_bh_ref(g['stats'], best), 0)})" if _num(_bh_ref(g["stats"], best)) else ""))
        if rec_y > 0 and any(g["recent_stats"].values()):
            rb = g["recent_best"]
            lines.append(f"  Last {months(rec_y)}, same period: " + (f"best <b>{rb}</b> · " if rb else "no clear best · ")
                         + _tf_line(g["recent_stats"], tfs, True)
                         + (f" (buy &amp; hold {pct(_bh_ref(g['recent_stats'], rb), 0)})" if _num(_bh_ref(g["recent_stats"], rb)) else ""))
    lines += ["", "Typical (median) results. ⚠ = under 1 year of candles, shown but not ranked."]
    if skipped:
        lines.append(f"⚠ {skipped} results missing - see the report.")
    lines.append("Attached: best timeframe per security (CSV) and the full report.")
    text = "\n".join(lines)
    return text if len(text) <= 3900 else text[:3850].rsplit("\n", 1)[0] + "\n…"


# ------------------------------------------------------------------------------------------------------ files
def write_files(out_dir, md: str, df: pd.DataFrame, bests: pd.DataFrame, day: str) -> dict:
    (out_dir / "archive").mkdir(parents=True, exist_ok=True)
    paths = {"md": out_dir / "latest.md", "results": out_dir / "results.csv", "best": out_dir / "best_by_security.csv"}
    paths["md"].write_text(md, encoding="utf-8")
    (out_dir / "archive" / f"{day}.md").write_text(md, encoding="utf-8")
    df.round(4).to_csv(paths["results"], index=False)
    bests.round(4).to_csv(paths["best"], index=False)
    return paths
