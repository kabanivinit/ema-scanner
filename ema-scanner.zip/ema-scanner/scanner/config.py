"""Loads config.yaml (with safe defaults) and explains mistakes in plain English."""
from __future__ import annotations

import copy
import os
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
VALID_TFS = ("15m", "1h", "4h", "1d", "1w")
VALID_MARKETS = ("NSE", "US", "CRYPTO", "FUT", "MCX")
VALID_SOURCES = ("auto", "tradingview", "yahoo")

DEFAULTS = {
    "data_source": "auto",              # auto = TradingView first, Yahoo as backup | tradingview | yahoo
    "ema": {"short": 10, "long": 20},
    "timeframes": list(VALID_TFS),
    "min_bars": 60,
    "display_timezone": "Asia/Kolkata",
    "universe_refresh_days": 7,
    "alerts": {
        "directions": "both",
        "tradingview_links": True,
        "max_lines_per_message": 40,
        "min_data_coverage": 0.80,
        "health_alert_hours": 6,
        # Timeframes that also get a short "no crossovers" message when a candle closes without any.
        "empty_messages": list(VALID_TFS),
    },
    "scan_last_bars": {"15m": 3, "1h": 2, "4h": 2, "1d": 2, "1w": 2},
    "settle_minutes": {"15m": 1, "1h": 2, "4h": 2, "1d": 15, "1w": 15},
    # After a late run or an outage only crossovers on candles newer than this are sent (about the last 5 candles);
    # the message then says what was skipped. Older alerts would only be noise.
    "max_alert_age_minutes": {"15m": 75, "1h": 300, "4h": 1200, "1d": 4320, "1w": 14400},
    "report": {"fresh_bars": {"15m": 4, "1h": 4, "4h": 3, "1d": 3, "1w": 2}, "max_rows_per_table": 40},
    # How late each free data feed is. The scanner waits this long after a candle closes, so it never
    # judges a candle that is still being built inside the (delayed) feed.
    "feed_delay_minutes": {
        "tradingview": {"NSE": 15, "US": 15, "MCX": 15, "FUT": 15, "CRYPTO": 0},
        "yahoo": {"NSE": 0, "US": 0, "MCX": 0, "FUT": 0, "CRYPTO": 0},
        "fyers": {"NSE": 0, "US": 0, "MCX": 0, "FUT": 0, "CRYPTO": 0},
    },
    # Fyers = real-time prices for NSE / BSE / MCX (secrets FYERS_APP_ID, FYERS_SECRET_ID, FYERS_PIN switch it on).
    "fyers": {
        "enabled": True,
        "plan": "standard",             # standard = free plan | prime = paid plan (set this to match YOUR Fyers plan)
        # Our own pace limits - always a little below what Fyers allows. Fyers blocks an account for the rest of the
        # day if the per-minute limit is broken 3 times. skip_intervals = candles still taken from TradingView.
        "limits": {
            # reserve_mcx = requests per day that NSE/BSE may not use, so the MCX candles (which have no other
            # source) never run dry late in the evening.
            "standard": {"per_second": 4, "per_minute": 40, "per_day": 4700, "reserve_mcx": 320, "skip_intervals": ["15m"]},
            "prime": {"per_second": 8, "per_minute": 400, "per_day": 450000, "reserve_mcx": 0, "skip_intervals": []},
        },
        "max_seconds": 1100,            # Fyers may use at most this long in one run; what is left goes to TradingView
        "workers": 4,                   # requests in flight at once
        "timeout_seconds": 20,
        "retries": 1,                   # extra tries after a failed request
        "history_days": {"15m": 30, "1h": 60, "1d": 360},      # days of candles per request (Fyers allows 100 / 366)
        "mcx_roll_days": 3,             # switch to next month's MCX contract this many days before month end
        "warn_days": 2,                 # Telegram warning this many days before the Fyers login runs out
        "master_refresh_days": {"NSE_CM": 7, "BSE_CM": 7, "MCX_COM": 1},
    },
    "run_budget_seconds": 1300,         # one scan run never downloads for longer than this
    "tradingview": {
        "bars": {"15m": 400, "1h": 400, "1d": 500},    # candles requested per symbol
        "batch_size": 25,               # symbols per connection
        "pause_seconds": 0.4,           # rest between batches
        "timeout_seconds": 40,          # give up on a batch after this long
        "retries": 1,                   # extra tries for symbols that timed out
        "max_seconds": 900,             # total time TradingView may use in one run
        "stop_after_failed_batches": 3,  # this many silent batches in a row = TradingView is down for this run
    },
    "yahoo": {
        "batch_size": 50, "pause_seconds": 2.0, "threads": 4, "retries": 2, "max_seconds": 900,
        "periods": {"15m": "30d", "1h": "90d", "1d": "3y"},
    },
    # The backtest ("3 - Backtest" workflow): the same rule, replayed over history on every timeframe.
    "backtest": {
        "years": 3,                     # how far back to test (shorter where the free data does not reach back)
        "timeframes": None,             # None = the same list as 'timeframes' above
        "warmup_bars": 60,              # candles used only to settle the averages before any trade is allowed
        "recent_years": 0.5,            # the "same period" comparison: every timeframe replayed over just this recent stretch
        "min_trades": 3,                # a timeframe needs this many trades to be named 'best' for a security
        "min_years": 1.0,               # ... and at least this much history (in years)
        # Cost of every buy and every sell in % of the trade value (brokerage, taxes, spread, slippage - a guess).
        "cost_pct_per_side": {"NSE": 0.05, "US": 0.02, "CRYPTO": 0.10, "FUT": 0.05, "MCX": 0.05},
        "chunk_symbols": 40,            # securities downloaded and tested at a time (keeps memory small)
        "max_minutes": 300,             # stop starting new work after this long and report what is done
        "extend_with_yahoo": True,      # hourly candles for crypto / futures reach further back on Yahoo
        "tradingview": {"bars": {"15m": 5000, "1h": 5000, "1d": 1500}, "batch_size": 10, "timeout_seconds": 120,
                        "max_seconds": 18000, "pause_seconds": 0.5},
        "yahoo": {"periods": {"15m": "59d", "1h": "720d", "1d": "5y"}, "batch_size": 25, "max_seconds": 3600},
    },
    "universes": {},
    "lists": {},
}


class ConfigError(Exception):
    """Raised with a message a non-coder can act on."""


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict) and k not in ("universes", "lists"):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def _validate(cfg: dict) -> None:
    e = cfg["ema"]
    if not (isinstance(e["short"], int) and isinstance(e["long"], int) and 1 <= e["short"] < e["long"]):
        raise ConfigError("config.yaml: ema short must be a whole number smaller than ema long (e.g. 10 and 20).")
    bad = [t for t in cfg["timeframes"] if t not in VALID_TFS]
    if bad:
        raise ConfigError(f"config.yaml: unknown timeframe(s) {bad}. Allowed: {', '.join(VALID_TFS)}.")
    if cfg["alerts"]["directions"] not in ("both", "bullish", "bearish"):
        raise ConfigError("config.yaml: alerts -> directions must be both, bullish or bearish.")
    if cfg["data_source"] not in VALID_SOURCES:
        raise ConfigError(f"config.yaml: data_source must be one of {', '.join(VALID_SOURCES)} "
                          f"(you wrote '{cfg['data_source']}').")
    bad = [t for t in (cfg["alerts"].get("empty_messages") or []) if t not in VALID_TFS]
    if bad:
        raise ConfigError(f"config.yaml: alerts -> empty_messages has unknown timeframe(s) {bad}. Allowed: {', '.join(VALID_TFS)}.")
    if cfg["fyers"].get("plan") not in ("standard", "prime"):
        raise ConfigError("fyers plan must be standard (free Fyers plan) or prime (paid Fyers plan) - check 'fyers: plan' in "
                          "config.yaml or the GitHub secret FYERS_PLAN.")
    for key, u in cfg["universes"].items():
        if u.get("market") not in VALID_MARKETS:
            raise ConfigError(f"config.yaml: universe '{key}' has market '{u.get('market')}'. Allowed: {', '.join(VALID_MARKETS)}.")
        bad = [t for t in (u.get("timeframes") or []) if t not in VALID_TFS]
        if bad:
            raise ConfigError(f"config.yaml: universe '{key}' has unknown timeframe(s) {bad}.")
        if u.get("source") == "list" and u.get("list") not in cfg["lists"]:
            raise ConfigError(f"config.yaml: universe '{key}' points to list '{u.get('list')}' which does not exist under 'lists'.")
    b = cfg["backtest"]
    try:
        years_ok = 0.25 <= float(b["years"]) <= 10
    except (TypeError, ValueError):
        years_ok = False
    if not years_ok:
        raise ConfigError("config.yaml: backtest -> years must be a number between 0.25 and 10.")
    try:
        recent_ok = 0 <= float(b.get("recent_years") or 0) <= 5
    except (TypeError, ValueError):
        recent_ok = False
    if not recent_ok:
        raise ConfigError("config.yaml: backtest -> recent_years must be a number between 0 and 5 (0 switches the "
                          "same-period comparison off).")
    bad = [t for t in (b.get("timeframes") or []) if t not in VALID_TFS]
    if bad:
        raise ConfigError(f"config.yaml: backtest -> timeframes has unknown value(s) {bad}. Allowed: {', '.join(VALID_TFS)}.")
    if not isinstance(b.get("cost_pct_per_side"), dict):
        raise ConfigError("config.yaml: backtest -> cost_pct_per_side must list a percentage per market, e.g. NSE: 0.05.")
    if not any(u.get("enabled", True) for u in cfg["universes"].values()):
        raise ConfigError("config.yaml: every universe is switched off (enabled: false) - nothing to scan.")


def load_config(path=None) -> dict:
    p = Path(path) if path else ROOT / "config.yaml"
    if not p.exists():
        raise ConfigError(f"Cannot find {p.name}. It must sit in the main folder of the project.")
    try:
        raw = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        mark = getattr(exc, "problem_mark", None)
        where = f" near line {mark.line + 1}" if mark else ""
        raise ConfigError(f"config.yaml has a formatting mistake{where}. Check the spaces at the start of lines "
                          f"and that every value after a colon has a space before it.") from exc
    cfg = _merge(DEFAULTS, raw)
    plan = os.environ.get("FYERS_PLAN", "").strip().lower()
    if plan:                                              # the GitHub secret FYERS_PLAN overrides the file, so no editing is needed
        cfg["fyers"]["plan"] = plan
    _validate(cfg)
    return cfg
