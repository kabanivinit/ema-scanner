"""Builds the Telegram messages: ONE message per timeframe each time a candle closes.

    ⏱ 15 MIN · candle closed 03 Nov 11:15 IST
    2 crossovers: 🟢 1 bullish · 🔴 1 bearish

    🟢 15 Min Crossover in Reliance Industries Limited, Bullish — ₹2,953.40
    🔴 15 Min Crossover in Tata Motors Limited, Bearish — ₹712.10

    Checked: Nifty 500 (499) · Indian Indices (30) · Crypto (48)

When nothing crossed, the message says so ("✅ No crossovers in this candle.") - that way silence never has to be guessed.
"""
from __future__ import annotations

import html
import re
from dataclasses import dataclass, field

from .fmt import bar_label, price
from .universe import tv_link

TF_NAME = {"15m": "15 Min", "1h": "1 Hour", "4h": "4 Hour", "1d": "1 Day", "1w": "1 Week"}
INTRADAY = ("15m", "1h", "4h")
LIMIT = 3800                    # Telegram allows 4096 characters per message; leave room for the header and footer


@dataclass
class Message:
    text: str
    signals: list = field(default_factory=list)
    tf: str = ""


def tf_name(tf: str) -> str:
    return TF_NAME.get(tf, tf)


def full_name(inst) -> str:
    """The security's full name, as in the user's example: 'Reliance Industries Limited' (NSE writes 'Ltd.')."""
    name = str(inst.name).strip() or inst.symbol
    if inst.market == "NSE":
        name = re.sub(r"\bLtd\b\.?", "Limited", name, flags=re.I)
    return name


def _order(cfg):
    return list(cfg["universes"].keys())


def _ukey(inst, cfg):
    order = _order(cfg)
    keys = sorted(inst.universes, key=lambda k: order.index(k) if k in order else 99)
    return order.index(keys[0]) if keys and keys[0] in order else 99


def _end_label(tf, end, market, cfg) -> str:
    return bar_label(tf, end, market, cfg["display_timezone"])


def _header(batch, cfg, part=None) -> str:
    tf = batch.tf
    if batch.coverage:
        top = max(batch.coverage, key=lambda c: c.bar_end)
        end, market = top.bar_end, top.market
    else:
        s = max(batch.signals, key=lambda x: x.bar_end)
        end, market = s.bar_end, s.inst.market
    label = _end_label(tf, end, market, cfg)
    when = f"candle closed {label}" if tf in INTRADAY else label
    tail = f" (part {part[0]} of {part[1]})" if part and part[1] > 1 else ""
    return f"⏱ <b>{tf_name(tf).upper()}</b>{tail} · {html.escape(when)}"


def _newest_end(batch):
    if batch.coverage:
        return max(c.bar_end for c in batch.coverage)
    return max(s.bar_end for s in batch.signals)


def _span(minutes) -> str:
    minutes = int(minutes)
    if minutes % 1440 == 0:
        d = minutes // 1440
        return f"{d} day{'s' if d != 1 else ''}"
    if minutes % 60 == 0:
        h = minutes // 60
        return f"{h} hour{'s' if h != 1 else ''}"
    return f"{minutes} minutes"


def _gap_note(batch, cfg) -> str:
    """Said only after a long absence: what the scanner could not do while it was away."""
    since = getattr(batch, "gap_from", None)
    if since is None:
        return ""
    when = since.tz_convert(cfg["display_timezone"]).strftime("%d %b %H:%M %Z")
    limit = _span(cfg["max_alert_age_minutes"][batch.tf])
    return (f"<i>⚠️ The scanner was not running from {html.escape(when)}. Crossovers on candles that closed "
            f"more than {limit} before this message were not sent.</i>")


def _footer(batch, cfg) -> str:
    out = ""
    if batch.coverage:
        newest = _newest_end(batch)
        items = []
        for c in batch.coverage:
            n = f"{c.got}" if c.got == c.total else f"{c.got} of {c.total}"
            extra = []
            if c.late:
                extra.append(f"{c.late} on delayed data")
            if batch.tf in INTRADAY and c.bar_end != newest:
                extra.append("candle " + c.bar_end.tz_convert(cfg["display_timezone"]).strftime("%H:%M"))
            items.append(f"{html.escape(c.label)} ({n}{', ' + ', '.join(extra) if extra else ''})")
        out = "\n\n<i>Checked: " + " · ".join(items) + "</i>"
    note = _gap_note(batch, cfg)
    if note:
        out += ("\n" if out else "\n\n") + note
    return out


def _line(sig, cfg, newest) -> str:
    inst = sig.inst
    name = html.escape(full_name(inst))
    if cfg["alerts"]["tradingview_links"] and inst.tv:
        name = f'<a href="{html.escape(tv_link(inst.tv), quote=True)}">{name}</a>'
    bull = sig.direction == "bull"
    text = (f"{'🟢' if bull else '🔴'} {tf_name(sig.tf)} Crossover in {name}, {'Bullish' if bull else 'Bearish'}"
            f" — {html.escape(inst.currency)}{price(sig.close)}")
    if sig.bar_end != newest:                                   # a crossover from an earlier candle (late run)
        text += f" · {html.escape(_end_label(sig.tf, sig.bar_end, inst.market, cfg))}"
    return text


def _counts(sigs) -> str:
    nb = sum(1 for s in sigs if s.direction == "bull")
    ns = len(sigs) - nb
    parts = ([f"🟢 {nb} bullish"] if nb else []) + ([f"🔴 {ns} bearish"] if ns else [])
    return f"{len(sigs)} crossover{'s' if len(sigs) != 1 else ''}: " + " · ".join(parts)


def build_tf_messages(batch, cfg) -> list:
    """The message(s) for one timeframe: its crossovers, or 'no crossovers' (if switched on for that timeframe)."""
    tf = batch.tf
    sigs = sorted(batch.signals, key=lambda s: (s.direction != "bull", _ukey(s.inst, cfg), full_name(s.inst).lower()))
    if not sigs:
        if not batch.coverage or tf not in (cfg["alerts"].get("empty_messages") or []):
            return []
        return [Message(f"{_header(batch, cfg)}\n✅ No crossovers in this candle.{_footer(batch, cfg)}", [], tf)]

    newest = _newest_end(batch)
    footer = _footer(batch, cfg)
    max_lines = int(cfg["alerts"]["max_lines_per_message"])
    budget = LIMIT - len(_header(batch, cfg, (99, 99))) - len(footer) - len(_counts(sigs)) - 40
    chunks, cur, size = [], [], 0
    for s in sigs:
        line = _line(s, cfg, newest)
        if cur and (len(cur) >= max_lines or size + len(line) + 1 > budget):
            chunks.append(cur)
            cur, size = [], 0
        cur.append((s, line))
        size += len(line) + 1
    chunks.append(cur)

    out = []
    for n, chunk in enumerate(chunks, 1):
        text = _header(batch, cfg, (n, len(chunks)))
        if n == 1:
            text += "\n" + _counts(sigs)
        text += "\n\n" + "\n".join(line for _, line in chunk)
        if n == len(chunks):
            text += footer
        out.append(Message(text, [s for s, _ in chunk], tf))
    return out


def live_message(cfg, instruments, notes, feeds="") -> str:
    s, l = cfg["ema"]["short"], cfg["ema"]["long"]
    lines = [f"✅ <b>EMA {s}/{l} scanner is live</b>", "",
             "What you will get: every time a candle closes, <b>one message per timeframe</b> - the crossovers "
             "(one line per security, 🟢 Bullish / 🔴 Bearish) or a short \"No crossovers\" note.", "",
             "Timeframes: " + " · ".join(tf_name(t) for t in cfg["timeframes"]), "", "Watching:"]
    for k, u in cfg["universes"].items():
        if not u.get("enabled", True) or k not in notes or str(notes[k]).startswith("skipped"):
            continue
        members = [i for i in instruments if k in i.universes]
        bad = notes.get(k, "").startswith("FAILED")
        text = "could not load" if bad else f"{len(members)} symbols"
        left_out = [tf_name(t) for t in cfg["timeframes"] if members and not any(t in i.tfs for i in members)]
        if left_out and not bad:
            text += " · not scanned on " + ", ".join(left_out)
        lines.append(f"{'⚠️' if bad else '•'} {html.escape(u.get('label', k))}: {text}")
    if feeds:
        lines += ["", "Prices: " + html.escape(feeds)]
    lines += ["", "Crossovers that were already visible when the scanner started were recorded silently, "
                  "so the first alerts you see are new ones."]
    return "\n".join(lines)


def health_message(problems) -> str:
    return "⚠️ <b>Scanner data problem</b>\n" + "\n".join(f"• {html.escape(p)}" for p in problems) + \
           "\nAlerts for these are paused and will retry automatically."
