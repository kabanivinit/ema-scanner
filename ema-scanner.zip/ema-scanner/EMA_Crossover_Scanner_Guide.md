# EMA 10/20 Crossover Scanner — Guide & Work Log

Prepared 01–02 Nov 2026 · version 1.1.4 (prices from TradingView, backtest added) · for a non-coder (no programming needed after the one-time setup)

---

## 0. Status at a glance

| Item | Status |
|---|---|
| Pine script updated to EMA **10 (green)** / **20 (red)** | Done — `ema_crossover.pine` |
| Scanner that applies the same logic to about 1,100 symbols on 15m / 1h / 4h / 1D / 1W | Built and tested offline (168 automated tests passing) |
| **Prices from TradingView** (your change request) | Built. Yahoo Finance stays only as an automatic backup (everything except MCX) |
| Telegram alerts (grouped, de-duplicated, clickable TradingView links) | Built and tested with a simulated Telegram |
| Daily report (Markdown + CSV, also sent to Telegram) | Built and tested |
| **Backtest: which timeframe worked better** (3 years, every security, every timeframe) | Built and tested on synthetic data (Section 5A). **Not run on real prices yet** — my workspace cannot reach market data, so it runs on GitHub (`3 - Backtest`). |
| **Live report with real prices** | **Not produced yet.** My workspace cannot reach TradingView, Yahoo or Telegram, so no live data was pulled. Your first GitHub run (Section 4) produces it in about 10–15 minutes. |
| First live test (02 Nov 2026) | Telegram works. Nifty 500, Nasdaq 100 and S&P 500 lists download. **TradingView answers from GitHub's servers for NSE, US and crypto** (400–500 candles per symbol). It returned nothing for MCX codes. |
| Commodities and Indian indices | **Commodities use ten global futures for now** (Gold, Silver, Copper, Crude WTI, Brent, Natural Gas, Aluminium, Platinum, Cotton, Soybeans) because TradingView's logged-out feed returned **no MCX data** in the first live test (02 Nov 2026). 30 NSE/BSE indices are included. Real MCX prices need a broker data feed (Section 9). |
| ⚠ Read Section 8 before relying on it | TradingView's free feed is **unofficial**, **about 15 minutes delayed** for NSE / US / MCX, and TradingView's Terms of Use restrict this kind of use. |

---

## 1. What you asked for → what was built

| You asked | Delivered |
|---|---|
| Run the Pine script logic on 6 groups of securities and report | Python scanner replicating the script exactly (Section 5), plus a daily report |
| Alert on Telegram when Short (10, green) crosses Long (20, red) on 15m, 1h, 4h, 1D, 1W | `1 - EMA Scan` runs every 15 minutes, sends one grouped message per timeframe/direction |
| Markdown file of all work | This file |
| "Back-test 3 years on different timeframes and securities; which timeframe worked better" | Workflow `3 - Backtest` and Section 5A. Results land in Telegram and in `reports/backtest/` |
| Simple for a non-coder | All settings in one file (`config.yaml`); setup is clicks only; a "Check Setup" button tells you what is wrong in plain words |
| **"Instead of Yahoo, use TradingView"** | Candles now come from TradingView's chart feed. One setting, `data_source` in `config.yaml`, picks the source: `auto` (default: TradingView first, Yahoo as backup), `tradingview` or `yahoo`. |

---

## 2. How it works (one minute)

```
GitHub (free, runs by itself every 15 min)
   │  asks TradingView's chart feed for candles (the same feed its website charts use; no login)
   │  rebuilds 4h and 1W candles exactly like TradingView
   │  waits for the feed's delay (Section 5) so a half-built candle is never judged
   │  computes EMA10 & EMA20, finds crossovers on CLOSED candles only
   │  skips anything already alerted (remembers in a small saved file)
   │  if TradingView cannot be reached: Yahoo backup (all groups except MCX)
   ▼
Telegram message ──► you
Daily 17:10 IST ──► report (.md + .csv) in Telegram and in your GitHub repo
```

TradingView's own alerts cannot do this: one alert covers one symbol on one timeframe, so 1,100 symbols × 5 timeframes is far beyond what alerts allow. That is why the scanner exists. You can still use the Pine script on charts for visual checking.

---

## 3. What is scanned

| # | Your group | What the scanner uses | Count | Source of list | TradingView code |
|---|---|---|---|---|---|
| 1 | Nifty 500 | All constituents | ~500 | Downloaded from NSE, refreshed weekly | `NSE:<symbol>` |
| 2 | Nasdaq 100 | All constituents | ~100 | Downloaded from Wikipedia, weekly | `NASDAQ:`, else `NYSE:`, else `AMEX:` (first that exists) |
| 3 | Crypto | Curated list of major coins | 48 | `config.yaml` (editable) | `BINANCE:XYZUSDT`, else `COINBASE:`, `KRAKEN:`, `BITSTAMP:` (USD) |
| 4 | Commodities | **Global futures as stand-ins for MCX**: Gold (COMEX), Silver, Copper, Crude Oil WTI, Brent, Natural Gas, Aluminium, Platinum, Cotton, Soybeans | 10 | `config.yaml` | Yahoo Finance (TradingView is not asked). The alert link opens the matching MCX chart |
| 5 | S&P 500 | All constituents | ~500 | Downloaded from Wikipedia, weekly | `NYSE:`, else `NASDAQ:`, else `AMEX:` |
| 6 | Indian indices | Nifty 50, Bank, Sensex, Next 50, Midcap 50/100/150, Smallcap 100/250, Nifty 100, 200, 500, Private Bank, Consumption, India VIX and 15 sector indices (IT, Auto, Pharma, FMCG, Metal, Realty, Energy, Infrastructure, PSU Bank, Media, Financial Services, PSE, Commodities, Services, MNC) | 30 | `config.yaml` | `NSE:CNXIT` etc. |

Overlaps (e.g. Apple is in S&P 500 and Nasdaq 100) are fetched once and alerted once, labelled with both groups. Once TradingView has answered for a symbol, the exchange that worked is remembered, so later runs are faster.

**Honest gaps:**
- **Commodities are not MCX prices.** COMEX / NYMEX / ICE futures cross at nearly the same times as MCX contracts but not identically (USD vs INR, different contract months). Alerts say "Commodities (global proxy for MCX)". NCDEX agricultural contracts are not covered.
- **MCX contracts are built in but switched off.** The 19 MCX front-month contracts (`MCX:GOLD1!` etc.) are listed in `config.yaml` under *Commodities (MCX)* with `enabled: false`. Set it to `true` and run Check Setup to try again; if TradingView still rejects them, Check Setup prints its reply. Real MCX needs a broker feed (Section 9). Note that front-month ("1!") prices jump at roll-over, which can cause one false-looking cross.
- **Indian indices: 30, not every one of the 100+.** Add more by copying a line. Nine of the 30 are marked `optional` (code not confirmed) so a wrong code never triggers an alarm.
- **Crypto: 48 major coins, not "all".** Add more by copying a line in `config.yaml`.
- **Yahoo-only mode** (`data_source: yahoo`) behaves the same for commodities and drops the 9 extra indices that exist only on TradingView.

---

## 4. One-time setup (about 20 minutes)

### Step A — Create your Telegram bot
1. In Telegram, search **@BotFather** → send `/newbot` → choose a name and a username ending in `bot`.
2. BotFather replies with a **token** (looks like `123456789:ABCdef…`). Keep it private — never paste it in chats or public places.
3. Open your new bot, press **Start**, send "hi".
4. Find your **chat ID**: in a browser open `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates` (replace `<YOUR_TOKEN>`, keep the word `bot` in front). Look for `"chat":{"id":` followed by a number — that number is your chat ID. (For a group: add the bot to the group, send a message there, reload the page; group IDs start with `-`.)

### Step B — Create the GitHub project
1. Create a free account at github.com (skip if you have one).
2. Click **New repository** → name it `ema-scanner` → choose **Public** → **Create repository**.
   *Why public:* GitHub runs public projects free. A private project has a small monthly free allowance that a 15-minute schedule will exceed. Your Telegram token stays hidden in Secrets (Step C); only the scanner code, settings and reports are visible.
3. Unzip `ema-scanner.zip` on your computer. On the new repository page click **uploading an existing file**, drag **everything inside the unzipped folder** (including the `.github` folder) into the page, then click **Commit changes**.
   - Mac hides folders starting with a dot: in Finder press **Cmd + Shift + .** to show `.github`.
   - **If your browser flattens the folders** (the upload list shows `tv.py` instead of `scanner/tv.py`) use the zip route below instead.
   - If `.github` did not upload: click **Add file → Create new file**, type `.github/workflows/scan.yml` as the file name (typing `/` creates folders), paste the text of `workflow_files_to_paste/scan.yml`, commit. Repeat for `check-setup.yml` and `daily-report.yml`.

#### Alternative to B.3: the zip route (no folders involved)
Use this if uploading folders keeps flattening them. GitHub unpacks the zip for you on every run.
1. **Do not unzip.** In the repository click **Add file → Upload files**, drag the file `ema-scanner.zip` itself onto the page, and **Commit changes**. Keep only **one** zip in the repository (delete an older one first when you update).
2. Create the workflow files by hand (**Add file → Create new file**, type the name, paste, commit): `.github/workflows/check-setup.yml`, `.github/workflows/scan.yml`, `.github/workflows/daily-report.yml` and (for the backtest) `.github/workflows/backtest.yml`. Their text is in the zip's `workflow_files_to_paste` folder (or ask me to paste it into the chat). Each begins with a step called *Unpack the scanner* that opens the zip.
3. To change settings later, create a file named `config.yaml` in the repository's main page (Add file → Create new file), paste the contents of `config.yaml` from the zip and edit it there. A `config.yaml` in the repository always wins over the one inside the zip.
4. To update the scanner: delete the old zip, upload the new one, commit.

### Step C — Add your two secrets
Repository → **Settings → Secrets and variables → Actions → New repository secret**. Add:

| Name (exactly) | Value |
|---|---|
| `TELEGRAM_BOT_TOKEN` | the token from Step A |
| `TELEGRAM_CHAT_ID` | the number from Step A |

No TradingView account, password or key is needed. The scanner never logs in to TradingView.

### Step D — Switch it on (run in this order)
Open the **Actions** tab (click the green button if GitHub asks to enable workflows), choose a workflow on the left, click **Run workflow**.

1. **0 - Check Setup (run this first)** — about 3–5 minutes. The log shows `[PASS]`, `[WARN]` or `[FAIL]` lines in plain words, and Telegram shows a "Setup check" message. It tells you whether TradingView answers from GitHub's servers, whether its newest candles are current, how delayed each market is, and which symbol codes it does not recognise. Good output looks like:
   ```
   [PASS] TradingView NSE 15m: 400 candles · newest usable candle ended ... · expected ...
   [PASS] NSE: TradingView data mode 'delayed_streaming_900' = 15 min delay (matches config)
   [PASS] TradingView sample test: data for 23 of 25 spread-out symbols
   ```
   Fix any `[FAIL]` using Section 10, or send me the log text. (`[WARN]` lines about weekends or holidays are normal.)
2. **2 - Daily Report** — about 10–15 minutes. You receive a summary plus the full report (`.md`) and data (`.csv`) in Telegram. **This is the report you asked for.** Its *Data coverage* table lists any symbol TradingView did not recognise.
3. **1 - EMA Scan** — a few minutes. Telegram shows "scanner is live". From now on it runs by itself every 15 minutes.
4. *Optional, any time:* **3 - Backtest** — see Section 5A. It never runs by itself.

The very first scan records crossovers already in progress *silently*, so you are not flooded; alerts begin from the next closed candle.

---

## 5. Exact rules used (same as your Pine script)

- **EMA:** `ta.ema(close, n)` — smoothing 2/(n+1), starting from the first candle. Short = 10 (green), Long = 20 (red).
- **Bullish cross (green above red):** EMA10 is above EMA20 now and was at or below it on the previous candle (`ta.crossover`).
- **Bearish cross:** EMA10 below EMA20 now and at or above it previously (`ta.crossunder`).
- **Closed candles only** (like TradingView "Once Per Bar Close"). A candle still forming is never used, so alerts do not appear and then vanish.
- **Candles are rebuilt like TradingView.** 15m, 1h and 1D candles come straight from TradingView; 4h candles are built from 1h and weekly candles from daily ones.
  - 4h anchors on the session open — NSE: 09:15–13:15 and 13:15–15:30; US: 09:30–13:30 and 13:30–16:00; MCX (only if you switch that group on): 09:00, 13:00, 17:00, 21:00 (last candle ends at the close); crypto: 00:00, 04:00, … UTC.
  - 1D = one exchange session; 1W = Monday–Friday for stocks and MCX, Monday–Sunday for crypto.
  - Short final candles (e.g. NSE 15:15–15:30) end at the close. MCX's close is assumed to be 23:55; in winter (23:30 close) the last candle's alert arrives up to 25 minutes later than it could — the safe direction.
- **Data delay is built in.** TradingView's free, logged-out feed is **about 15 minutes behind for NSE, US stocks and MCX; crypto is live.** The scanner adds that delay to its normal waiting time, so it never judges a candle that is still being built inside the delayed feed. In practice an alert for NSE / US / MCX arrives **roughly 20–35 minutes after the candle closes** (daily and weekly: about 35–60 minutes); crypto about 5–20 minutes. Check Setup asks TradingView what delay it applies and tells you if `feed_delay_minutes` needs changing.
- **Each crossover is alerted once.** A catch-up window (last 2–3 candles) covers a late run, and anything older than the limit in `config.yaml` is never sent.
- **Both directions** are alerted (🟢 bullish, 🔴 bearish). Change in `config.yaml` → `alerts: directions`.

### Alert example (illustrative — made-up symbols and prices)
```
🟢 BULLISH CROSS · 1H
EMA 10 (green) crossed above EMA 20 (red)
🕒 02 Nov 14:45 IST

Nifty 500 (2)
• SAMPLEA  ₹1,234.50  (+0.24%)
• SAMPLEB  ₹98.25  (+0.31%)

Crypto (1)
• BTC  $67,000.00  (+0.30%)
```
The percentage is the gap between EMA10 and EMA20. Symbol names are links that open the chart on TradingView.

### Report layout (`reports/latest.md`, also `latest.csv`)
1. **Market breadth** — % of symbols with EMA10 above EMA20, per group and timeframe.
2. **Fresh crossovers** — recent crosses per group and timeframe, newest first.
3. **Data coverage** — symbols the feed could not provide, how many candle sets TradingView and Yahoo each delivered, and codes TradingView did not recognise.
4. **Notes.**
The CSV holds every symbol × timeframe (state, EMAs, last cross, bars since cross) for Excel.

---

## 5A. Backtest — which timeframe worked better (workflow `3 - Backtest`)

**What it does.** It replays your rule over the past on every security and every timeframe: *buy at the open of the candle after EMA 10 crosses above EMA 20, sell at the open of the candle after it crosses below.* Long only (no short selling), one position at a time, the whole account in, and a cost on every buy and every sell. The costs are my guesses and you can change them: NSE 0.05 %, US 0.02 %, crypto 0.10 %, futures 0.05 % per buy or sell (`backtest:` → `cost_pct_per_side` in `config.yaml`). Candles are built exactly like the live scanner builds them (4h from hourly, weekly from daily) and only closed candles count.

**How to run it.** Actions tab → **3 - Backtest** → Run workflow. Leave the boxes as they are. I estimate 1–3 hours (the first real run will tell); Telegram then receives a summary, `best_by_security.csv` (open in Excel) and `latest.md`. The same files are saved in the repository under `reports/backtest/`. For a quick trial first, type `5` in the box *limit* (first 5 securities of each group, a few minutes); the box *only* takes group names such as `crypto,sp500`; the box *years* changes the period.

**How much history exists (this decides what can be compared).** TradingView's free feed gives about 5,000 candles per series:

| Timeframe | Stocks and indices | Crypto | Futures proxies |
|---|---|---|---|
| 1D, 1W | about 3 years tested (6 years fetched for warm-up) | about 3 years | about 3 years |
| 1H, 4H | about 2.8 years | about 7 months from TradingView; the scanner asks Yahoo too and keeps the longer history (about 2 years) | about 10 months; Yahoo extends it to about 2 years |
| 15M | about 9 months | about 7 weeks | about 8 weeks |

**So the report shows two views.**
- **A. Longest history available** (up to 3 years): typical (median) *yearly return after costs* per group and timeframe. A timeframe with less than 1 year of candles is shown with ⚠ but can never be named "best", because a few months cannot be compared fairly with years.
- **B. Same period for every timeframe** (the last 6 months): typical *total return* over just that stretch, so 15-minute candles and weekly candles are compared on equal terms. It is short, so treat it as a hint.

**Best timeframe per security** (section 3 of the report and `best_by_security.csv`): the timeframe with the highest yearly return after costs among those with at least 3 trades and 1 year of candles, next to the return on every timeframe, profit factor, win rate, number of trades, worst drop and buy & hold. The CSV also has the same-period (last 6 months) numbers and that period's best timeframe.

**Reading the numbers.** *Yearly return* = average yearly growth after costs, compounded. *Profit factor* = total profit of winning trades ÷ total loss of losing trades (above 1 = made money). *Win rate* = share of trades that made money. *Worst drop* = biggest fall from a previous high of the account. *Buy & hold* = just owning it for the same period.

**What it cannot tell you.**
- The best timeframe of a single security is the winner of several tries, so it will look better than it will be in future. The group medians are far more trustworthy than any single pick.
- Three years is one market phase; six months is far less. A rule that did well may do badly in a different phase.
- Costs are assumptions, and fills at the next open are idealised. Short timeframes trade the most and are hurt most by real costs.
- Lists are today's index members (stocks that dropped out earlier are missing), which flatters stock results.
- Commodities are global futures, not MCX prices; prices are adjusted for splits, not for dividends.

---

## 6. Everyday use (all in `config.yaml` — click the pencil icon on GitHub, then Commit)

| I want to… | Change |
|---|---|
| Use Yahoo only (e.g. TradingView stops working) | `data_source: yahoo` — near-real-time, but MCX is replaced by global futures |
| Use TradingView only, no backup | `data_source: tradingview` |
| Switch a timeframe off everywhere | Delete it from `timeframes:` at the top |
| Fewer alerts for one group | Under that group add `timeframes: ["1h", "4h", "1d", "1w"]` |
| Only bullish (or only bearish) alerts | `directions: bullish` |
| Different EMA lengths | `ema:` → `short` and `long` (also change the Pine script inputs) |
| Add an index or MCX contract | Copy a line under `lists:` and change `symbol`, `name` and `tv:` — open the chart on tradingview.com and copy the `EXCHANGE:CODE` shown at the top left |
| Add a coin | Copy a crypto line and change `symbol` (e.g. `PEPE-USD`) and `name`. If the coin's ticker differs from the symbol, add `base: "TICKER"` |
| Stop alarms about a code you are unsure of | Add `optional: true` to that line |
| Turn a whole group off | `enabled: false` |
| Pause everything | Actions tab → workflow → **⋯ → Disable workflow** |
| Test without sending anything | Run `1 - EMA Scan` with **Dry run** ticked |
| Backtest a different period | `backtest:` → `years` (or the box *years* when running `3 - Backtest`) |
| Change the backtest trading costs | `backtest:` → `cost_pct_per_side` (percent per buy and per sell, per market) |
| Switch the "last 6 months, same period" comparison off or change its length | `backtest:` → `recent_years` (`0` = off) |

A symbol you add later may send one alert if it crossed within the last few candles.

---

## 7. Assumptions I made — please confirm or tell me to change

1. Alert on **both** bullish and bearish crossovers.
2. A **public** GitHub repository is acceptable (needed for free 15-minute runs).
3. 15-minute alerts on **all** ~1,100 symbols, as you specified. This will be chatty and is the heaviest load on TradingView. Easy to narrow later.
4. TradingView is used **without logging in** (free delayed feed), with Yahoo as automatic backup.
5. Commodities use **global futures** until a broker feed is added; NCDEX is not covered.
6. Times are shown in IST.

---

## 8. Limits and risks (read once)

| Risk | What it means | What to do |
|---|---|---|
| **TradingView's terms** | TradingView has no official data service for programs. The scanner uses the same web connection TradingView's own charts use, without logging in. TradingView's Terms of Use (sections 2, 3 and 10) say its market data is for personal, display-only use, restrict machine-driven processing that does not display the data, and give no promise that its interfaces stay the same. Reading data this way for your own alerts goes against the wording of those terms, so treat it as a grey area. In practice TradingView could block GitHub's servers or change the connection at any time, without notice. Your TradingView account is not involved because the scanner never logs in. | Your decision. It is personal use, paced gently and not redistributed. Kill-switch: `data_source: yahoo`. The official route for a short list is in Section 9. |
| **15-minute delay** | The free feed is about 15 minutes behind for NSE, US and MCX (crypto is live). Paying TradingView for real-time data would **not** help, because the scanner does not log in. | If minutes matter: broker data feed (Section 9). |
| **Blocking or throttling** | With 15m on every symbol the scanner makes roughly 35,000–45,000 chart requests a day. It is paced (25 symbols per connection, short pauses, one retry), stops early if TradingView goes silent, and hands over to Yahoo for everything except MCX. You get a ⚠ message in Telegram (at most once every 6 hours) if fewer than 80% of symbols return data. I cannot promise TradingView will never limit it. | Run Check Setup and the first Daily Report. If many symbols show "no data", send me the *Data coverage* table; fallback is narrowing 15m. |
| **Unofficial connection can change** | If TradingView changes its format, candles stop arriving until the scanner is updated. | Check Setup shows it in plain words; send me the log. Meanwhile set `data_source: yahoo`. |
| **GitHub timing** | Scheduled runs can start late (commonly 5–30 minutes at busy times) and occasionally get skipped. Together with the data delay, NSE / US / MCX alerts are not suited to scalping. | For on-time alerts: Section 9. |
| **60-day rule** | GitHub silently disables scheduled workflows in a public repo with no activity for 60 days. The daily report saves a file each day, which normally counts as activity. | If it ever stops: Actions tab → re-enable the workflow. |
| **Data differences** | Candles are the ones TradingView's charts show, so crosses should match your charts closely. Crypto depends on the exchange used (Binance first); your chart may use another, so edge cases can differ. | Treat alerts as a screen; confirm on the chart. |
| **Exchange holidays** | Handled: before scanning, the scanner checks that a benchmark index actually has the new candle. | None. |
| **Backtest limits** | Free candles reach back about 3 years for daily/weekly, 2.8 years for hourly (stocks) but only months for 15-minute; results are in-sample, long only, cost-assumption dependent and one market phase. | Read Section 5A before acting on any "best timeframe". |
| **Crossovers are mechanical signals** | EMA crossovers lag and whipsaw in sideways markets. | Your judgement and risk rules still apply. |
| **Partly live-tested** | The first Check Setup run (02 Nov 2026, a Sunday) confirmed that TradingView answers from GitHub for NSE, US and crypto, that day candles carry the right date, and that Telegram works. **Not yet confirmed:** the actual data delay on a trading day (TradingView does not report its data mode to logged-out visitors), whether every crypto/index code exists (the first Daily Report lists any it does not), and why the final 15 minutes of Friday's NSE session (the 15:15–15:30 candle) was missing from its 15m and 1h data. The scanner never alerts on a candle that has not arrived, but run Check Setup once during Indian market hours (about 10:00 IST) and send me the log. | Send me that log. |

---

## 9. Next steps — only if you want them

| Item | What | Needed from you |
|---|---|---|
| Real MCX commodities and real-time NSE candles (no 15-minute delay) | Pull from a broker data API. You have both Kite and Fyers; Fyers' API is free for data, Kite's historical data is a paid add-on. Needs a daily login token; we would agree a safe way to refresh it. | Which broker; an API app. Nothing shared in chat — secrets go into GitHub Secrets. |
| TradingView's own alerts for a short list | Use the Pine alert conditions on ~20 key charts and send them to Telegram through a webhook. This is TradingView's official route and is real-time, but alert counts are limited and webhooks need a paid TradingView plan. | Your plan type |
| On-time scans | Run the same scanner every minute on a small cloud server or always-on PC | Server or PC |
| More indices / coins / NCDEX | Add codes | The list |

### Decisions that are yours (I assumed the first answer in each)
1. Both bullish **and** bearish alerts?
2. Public repository?
3. 15m on everything, or only indices, crypto, commodities and (say) Nifty 500 leaders?
4. Accept unofficial, 15-minute-delayed TradingView data for NSE / US / MCX — or start with `data_source: yahoo` (near-real-time, no MCX) until you have seen the first report?

---

## 10. Troubleshooting

| What you see | Likely cause | Fix |
|---|---|---|
| Check Setup: "Telegram secrets are missing" | Secret name typed differently | Re-add `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` exactly as written |
| "chat not found" / "Unauthorized" | Bot not started, wrong chat ID, or wrong token | Press **Start** on the bot, redo Step A.4; for groups add the bot first |
| `config.yaml: universe 'commodities' has market 'MCX'. Allowed: NSE, US, CRYPTO, FUT` | An old copy of the scanner is running with the new `config.yaml` (the new code did not land in the `scanner` folder) | Use the zip route in Section 4; the log's first line must show the newest version number |
| Upload list shows `tv.py` instead of `scanner/tv.py` | The browser dropped the folder structure | Use the zip route in Section 4 |
| Nasdaq 100 list `FAIL` (older versions only) | Wikipedia changed its page | Update to version 1.1.1 or later (the log's first line shows the version) |
| Nifty 500 list `FAIL` | NSE blocked the download | Download the file from `https://nsearchives.nseindia.com/content/indices/ind_nifty500list.csv` in your browser, upload it to the repo as `universe_cache/nifty500.csv` (Add file → Upload files) |
| `[WARN] TradingView is not working from here - the scanner will use the Yahoo backup` | TradingView refuses GitHub's servers, or changed its connection | Alerts still run on Yahoo (no MCX). Send me the log. Set `data_source: yahoo` to stop trying TradingView |
| `[FAIL] Neither TradingView nor Yahoo returned usable data` | Both sources unreachable from GitHub | Re-run later; if it repeats, send me the log |
| "TradingView does not recognise: …" (Check Setup or report) | A symbol code is wrong or retired | Open the chart on tradingview.com, copy `EXCHANGE:CODE` into that line's `tv:`; add `optional: true` to silence it |
| `[WARN] TradingView: no 15m candles for MCX benchmark MCX:GOLD1!` | TradingView's logged-out feed has no MCX data (seen 02 Nov 2026) | Leave the MCX group switched off (default). Commodities use global futures |
| `[WARN] … data mode '…' = N min delay, but config.yaml assumes M` | The delay differs from my assumption | Copy the line the message suggests into `feed_delay_minutes` |
| Many symbols "no data from the data feed" | Throttling or wrong codes | Wait and re-run; send me the *Data coverage* table |
| ⚠ Telegram message "TradingView feed not reachable … using the Yahoo backup" | TradingView was down or blocked during that run | Yahoo covers everything except MCX; if it persists for a day, tell me |
| No alerts for hours | Market closed, nothing crossed, or runs delayed | Check the Actions tab: recent `1 - EMA Scan` runs should be green. Weekends: only crypto moves |
| Too many alerts | 15m on ~1,100 symbols | Section 6 |
| Run shows a red ✗ | Telegram rejected a message, or setup problem | Open the run → read the last lines; send them to me |
| `3 - Backtest` shows many "no data from the data feed" rows | TradingView throttled the long download | Re-run later; use the box *only* for the group that is missing |
| `3 - Backtest` is red but `reports/backtest/` has files | Telegram refused a message, or the run hit its time limit | The files are saved anyway; send me the last lines of the log |
| Backtest says "not enough trades or history" for a group or security | The candles did not reach back far enough, or too few trades | Normal for 15M (months of data) and for brand-new listings; see Section 5A |

---

## 11. Testing performed (in my workspace, synthetic data)

168 automated tests passed on pandas 3.0.5 (Python 3.13), 3.1.0 **and** 2.2.3: 16 on EMA/candle timing, 16 on end-to-end runs, 16 on lists/config/Telegram/report, 10 on the workflow files and the zip-upload route, 31 on TradingView (connection, source switching and the setup check) and 79 on the backtest.

- EMA and cross maths match the Pine definitions, including equal-value edge cases.
- Candle building: NSE/US/crypto/MCX/futures sessions, 4h anchoring, short final candles, US daylight-saving change, incomplete blocks dropped, weekly Monday–Friday.
- Forming candle never used; exchange-closed periods and weekends handled; a candle still being built inside a 15-minute-delayed feed is never judged.
- **TradingView connection against a simulated TradingView:** message framing, heartbeat replies, candle parsing, every kind of failure reply, timeouts, one retry, symbols per connection and pauses, time budget, "stop early when TradingView goes silent", trying the next exchange for a symbol and remembering the winner, remembering unknown symbols for 2 days, never logging in, and TradingView candles giving the same signals as the equivalent candles for NSE / US / MCX / crypto.
- **Source switching:** `auto`, `tradingview` and `yahoo` modes; Yahoo backup used only for symbols it knows; the outage reported once; unknown or optional codes never counted against data coverage.
- Setup check: source-aware output, delay mismatch warnings, both sources down.
- End-to-end runs: silent first run → one alert → no duplicates; Telegram failure retried without losing the alert; low data coverage pauses and warns; missing secrets fail loudly; dry run sends nothing; report command writes files and sends summary + documents.
- Messages: HTML escaping, splitting under Telegram's length limit, bullish before bearish, rate-limit handling, token never printed.
- **Backtest:** the trade-by-trade maths is checked against an independent bar-by-bar calculation on 32 random price paths (with gaps, different costs and periods); known cases (one cross, last-candle signals, warm-up, missing opens, costs, buy & hold, the same-period window); chunked downloading, time limit, a failing chunk, TradingView resting and retrying, Yahoo extension of hourly history; best-timeframe rules and flags, group pooling, report text, the command and its options; a full-size dry run (1,188 securities × 5 timeframes) finished in about a minute of computing and 150 MB of memory.
- Yahoo parsing for both column layouts; throttle detection with back-off; list downloads (NSE, Wikipedia) and cache fallback; config mistakes explained in plain words; workflow files validated.

**Not testable here:** live TradingView, Yahoo, NSE, Wikipedia, Telegram and GitHub runs (my workspace blocks them). *Check Setup* verifies each.

---

## 12. Files

| File | Purpose |
|---|---|
| `EMA_Crossover_Scanner_Guide.md` | This guide |
| `ema_crossover.pine` | Updated Pine script (10 green / 20 red, richer alert text) |
| `config.yaml` | Your settings (data source, groups, lists) |
| `scanner/` | The scanner code: signals, candle timing, TradingView connection (`tv.py`), Yahoo backup and source switching (`data.py`), lists, Telegram, report, backtest (`backtest.py`, `backtest_report.py`) |
| `.github/workflows/` | The four buttons: `check-setup`, `scan`, `daily-report`, `backtest` |
| `workflow_files_to_paste/` | Copies of the four workflow files (for the paste method in Step B.3) |
| `tests/` | Automated tests |
| `reports/` | Created on first run: `latest.md`, `latest.csv`, `archive/`; the backtest adds `backtest/` (`latest.md`, `results.csv`, `best_by_security.csv`, `archive/`) |

### Pine script changes
Defaults 9/21 → **10/20**; short line colour blue → **green**; long line orange → **red**; alert texts now include exchange, symbol, timeframe and close. In TradingView: Pine Editor → paste → **Add to chart**; for a manual alert choose condition *EMA Cross → Bullish/Bearish EMA Cross*, trigger **Once Per Bar Close**.

---

## 13. Sources

- [TradingView Terms of Use and policies — display-only, personal-use and machine-driven wording (sections 2, 3, 10)](https://in.tradingview.com/policies)
- [python-tradingview-ta FAQ — notes on TradingView data and delays](https://python-tradingview-ta.readthedocs.io/en/stable/faq.html)
- [tvdatafeed-enhanced](https://pypi.org/project/tvdatafeed-enhanced/) and [tradingview-scraper](https://pypi.org/project/tradingview-scraper/) — open-source libraries whose chart-feed connection format the scanner follows (code was read, not copied)
- [GitHub Actions scheduled workflows — interval, delays, 60-day rule, default branch](https://cronuru.com/guides/github-actions-scheduled-workflows)
- [GitHub Docs — Actions billing and usage (public repositories are free)](https://docs.github.com/en/actions/reference/usage-limits-billing-and-administration)
- [yfinance community discussion on Yahoo rate limiting](https://github.com/ranaroussi/yfinance/discussions/2431)

## 14. Change log
- 1.1.4 · 02 Nov 2026 · New workflow `3 - Backtest` (3-year, every timeframe, every security, long-only, with costs; long-history view plus a same-period view; best timeframe per security; Telegram digest + CSV + Markdown). Report notes now describe TradingView's delay correctly and no longer mention MCX when it is off. Tests 168.
- 1.1.3 · 02 Nov 2026 · After the first live Check Setup: MCX group switched off by default (TradingView returned no MCX data) and commodities use global futures; Check Setup now judges the sample on codes TradingView recognises and prints TradingView's own reply for rejected ones; EOS marked optional.
- 1.1.2 · 02 Nov 2026 · Zip route: all three workflows can unpack `ema-scanner.zip` themselves, so no folder upload is needed. Tests 87.
- 1.1.1 · 01 Nov 2026 · Nasdaq 100 list: Wikipedia no longer carries the table, so the scanner now tries a second web page and, as a last resort, a copy built into the scanner (found by your first Check Setup run). Tests 83.
- 1.1.0 · 01 Nov 2026 · Prices now come from TradingView's chart feed (Yahoo is the automatic backup; `data_source` setting). Added MCX commodity contracts, 9 more NSE indices, a 15-minute data-delay allowance, symbol fall-backs and bad-code memory, and a TradingView-aware Check Setup. Tests 50 → 82.
- 1.0.0 · 01 Nov 2026 · First release (Yahoo Finance data).
