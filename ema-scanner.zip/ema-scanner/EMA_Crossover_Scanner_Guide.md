# EMA 10/20 Crossover Scanner — Guide & Work Log

Prepared 01–05 Nov 2026 · version 1.3.0 (Fyers real-time Indian prices with an automatic daily Fyers login using your TOTP key, one clear Telegram message per timeframe, punctual schedule, no alert bursts after a late run, commodity contracts found even when Fyers' list cannot be read, setup check and report that say on Telegram what is missing and why, a steady Fyers pace that waits and tries again when Fyers says "too fast") · for a non-coder (no programming needed after the one-time setup)
---

## 0. Status at a glance

| Item | Status |
|---|---|
| Pine script updated to EMA **10 (green)** / **20 (red)** | Done — `ema_crossover.pine` |
| Scanner that applies the same logic to about 1,100 symbols on 15m / 1h / 4h / 1D / 1W | Built, running on your GitHub since 02–03 Nov. 301 automated tests passing |
| **03 Nov change 1 — clear, regular Telegram messages** | Done and tested. One message per timeframe each time a candle closes; one line per security (`🟢 15 Min Crossover in Reliance Industries Limited, Bullish`); a "✅ No crossovers in this candle" message when nothing crossed (Section 5) |
| **03 Nov change 2 — Fyers for NSE / BSE / MCX, TradingView for everything else** | Built and tested against a **simulated** Fyers (my workspace cannot reach the real one). **First real results, 04 Nov:** the by-hand Fyers login worked, the Setup check had no failures and the daily report arrived. The **commodity (MCX) row of the first two reports stayed empty**. The report's own "Where data is missing" lines (added in 1.2.2) showed the cause: Fyers answered *"You've reached the Standard plan limit of 5 requests/second"* and the scanner gave up on Fyers for the rest of that run (TradingView has no MCX prices). **Fixed in 1.2.3** (steady pace, wait and try again; Section 14). Confirm with a new *Check Setup* run (Step D), which now asks for the commodities exactly the way the report does, then a new *Daily Report*. **05 Nov, a second problem:** Fyers switched off its 15-day login renewal (SEBI rule: a fresh two-step login every day), so the scanner could not get into Fyers on a new day. **Fixed in 1.3.0:** the scanner logs in by itself every day with your user ID, TOTP key and PIN (Step E); this part has only been tested against copies of Fyers' login steps, not the real Fyers, until your first *Check Setup* shows `the scanner logged in by itself just now`. |
| **03 Nov change 3 — GitHub runs every 15 minutes, on time** | GitHub's own timer now fires every 5 minutes (it is often late). For punctual runs add the free outside timer (Section 4, Step F, about 10 minutes). |
| What your Fyers plan decides | **Free (`standard`) plan:** real-time candles for 1 Hour, 4 Hour, 1 Day, 1 Week on Indian stocks, indices and MCX; 15 Min stays on TradingView (about 15 minutes late) and MCX has no 15 Min. **Paid (`prime`) plan:** everything Indian in real time (Section 5, table "When alerts arrive") |
| Backtest (3 years, every timeframe, every security) | Built. First real run on 03 Nov finished (about 16 minutes); its "save a copy" step was fixed afterwards (Section 5A). It does not use Fyers |
| Commodities | **Real MCX contracts via Fyers** once the Fyers secrets are added (19 contracts). Without Fyers: ten global futures as stand-ins |
| ⚠ Read Section 8 before relying on it | TradingView's feed is **unofficial**, **about 15 minutes late for US stocks**, and TradingView's terms restrict this use. Crossovers are mechanical signals, not advice |
---

## 1. What you asked for → what was built

| You asked | Delivered |
|---|---|
| Run the Pine script logic on 6 groups of securities and report | Python scanner replicating the script exactly (Section 5), plus a daily report |
| Alert on Telegram when Short (10, green) crosses Long (20, red) on 15m, 1h, 4h, 1D, 1W | `1 - EMA Scan`: one Telegram message per timeframe each time a candle closes, one line per security |
| Markdown file of all work | This file |
| Back-test 3 years; which timeframe worked better | Workflow `3 - Backtest` and Section 5A |
| Simple for a non-coder | Settings in one file (`config.yaml`) plus GitHub secrets; setup is clicks only; *Check Setup* tells you what is wrong in plain words |
| "Instead of Yahoo, use TradingView" (02 Nov) | Done: TradingView first, Yahoo only as an automatic backup |
| **03 Nov (1)** Clearer messages at regular intervals: a separate message per timeframe naming the timeframe, one line per security like *"15 Min Crossover in Reliance Industries Limited, Bullish/Bearish"*, and a message saying so when a timeframe has no alarms | Done (Section 5). The 15 Min message follows every quarter-hour candle, the 1 Hour message every hourly candle, and so on |
| **03 Nov (2)** Use Fyers for all Indian securities on NSE, BSE and MCX; TradingView for the rest | Done (Sections 3, 4 and 5). Fyers logs in with your own API app; since 1.3.0 the scanner logs in by itself every day (Step E) - Fyers no longer allows longer logins |
| **03 Nov (3)** Run GitHub every 15 minutes so messages are not delayed | GitHub's timer every 5 minutes as a safety net, plus an outside timer that starts each scan at :02, :17, :32, :47 (Step F) |
---

## 2. How it works (one minute)

```
Outside timer (cron-job.org, free) starts the scan at :02 :17 :32 :47   +   GitHub's own timer every 5 minutes (backup)
   ▼
GitHub (free) runs the scanner
   │  Indian stocks, indices and MCX commodities (NSE / BSE / MCX)  → Fyers (logs in by itself every day: user ID + TOTP + PIN)
   │  US stocks and crypto                                          → TradingView's chart feed (US ≈ 15 min late, crypto live)
   │  anything Fyers cannot deliver                                 → TradingView, then Yahoo as the last backup
   │  rebuilds 4h and 1W candles exactly like TradingView
   │  waits for the feed's delay so a half-built candle is never judged
   │  computes EMA10 & EMA20, finds crossovers on CLOSED candles only
   │  skips anything already announced (small saved memory)
   ▼
Telegram: ONE message per timeframe each time a candle closes  ──► you
Daily 17:10 IST ──► report (.md + .csv) in Telegram
```

TradingView's own alerts cannot do this: one alert covers one symbol on one timeframe, so 1,100 symbols × 5 timeframes is far beyond what alerts allow. That is why the scanner exists. You can still use the Pine script on charts for visual checking.
---

## 3. What is scanned

| # | Your group | What the scanner uses | Count | Source of list | Prices from |
|---|---|---|---|---|---|
| 1 | Nifty 500 | All constituents | ~500 | Downloaded from NSE, refreshed weekly | **Fyers** (`NSE:<symbol>-EQ`); TradingView if Fyers cannot deliver |
| 2 | Nasdaq 100 | All constituents | ~100 | Downloaded from Wikipedia, weekly | TradingView (`NASDAQ:`, else `NYSE:`, else `AMEX:`) |
| 3 | Crypto | Curated list of major coins | 48 | `config.yaml` (editable) | TradingView (`BINANCE:XYZUSDT`, else `COINBASE:`, `KRAKEN:`, `BITSTAMP:`) |
| 4 | Commodities | **Real MCX front-month futures**: Gold, Silver, Crude Oil, Natural Gas, Copper, Zinc, Lead, Aluminium, Nickel plus their mini/micro versions, Mentha Oil and Crude Palm Oil (19 contracts; the 9 less-liquid ones are marked `optional`). The scanner picks the nearest contract each month by itself and switches to next month 3 days before month end | 19 | `config.yaml` + Fyers' public contract list | **Fyers only** (no other source has MCX). Without the Fyers secrets this group switches itself off and ten global futures take its place |
| 5 | S&P 500 | All constituents | ~500 | Downloaded from Wikipedia, weekly | TradingView |
| 6 | Indian indices | Nifty 50, Bank, Sensex (BSE), Next 50, Midcap, Smallcap, Nifty 100/200/500, sector indices (IT, Auto, Pharma, FMCG, Metal, Realty, Energy, Infrastructure, PSU Bank, Media, Financial Services, PSE, Commodities, Services, MNC) and India VIX | 30 | `config.yaml` | **Fyers** (`NSE:NIFTY50-INDEX`, `BSE:SENSEX-INDEX` …) |

Overlaps (e.g. Apple is in S&P 500 and Nasdaq 100) are fetched once and alerted once, labelled with both groups. The scanner matches every Indian name to Fyers' own public symbol lists; *Check Setup* prints how many matched and which did not (those fall back to TradingView).

**Honest gaps:**
- **MCX on the free Fyers plan has no 15 Min timeframe** (too many requests for the free daily allowance, and TradingView has no MCX prices). It is scanned on 1 Hour, 4 Hour, 1 Day and 1 Week. The first Telegram message and *Check Setup* say so. The paid plan has all five.
- **MCX contracts roll every month.** Front-month prices jump at roll-over, which can cause one false-looking cross around the 25th–1st of the month.
- **Indian indices: 30, not every one of the 100+.** Add more by copying a line. Nine of the 30 are marked `optional` (code not confirmed) so a wrong code never triggers an alarm.
- **Crypto: 48 major coins, not "all".** Add more by copying a line in `config.yaml`.
- **NCDEX and BSE-only stocks outside Nifty 500 are not included.** Add lines under `lists:` if you want specific ones.
- **Backtest and Yahoo-only mode** still use the ten global futures for commodities (no MCX history is available that way).
---

## 4. Setup (first time about 30 minutes; updating an existing installation: Step G, about 10)

### Step A — Create your Telegram bot
1. In Telegram, search **@BotFather** → send `/newbot` → choose a name and a username ending in `bot`.
2. BotFather replies with a **token** (looks like `123456789:ABCdef…`). Keep it private — never paste it in chats or public places.
3. Open your new bot, press **Start**, send "hi".
4. Find your **chat ID**: in a browser open `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates` (replace `<YOUR_TOKEN>`, keep the word `bot` in front). Look for `"chat":{"id":` followed by a number — that number is your chat ID. (For a group: add the bot to the group, send a message there, reload the page; group IDs start with `-`.)

### Step B — Create the GitHub project
1. Create a free account at github.com (skip if you have one).
2. Click **New repository** → name it `ema-scanner` → choose **Public** → **Create repository**.
   *Why public:* GitHub runs public projects free. A private project has a small monthly free allowance that a 15-minute schedule will exceed. Your Telegram token stays hidden in Secrets (Step C); only the scanner code, settings and reports are visible.
3. Unzip `ema-scanner.zip` on your computer. On the new repository page click **uploading an existing file**, drag **everything inside the unzipped folder** (including the `.github` folder) into the page, then click **Commit changes**.
   - Mac hides folders starting with a dot: in Finder press **Cmd + Shift + .** to show `.github`.
   - **If your browser flattens the folders** (the upload list shows `tv.py` instead of `scanner/tv.py`) use the zip route below instead.
   - If `.github` did not upload: click **Add file → Create new file**, type `.github/workflows/scan.yml` as the file name (typing `/` creates folders), paste the text of `workflow_files_to_paste/scan.yml`, commit. Repeat for `check-setup.yml`, `daily-report.yml`, `backtest.yml` and `fyers-login.yml`.

#### Alternative to B.3: the zip route (no folders involved)
Use this if uploading folders keeps flattening them. GitHub unpacks the zip for you on every run.
1. **Do not unzip.** In the repository click **Add file → Upload files**, drag the file `ema-scanner.zip` itself onto the page, and **Commit changes**. Keep only **one** zip in the repository (delete an older one first when you update).
2. Create the workflow files by hand (**Add file → Create new file**, type the name, paste, commit): `.github/workflows/check-setup.yml`, `.github/workflows/scan.yml`, `.github/workflows/daily-report.yml`, `.github/workflows/backtest.yml` and `.github/workflows/fyers-login.yml`. Their text is in the zip's `workflow_files_to_paste` folder (or ask me to paste it into the chat). Each begins with a step called *Unpack the scanner* that opens the zip.
3. To change settings later, create a file named `config.yaml` in the repository's main page (Add file → Create new file), paste the contents of `config.yaml` from the zip and edit it there. A `config.yaml` in the repository always wins over the one inside the zip.
4. To update the scanner: delete the old zip, upload the new one, commit.

### Step C — Add your secrets
Repository → **Settings → Secrets and variables → Actions → New repository secret**. The names must match exactly. Never paste the values anywhere else — not in chat, not in a file.

| Name (exactly) | Value | Needed? |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | the token from Step A | yes |
| `TELEGRAM_CHAT_ID` | the number from Step A | yes |
| `FYERS_APP_ID` | the App ID of your Fyers API app (looks like `AB12CD34EF-100`) | for Fyers |
| `FYERS_SECRET_ID` | that app's Secret ID | for Fyers |
| `FYERS_PIN` | your 4-digit Fyers PIN (the one you type in the Fyers app; the daily login uses it) | for Fyers |
| `FYERS_USER_ID` | your Fyers client ID (looks like `XY12345`) | for the automatic daily login (Step E) |
| `FYERS_TOTP_KEY` | the long code of letters and digits that Fyers shows under the TOTP QR picture (Step E, part 1) | for the automatic daily login (Step E) |
| `FYERS_PLAN` | `standard` (free plan) or `prime` (paid plan). Leave it out = `standard` | optional |
| `FYERS_REDIRECT_URI` | only if your Fyers app uses another redirect address than `https://trade.fyers.in/api-login/redirect-uri/index.html`; it must be exactly the address saved in your Fyers app | optional |

Without the first three Fyers secrets the scanner works as before: TradingView for everything, global futures instead of MCX. Without `FYERS_USER_ID` and `FYERS_TOTP_KEY` Fyers works only on days when you log in by hand (Step E, emergency route). Your TradingView subscription is not used by the scanner (it never logs in to TradingView; see Section 8).

### Step D — Switch it on (run in this order)
Open the **Actions** tab, choose a workflow on the left, click **Run workflow**.

1. **0 - Check Setup (run this first)** — about 5 minutes. The log shows `[PASS]`, `[WARN]` or `[FAIL]` lines in plain words and Telegram gets a "Setup check" message that lists every warning and failure (so you can read it on your phone without opening the log). It logs in to Fyers by itself during this check (Step E). If it says `[FAIL] Fyers login: …`, the text names the secret that is wrong (Section 10).
2. **4 - Fyers Login** — the test button for the automatic login (Step E, part 3). Optional once Check Setup shows `Fyers login works`.
3. **0 - Check Setup** again. Good Fyers lines look like this (your numbers will differ):
   ```
   [PASS] Fyers codes found for 548 of 560 Indian symbols
   [INFO] MCX contracts in use: Gold → GOLD26DECFUT; Crude Oil → CRUDEOIL26NOVFUT …
   [PASS] Fyers login works · the scanner logged in by itself just now (user ID + TOTP code + PIN)
   [PASS] Fyers Nifty 50 (NSE:NIFTY50-INDEX) 1h: 300 candles · newest candle starts 03 Nov 14:15 IST
   [PASS] Fyers requests needed per trading day ≈ 4,650 (allowance in use: 4,700 on the standard plan)
   ```
   If a line says `[FAIL]`, use Section 10 or send me the log text (it never contains your secrets).
4. **2 - Daily Report** — about 10–15 minutes; summary plus the full report (`.md`) and data (`.csv`) arrive in Telegram.
5. **1 - EMA Scan** — Telegram shows "scanner is live". From then on it runs by itself (Step F makes it punctual).
6. *Optional, any time:* **3 - Backtest** (Section 5A). It never runs by itself.

The very first scan records crossovers already in progress *silently*, so you are not flooded; alerts begin from the next closed candle. The same happens once when you update from an older version: its old alert memory is discarded, so no backlog of old alerts arrives.

### Step E — Fyers: automatic daily login (do once, about 10 minutes)
Since 5 Nov 2026 Fyers asks for a fresh two-step login **every day** (a SEBI rule); the old "renew for 15 days" no longer exists. The scanner now does the daily login by itself, the way the Fyers app does: your user ID, then the 6-digit TOTP code (it works that code out from your TOTP key), then your PIN. You set this up once.

**Part 1 — Get your TOTP key**
1. Log in at **fyers.in/web** in a browser (the Fyers app works too: Menu → Profile).
2. Click your **Profile** icon → the **Others** tab → **External 2FA TOTP**.
3. If it offers **Enable**: click it. A QR picture appears and, as text next to or under it, a **long code of capital letters and digits** — that is your **TOTP key**. Copy it into a safe note **right now**: it is shown only at this moment. Then scan the QR with an authenticator app (Google Authenticator or Microsoft Authenticator), type the 6-digit code and your Fyers PIN, and click **Enable**.
4. If it already says TOTP is on and you never saved the key: click **Disable** (confirm), then do point 3. The new QR replaces the old one — delete the old Fyers entry in your authenticator app and scan the new QR.
5. If you cannot find any text code next to the QR, tell me what the screen shows (do not send the code).

**Part 2 — Add the two secrets**
Repository → **Settings → Secrets and variables → Actions → New repository secret**:
- `FYERS_USER_ID` = your Fyers client ID (like `XY12345`, shown on your Fyers profile).
- `FYERS_TOTP_KEY` = the long code from part 1 (spaces in it do not matter).
- Check that `FYERS_PIN` is your real 4-digit Fyers PIN. If you change any Fyers secret later, nothing else is needed: the next login simply uses it.

**Part 3 — Test it**
1. Update to 1.3.0 (Step G): new zip and the four changed workflow files.
2. Actions → **4 - Fyers Login** → **Run workflow** → leave the box **empty** → Run. Within a minute Telegram shows **✅ Fyers login works**. If it shows **❌ Fyers login failed**, the message names the secret that is wrong (Section 10).
3. Actions → **0 - Check Setup** → expect `[PASS] Fyers login works · the scanner logged in by itself just now`.

**Part 4 — What happens from now on**
- You do nothing. The first run each day that needs Indian prices logs in (about 10 seconds); every later run reuses that day's pass. The pass is kept **encrypted** in the scanner's private memory (not in the repository) with a key made from your Fyers secrets. If Fyers drops the pass earlier, the scanner logs in once more.
- A refused login is never repeated in a loop. Wrong **PIN**: no new try until tomorrow (wrong PINs can lock a Fyers account). Wrong user ID / app secrets: wait 1 hour. Wrong TOTP: wait 3 hours. At most 6 automatic tries a day. A Fyers hiccup is simply tried again on the next run. **4 - Fyers Login** and **0 - Check Setup** ignore the waiting, so after fixing a secret just run one of them.
- If the login fails you get one ⚠ message on Telegram (repeated at most every few hours) that says why; meanwhile Indian prices come from TradingView (about 15 minutes late, no MCX).
- **Emergency route** (if Fyers ever changes its login so that the automatic login stops working): Actions → **4 - Fyers Login** → Run workflow → type `link` in the box → Telegram sends the old by-hand login link. Open it, log in at Fyers, copy the whole web address you land on (it contains `auth_code=`), then run **4 - Fyers Login** again with that address pasted into the box. That gives you prices for that one day.

**Part 5 — Safety, in plain words**
- Your user ID, TOTP key and PIN together can log in to your Fyers account. They stay in GitHub's private secrets: nobody can read them from the public repository and GitHub hides them in logs. Protect your GitHub account itself: **GitHub → Settings → Password and authentication → turn on two-factor authentication**.
- If you ever think they leaked: in Fyers disable and re-enable TOTP (you get a new key), change your PIN, and update the three secrets.
- This is **not an official Fyers data service**: the scanner repeats the steps of Fyers' own login page (the same ones that open-source Fyers login tools use). Fyers may change them without notice. That is why the emergency route exists, and why this part is marked "not yet proven on the real Fyers" in Section 8 until your first Check Setup shows it working.

### Step F — Punctual alerts: the outside timer (recommended, about 10 minutes)
GitHub's own timer is unreliable: its documentation says scheduled runs can be delayed and, when GitHub is busy, dropped. On this project (3 Nov) it started your scan by timer only once in 11 hours, and the 17:10 IST report at 00:09 IST. A free outside service, **cron-job.org**, can press the "Run workflow" button for you at exactly :02, :17, :32 and :47 of every hour. GitHub's own timer stays on as a backup; if both fire, the second one finds nothing new and does nothing.

**1. Make a limited key (token) on GitHub**
- GitHub → your profile picture → **Settings → Developer settings → Personal access tokens → Fine-grained tokens → Generate new token**.
- Name: `ema-scanner-timer`. Expiration: the longest offered (put the date in your calendar; when it ends the outside timer stops and GitHub's own timer carries on).
- Repository access: **Only select repositories → ema-scanner**.
- Permissions → Repository permissions → **Actions: Read and write**. Leave everything else "No access".
- **Generate token** and copy it once. It can only start workflows of this one repository. Keep it private.

**2. Make the timer on cron-job.org**
- Create a free account at cron-job.org → **Create cronjob**.
- Title: `EMA scan`. URL: `https://api.github.com/repos/kabanivinit/ema-scanner/actions/workflows/scan.yml/dispatches`
- Schedule: **User-defined** → Minutes: tick **2, 17, 32, 47**; every hour, every day, every month.
- Advanced settings: Request method **POST**. Request body: `{"ref":"main"}` (use the name shown in the branch drop-down on your repository's main page if it is not `main`). Headers (add one by one):
  - `Authorization` = `Bearer ` followed by your token
  - `Accept` = `application/vnd.github+json`
  - `X-GitHub-Api-Version` = `2022-11-28`
  - `Content-Type` = `application/json`
- Save, then press **Test run**. A green result (HTTP 200 or 204) means GitHub accepted it; within a minute a new run of **1 - EMA Scan** appears in your Actions tab.
- Optional: switch on cron-job.org's e-mail when a job fails.

If the test shows 401: token wrong or expired. 403 or 404: the token lacks "Actions: Read and write", is not limited to this repository, or the repository name in the URL is wrong. 422: the branch name in the body is wrong.

### Step G — Updating your existing installation to 1.3.0 (about 10 minutes if you already run 1.2.x)
**Updating from 1.2.x to 1.3.0:** (1) replace the zip (step 1 below); (2) replace **four** workflow files — in `.github/workflows` open `scan.yml`, `daily-report.yml`, `check-setup.yml` and `fyers-login.yml`, click the pencil icon, select all, paste the new text (same file names, they came with this guide), commit — each gains two lines that hand the new secrets to the scanner; without them the automatic login cannot work; (3) add the two secrets and test (Step E, parts 1–3); (4) run **2 - Daily Report** so the MCX row can be checked. `backtest.yml` is unchanged.

**Older note (1.2.1 / 1.2.2 → 1.2.3):**
only step 1 below (replace the zip), then run **0 - Check Setup** (it takes a few minutes now: it asks for every commodity the way the report does), then **2 - Daily Report**; no workflow file changes. The Setup check message on Telegram now lists every warning and every commodity contract, so you do not need to open any log.

**Updating from older versions:**

1. Repository → click `ema-scanner.zip` → delete it (trash icon) → commit; then **Add file → Upload files** → drop the new `ema-scanner.zip` → commit. Keep only one zip.
2. Replace three workflow files and add one: for `.github/workflows/scan.yml`, `check-setup.yml` and `daily-report.yml` open the file → pencil icon → select all → paste the new text (files `scan.yml`, `check-setup.yml`, `daily-report.yml` that came with this guide) → commit. Then **Add file → Create new file** → name `.github/workflows/fyers-login.yml` → paste → commit. (`backtest.yml` is unchanged.)
3. Add the secrets of Step C.
4. Run Step D (Check Setup → Daily Report → Scan).
5. Do Step F.
6. The first scan after the update sends one "scanner is live" message and no old alerts: the old alert memory is discarded once, so nothing from the hours before the update arrives late.

Your repository has no `config.yaml` of its own, so the one inside the zip applies. To change a setting later, create `config.yaml` as described in the zip route (3 above); for the Fyers plan simply use the secret `FYERS_PLAN`.
---

## 5. Exact rules used (same as your Pine script)

- **EMA:** `ta.ema(close, n)` — smoothing 2/(n+1), starting from the first candle. Short = 10 (green), Long = 20 (red).
- **Bullish cross (green above red):** EMA10 is above EMA20 now and was at or below it on the previous candle (`ta.crossover`).
- **Bearish cross:** EMA10 below EMA20 now and at or above it previously (`ta.crossunder`).
- **Closed candles only** (like TradingView "Once Per Bar Close"). A candle still forming is never used, so alerts do not appear and then vanish.
- **Candles are rebuilt like TradingView.** 15m, 1h and 1D candles come straight from the feed (Fyers for Indian markets, TradingView for the rest); 4h candles are built from 1h and weekly candles from daily ones.
  - 4h anchors on the session open — NSE: 09:15–13:15 and 13:15–15:30; US: 09:30–13:30 and 13:30–16:00; MCX: 09:00, 13:00, 17:00, 21:00 (last candle ends at the close); crypto: 00:00, 04:00, … UTC.
  - 1D = one exchange session; 1W = Monday–Friday for stocks and MCX, Monday–Sunday for crypto.
  - Short final candles (e.g. NSE 15:15–15:30) end at the close. MCX's close is assumed to be 23:55; in winter (23:30 close) the last candle's alert arrives up to 25 minutes later than it could — the safe direction.
- **Data delay is built in.** The scanner waits a short time after a candle closes (1 minute for 15m, 2 for 1h/4h, 15 for 1D/1W) plus the delay of the feed that delivered it, so it never judges a candle that is still being built. Fyers is real time; TradingView's logged-out feed is about 15 minutes behind for US stocks, crypto is live. Check Setup asks TradingView what delay it applies and tells you if `feed_delay_minutes` needs changing.

  **When alerts arrive** (after the candle closes; with the outside timer of Step F; add the unknown lateness of GitHub's own timer if you skip it):

  | Candle | Data from | Alert usually arrives |
  |---|---|---|
  | Crypto, any timeframe | TradingView (live) | 3–6 minutes |
  | US stocks, 15m / 1h / 4h | TradingView (≈15 min late) | about 20 minutes |
  | Indian stocks, indices and MCX · 1h, 4h · **paid Fyers plan** | Fyers | 3–6 minutes |
  | Indian stocks, indices and MCX · 15m · **paid Fyers plan** | Fyers | 3–6 minutes |
  | Indian stocks and indices · 1h, 4h · **free Fyers plan** | Fyers, paced at 40 requests a minute (a full round of ~550 symbols takes ~13 minutes) | about 15–20 minutes |
  | Indian stocks and indices · 15m · **free Fyers plan** | TradingView (≈15 min late) | about 20 minutes |
  | MCX · 1h, 4h, 1d, 1w · free plan | Fyers (only 19 contracts, quick) | 3–6 minutes (1d / 1w: about 20) |
  | MCX · 15m · **free Fyers plan** | not scanned | — |
  | 1 Day and 1 Week, any market | the feed above | about 20 minutes (the daily candle needs 15 minutes to settle) |

  Because slower feeds finish later, one quarter-hour can produce **more than one 15 Min message**: each message names its candle time and lists what it checked (`Checked: Crypto (48) · Nasdaq 100 (100, candle 18:45)`). On the free Fyers plan the slow Indian round is handled **after** crypto and US stocks, so a slow Indian round never holds those back.
- **Each crossover is alerted once.** If a run is late, the next one looks back over the candles it missed - but only those that closed within the age limits in `config.yaml` (`max_alert_age_minutes`: 75 minutes for 15 Min, 5 hours for 1 Hour, 20 hours for 4 Hour, 3 days for 1 Day, 10 days for 1 Week, about the last five candles each). Older crossovers would only be stale noise, and a long absence would otherwise arrive as one big burst. When something was left out, the message says so: *"⚠️ The scanner was not running from 03 Nov 21:44 IST. Crossovers on candles that closed more than 75 minutes before this message were not sent."*
- **Both directions** are alerted (🟢 bullish, 🔴 bearish). Change in `config.yaml` → `alerts: directions`.

### Telegram messages (illustrative — made-up prices)
One message per timeframe each time a candle closes. The first line always names the timeframe and the candle:
```
⏱ 15 MIN · candle closed 03 Nov 11:15 IST
2 crossovers: 🟢 1 bullish · 🔴 1 bearish

🟢 15 Min Crossover in Reliance Industries Limited, Bullish — ₹2,953.40
🔴 15 Min Crossover in Tata Motors Limited, Bearish — ₹712.10

Checked: Nifty 500 (499) · Indian Indices (30) · Crypto (48)
```
When nothing crossed:
```
⏱ 1 HOUR · candle closed 03 Nov 11:15 IST
✅ No crossovers in this candle.

Checked: Nifty 500 (499) · Indian Indices (30)
```
- 🟢 = EMA 10 crossed **above** EMA 20 (bullish), 🔴 = crossed **below** (bearish). The price is the candle's close. Names are links that open the chart on TradingView.
- A line that ends with a date and time is a crossover from an *earlier* candle that a late run caught up on.
- "(30 of 48)" in the *Checked* line means that many symbols delivered data for that candle; the rest are retried and listed in a ⚠ note.
- **Too many messages?** With "No crossovers" notes on, expect roughly 130–170 messages a day, most of them 15 Min. In `config.yaml` → `alerts: empty_messages:` delete a timeframe (for example `"15m"`) and that timeframe then sends only real crossovers.

### Report layout (sent to Telegram as `latest.md` and `latest.csv`; no longer saved in the public repository)
1. **Market breadth** — % of symbols with EMA10 above EMA20, per group and timeframe.
2. **Fresh crossovers** — recent crosses per group and timeframe, newest first.
3. **Data coverage** — symbols the feed could not provide, how many candle sets TradingView and Yahoo each delivered, and codes TradingView did not recognise.
4. **Notes.**
The CSV holds every symbol × timeframe (state, EMAs, last cross, bars since cross) for Excel.

---

## 5A. Backtest — which timeframe worked better (workflow `3 - Backtest`)

**What it does.** It replays your rule over the past on every security and every timeframe: *buy at the open of the candle after EMA 10 crosses above EMA 20, sell at the open of the candle after it crosses below.* Long only (no short selling), one position at a time, the whole account in, and a cost on every buy and every sell. The costs are my guesses and you can change them: NSE 0.05 %, US 0.02 %, crypto 0.10 %, futures 0.05 % per buy or sell (`backtest:` → `cost_pct_per_side` in `config.yaml`). Candles are built exactly like the live scanner builds them (4h from hourly, weekly from daily) and only closed candles count.

**How to run it.** Actions tab → **3 - Backtest** → Run workflow. Leave the boxes as they are. The first real run (03 Nov 2026) took about 16 minutes; allow up to a few hours if the data feed is slow. Telegram then receives a summary, `best_by_security.csv` (open in Excel) and `latest.md`. The same files are saved in the repository under `reports/backtest/`. For a quick trial first, type `5` in the box *limit* (first 5 securities of each group, a few minutes); the box *only* takes group names such as `crypto,sp500`; the box *years* changes the period.

**How much history exists (this decides what can be compared).** TradingView's free feed gives about 5,000 candles per series:

| Timeframe | Stocks and indices | Crypto | Futures proxies |
|---|---|---|---|
| 1D, 1W | about 3 years tested (6 years fetched for warm-up) | about 3 years | about 3 years |
| 1H, 4H | about 2.8 years | about 7 months from TradingView; the scanner asks Yahoo too and keeps the longer history (about 2 years) | about 10 months; Yahoo extends it to about 2 years |
| 15M | about 9 months | about 7 weeks | about 8 weeks |

**So the report shows two views.**
- **A. Longest history available** (up to 3 years): typical (median) *yearly return after costs* per group and timeframe. A timeframe with less than 1 year of candles is shown with ⚠ but can never be named "best", because a few months cannot be compared fairly with years.
- **B. Same period for every timeframe** (the last 6 months): typical *total return* over just that stretch, so 15-minute candles and weekly candles are compared on equal terms. It is short, so treat it as a hint.

**Best timeframe per security** (section 3 of the report and `best_by_security.csv`): the timeframe with the highest yearly return after costs among those with at least 3 trades and 1 year of candles, next to the return on every timeframe, profit factor, win rate, number of trades, worst drop and buy & hold. The CSV also has the same-period (last 6 months) numbers and that period's best timeframe.

**Reading the numbers.** *Yearly return* = average yearly growth after costs, compounded. *Profit factor* = total profit of winning trades ÷ total loss of losing trades (above 1 = made money). *Win rate* = share of trades that made money. *Worst drop* = biggest fall from a previous high of the account. *Buy & hold* = just owning it for the same period.

**What it cannot tell you.**
- The best timeframe of a single security is the winner of several tries, so it will look better than it will be in future. The group medians are far more trustworthy than any single pick.
- Three years is one market phase; six months is far less. A rule that did well may do badly in a different phase.
- Costs are assumptions, and fills at the next open are idealised. Short timeframes trade the most and are hurt most by real costs.
- Lists are today's index members (stocks that dropped out earlier are missing), which flatters stock results.
- Commodities are global futures, not MCX prices; prices are adjusted for splits, not for dividends.

---

## 6. Everyday use (all in `config.yaml` — click the pencil icon on GitHub, then Commit)

| I want to… | Change |
|---|---|
| Use Yahoo only (e.g. TradingView stops working) | `data_source: yahoo` — near-real-time, but MCX is replaced by global futures |
| Use TradingView only, no backup | `data_source: tradingview` |
| Tell the scanner I have Fyers **Prime** (paid) | Add the GitHub secret `FYERS_PLAN` = `prime` (no file to edit). Back to free: `standard` |
| Stop using Fyers (go back to TradingView) | Delete the three `FYERS_…` secrets, or `fyers:` → `enabled: false` |
| Fewer "No crossovers" messages | `alerts:` → `empty_messages:` → delete the timeframes you do not want it for |
| Switch a timeframe off everywhere | Delete it from `timeframes:` at the top |
| Fewer alerts for one group | Under that group add `timeframes: ["1h", "4h", "1d", "1w"]` |
| Only bullish (or only bearish) alerts | `directions: bullish` |
| Different EMA lengths | `ema:` → `short` and `long` (also change the Pine script inputs) |
| Add an index or MCX contract | Copy a line under `lists:` and change `symbol`, `name` and `tv:` — open the chart on tradingview.com and copy the `EXCHANGE:CODE` shown at the top left |
| Add a coin | Copy a crypto line and change `symbol` (e.g. `PEPE-USD`) and `name`. If the coin's ticker differs from the symbol, add `base: "TICKER"` |
| Stop alarms about a code you are unsure of | Add `optional: true` to that line |
| Turn a whole group off | `enabled: false` |
| Pause everything | Actions tab → workflow → **⋯ → Disable workflow** |
| Test without sending anything | Run `1 - EMA Scan` with **Dry run** ticked |
| Backtest a different period | `backtest:` → `years` (or the box *years* when running `3 - Backtest`) |
| Change the backtest trading costs | `backtest:` → `cost_pct_per_side` (percent per buy and per sell, per market) |
| Switch the "last 6 months, same period" comparison off or change its length | `backtest:` → `recent_years` (`0` = off) |

A symbol you add later may send one alert if it crossed within the last few candles.

---

## 7. Assumptions I made — please confirm or tell me to change

1. Alert on **both** bullish and bearish crossovers.
2. A **public** GitHub repository is acceptable (needed for free frequent runs). Nothing price-based is saved publicly any more: the daily report goes to your Telegram only (since 03 Nov); the repository keeps only code, settings and public symbol lists.
3. 15-minute alerts on **all** ~1,100 symbols, as you specified — about 130–170 Telegram messages a day with the "No crossovers" notes on (see Section 5).
4. Fyers plan = **free (`standard`)** until you tell me otherwise (secret `FYERS_PLAN`).
5. US stocks and crypto use TradingView **without logging in**. Crypto is real time for everyone; US stocks are as late as Check Setup's "TradingView data mode" line says (assumed 15 minutes). Your TradingView subscription is not used (you asked on 04 Nov for the login route - see Section 9).
6. Times are shown in IST.
---

## 8. Limits and risks (read once)

| Risk | What it means | What to do |
|---|---|---|
| **TradingView's terms** | TradingView has no official data service for programs. For US stocks and crypto the scanner uses the same web connection TradingView's own charts use, without logging in. TradingView's Terms of Use (sections 2, 3 and 10) say its market data is for personal, display-only use, restrict machine-driven processing and give no promise that the connection stays the same. Reading data this way for your own alerts goes against the wording, so treat it as a grey area. TradingView could block GitHub's servers or change the connection at any time. Your TradingView account is not involved because the scanner never logs in — which is also why your premium subscription does not make this data real time. | Your decision. Personal use, paced gently, not redistributed. Kill-switch: `data_source: yahoo`. The official route for a short list is in Section 9. |
| **Fyers is official but has limits** | Fyers' data API is meant for your own use. Free plan: 5,000 data requests a day, 50 a minute, 5 a second; paid plan: 500,000 a day, 500 a minute, 10 a second. The scanner stays below these. Going over the per-minute limit more than 3 times in a day blocks the account until the next day, so the scanner spreads its requests evenly (at most 2 a second on the free plan, 6 on the paid plan - Fyers counts requests when they *arrive*, and a burst of four can land as six) and, when Fyers still says "too fast", waits a few seconds, slows down and tries again. It gives up on Fyers for the rest of that run only if that keeps happening (more than 8 times), or at once when Fyers names the per-minute or the daily limit. | Check Setup prints the pace and the daily need. Fyers terms are yours to honour: personal use only, nothing redistributed. |
| **Free-plan consequences** | A full round of ~550 Indian symbols takes ~13 minutes at the free pace, so Indian 1 Hour / 4 Hour alerts arrive 15–20 minutes after the candle (about the same as TradingView's delay, but with exact, complete candles). 15 Min stays on TradingView (≈ 15 minutes late) and MCX has no 15 Min. The free plan is used almost fully (about 4,650 of the 4,700 requests a day the scanner allows itself); on a bad day with many retries the last Indian checks of the afternoon use TradingView instead. | Paid Fyers plan + secret `FYERS_PLAN` = `prime` makes everything Indian real time (about 1–2 minutes per round). |
| **Fyers needs a fresh login every day** | Fyers' rule (SEBI), not mine: since 5 Nov there is no longer a 15-day login. The scanner logs in by itself with your user ID, TOTP key and PIN (Step E). That uses the steps of Fyers' own login page, which are **not part of Fyers' published API documents** and can change without notice. | If the automatic login ever stops working you get a ⚠ message that says why, Indian prices fall back to TradingView (about 15 minutes late, no MCX), and the emergency route in Step E (type `link`) gives you the old by-hand login for that day. |
| **Fyers part is only partly proven on the real service** | Proven on 04 Nov: the by-hand login and the Setup check's sample candles. Not yet proven: the automatic TOTP login (new in 1.3.0; proven once Check Setup shows `Fyers login works · the scanner logged in by itself just now`), commodity contracts (the first two reports had no MCX data because of Fyers' 5-per-second limit; fixed in 1.2.3, proven only once the next Check Setup and Daily Report show them) and a full day of scans. I could not reach Fyers from my workspace. The parts that talk to Fyers (candles, symbol matching, contract names) follow Fyers' published documents and were tested against a simulated Fyers; the automatic login follows the login steps that open-source Fyers login tools use and was tested against a simulated Fyers and a local copy of those steps (including the published test values for the 6-digit code). Likely first-day surprises: a symbol name that does not match, the date stamp of daily candles, the MCX contract name. | Run Check Setup right after the login and send me its Fyers lines. Anything Fyers cannot deliver automatically comes from TradingView instead (TradingView has no MCX prices, so commodities need Fyers). |
| **Blocking or throttling of TradingView** | Indian symbols no longer go through TradingView when Fyers works, so the load on TradingView is far lower. It is still paced (25 symbols per connection, short pauses, one retry), stops early if TradingView goes silent and hands over to Yahoo (except MCX). You get a ⚠ message (at most once every 6 hours) if fewer than 80 % of symbols return data. | Run Check Setup and the Daily Report; send me the *Data coverage* table if many symbols show "no data". |
| **Unofficial connection can change** | If TradingView changes its format, candles stop arriving until the scanner is updated. | Check Setup shows it in plain words; send me the log. Meanwhile set `data_source: yahoo`. |
| **GitHub timing** | GitHub's own timer is often late and sometimes skips runs (on 3 Nov it started your scan once in 11 hours). The outside timer (Step F) starts each scan on time; GitHub's timer is the backup. If the outside timer's token expires, only the backup remains. | Do Step F. Put the token's expiry date in your calendar. |
| **Message volume** | With "No crossovers" notes on, roughly 130–170 Telegram messages a day (most are 15 Min). | `alerts: empty_messages:` (Section 6). Mute the chat at night if you like — crypto candles never stop. |
| **Privacy of a public repository** | The repository is public, so anyone can read its code, settings and run logs. Nothing secret is printed there (GitHub also hides secret values), the daily report goes to Telegram only, and your Fyers login is stored encrypted in GitHub's private cache — not in the repository. The pasted login address in "4 - Fyers Login" appears in that run's page but is a one-time code that is useless without your Secret ID. Reports saved earlier (before 03 Nov) are still in the `reports` folder; delete them if you wish. | Never put tokens in config files or chat. |
| **60-day rule** | GitHub switches off scheduled workflows in a public repository with no activity for 60 days. | If it ever stops: Actions tab → re-enable. The outside timer is not affected. |
| **Data differences** | Fyers candles come from the exchange feed; TradingView's charts may differ slightly (volume-weighted closes, different crypto exchange), so edge cases can differ from your chart. | Treat alerts as a screen; confirm on the chart. |
| **Exchange holidays** | Handled: before scanning, the scanner checks that a benchmark index actually has the new candle. | None. |
| **Backtest limits** | Free candles reach back about 3 years for daily/weekly, 2.8 years for hourly (stocks) but only months for 15-minute; results are in-sample, long only, cost-assumption dependent and one market phase. The backtest does not use Fyers, so commodities there are the global futures. | Read Section 5A before acting on any "best timeframe". |
| **Crossovers are mechanical signals** | EMA crossovers lag and whipsaw in sideways markets. This is a screening tool, not investment advice; the decisions and the risk are yours. | Your judgement and risk rules still apply. |
---

## 9. Next steps — only if you want them

| Item | What | Needed from you |
|---|---|---|
| Real-time 15 Min for Indian stocks and MCX | Switch to the paid FYERS Prime plan (₹499 a month + 18 % GST on Fyers' support page, checked 04 Nov 2026; up to 5,00,000 data requests a day), then set the secret `FYERS_PLAN` = `prime` | Your decision |
| Kite (Zerodha) as a data source | **Not built.** Kite's free "Personal" API has no market data; "Connect" costs ₹500 a month per app and includes it (limits: 3 history requests and 1 quote request a second, no daily cap listed; Zerodha support pages, checked 04 Nov 2026). The blocker is the login: the Kite key ends every morning before market open, so a fresh login with password and 2-step code is needed every day. Running that unattended would mean keeping your Zerodha password and TOTP key in GitHub, on an account that can place orders. Fyers' login lasts about 15 days and needs only your PIN in between | Nothing - stay with Fyers |
| Make the free Fyers plan fast too | "Smart screening": ask Fyers for cheap price snapshots of all symbols and download candles only for symbols close to a crossover. It would give real-time 15 Min on the free plan, but needs a day of careful work and a few days of watching before I would trust it | Tell me if you want it |
| Real-time US stocks | Only through your TradingView login (a session cookie). Crypto needs nothing: TradingView says all its crypto exchanges are real time without a login. For US stocks TradingView says its paid plans do not include the NASDAQ/NYSE real-time fees (a separate add-on). You said yes on 04 Nov; I will build it once Check Setup's "TradingView data mode" line shows US stocks as delayed and you have that add-on. TradingView's terms do not allow programs to log in this way, I cannot test it here, and it can break without notice, so it is **not built yet** | Send me the "TradingView data mode" lines from your next Check Setup |
| TradingView's own alerts for a short list | Use the Pine alert conditions on ~20 key charts and send them to Telegram through a webhook (official, real-time, limited counts; webhooks need a paid TradingView plan) | Your plan type |
| More indices / coins / NCDEX | Add codes | The list |

### Decisions that are yours (I assumed the first answer in each)
1. Both bullish **and** bearish alerts?
2. Public repository?
3. Keep "No crossovers" messages for every timeframe (chatty) or only for 1 Hour and above?
4. Which Fyers plan do you have — free or paid? (You said: free.)
5. US stocks: stay on logged-out TradingView, or the riskier cookie route? (You said yes to the cookie route on 04 Nov; waiting for the "TradingView data mode" lines, see Section 9.)
---

## 10. Troubleshooting

| What you see | Likely cause | Fix |
|---|---|---|
| **2 - Daily Report** is red at the step "Keep the symbol lists in the repository" with `error: cannot pull with rebase: You have unstaged changes` | The run rewrites report files of earlier days that are still stored in the repository, and Git refuses to update while they are changed (seen on 04 Nov 2026). The report itself had already reached Telegram | Replace `daily-report.yml` with the version dated 04 Nov (this guide's change log, 1.2.1) - it ignores such files and, if saving ever fails, only shows a ⚠ note instead of a red run |
| Check Setup: "Telegram secrets are missing" | Secret name typed differently | Re-add `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` exactly as written |
| "chat not found" / "Unauthorized" | Bot not started, wrong chat ID, or wrong token | Press **Start** on the bot, redo Step A.4; for groups add the bot first |
| `config.yaml: universe 'commodities' has market 'MCX'. Allowed: NSE, US, CRYPTO, FUT` | An old copy of the scanner is running with the new `config.yaml` (the new code did not land in the `scanner` folder) | Use the zip route in Section 4; the log's first line must show the newest version number |
| Upload list shows `tv.py` instead of `scanner/tv.py` | The browser dropped the folder structure | Use the zip route in Section 4 |
| Nasdaq 100 list `FAIL` (older versions only) | Wikipedia changed its page | Update to version 1.1.1 or later (the log's first line shows the version) |
| Nifty 500 list `FAIL` | NSE blocked the download | Download the file from `https://nsearchives.nseindia.com/content/indices/ind_nifty500list.csv` in your browser, upload it to the repo as `universe_cache/nifty500.csv` (Add file → Upload files) |
| `[WARN] TradingView is not working from here - the scanner will use the Yahoo backup` | TradingView refuses GitHub's servers, or changed its connection | Alerts still run on Yahoo (no MCX). Send me the log. Set `data_source: yahoo` to stop trying TradingView |
| `[FAIL] Neither TradingView nor Yahoo returned usable data` | Both sources unreachable from GitHub | Re-run later; if it repeats, send me the log |
| "TradingView does not recognise: …" (Check Setup or report) | A symbol code is wrong or retired | Open the chart on tradingview.com, copy `EXCHANGE:CODE` into that line's `tv:`; add `optional: true` to silence it |
| `[WARN] TradingView: no 15m candles for MCX benchmark MCX:GOLD1!` | TradingView's logged-out feed has no MCX data (seen 02 Nov 2026) | Leave the MCX group switched off (default). Commodities use global futures |
| `[WARN] … data mode '…' = N min delay, but config.yaml assumes M` | The delay differs from my assumption | Copy the line the message suggests into `feed_delay_minutes` |
| Many symbols "no data from the data feed" | Throttling or wrong codes | Wait and re-run; send me the *Data coverage* table |
| ⚠ Telegram message "TradingView feed not reachable … using the Yahoo backup" | TradingView was down or blocked during that run | Yahoo covers everything except MCX; if it persists for a day, tell me |
| No Telegram message for 30 minutes or more | The scan is not running (timer), or a Telegram/GitHub problem. Crypto candles close all day and night, so silence is never normal | Actions tab: recent `1 - EMA Scan` runs should be green and recent. Check the outside timer (Step F) |
| Too many messages | 15 Min on ~1,100 symbols, plus a "No crossovers" note after every candle | Section 6: `alerts: empty_messages:` |
| Run shows a red ✗ | Telegram rejected a message, or setup problem | Open the run → read the last lines; send them to me |
| `3 - Backtest` shows many "no data from the data feed" rows | TradingView throttled the long download | Re-run later; use the box *only* for the group that is missing |
| `3 - Backtest` is red but `reports/backtest/` has files | Telegram refused a message, or the run hit its time limit | The files are saved anyway; send me the last lines of the log |
| `3 - Backtest` is red at its last step "Keep a copy of the results in the repository" (`exit code 128`, seen 03 Nov 2026) | The answer **was already sent to Telegram**; only saving a copy in the repo failed, because git refused to pull while the restored symbol memory had changed a file | Nothing is lost. Paste the `backtest.yml` dated 03 Nov 2026 into `.github/workflows/backtest.yml` (the last step now cleans up first, and only shows a warning if saving still fails) |
| Backtest says "not enough trades or history" for a group or security | The candles did not reach back far enough, or too few trades | Normal for 15M (months of data) and for brand-new listings; see Section 5A |
| Check Setup: `[FAIL] Fyers login: Fyers wants a new login every day … add the GitHub secrets FYERS_USER_ID and FYERS_TOTP_KEY` | The two login secrets are not added yet | Step E, parts 1–2 |
| `Fyers did not accept the user ID (secret FYERS_USER_ID)` | The client ID is wrong (it must be like `XY12345`, not an e-mail address or phone number) | Correct the secret, run **4 - Fyers Login** |
| `Fyers did not accept the 6-digit TOTP code` | `FYERS_TOTP_KEY` is wrong or incomplete, or TOTP is not switched on in Fyers, or you disabled and re-enabled TOTP afterwards (that makes a new key) | Step E part 1 (get the key again), update the secret, run **4 - Fyers Login** |
| `Fyers did not accept the PIN (secret FYERS_PIN)` | The PIN secret is not your Fyers PIN. The scanner then waits until tomorrow on purpose (wrong PINs can lock the account) | Correct the secret, run **4 - Fyers Login** (it ignores the waiting) |
| `Fyers would not hand out the app login` | `FYERS_APP_ID` / `FYERS_SECRET_ID` wrong, or `FYERS_REDIRECT_URI` differs from the redirect address saved in your Fyers app | Compare with your Fyers API app page; fix; run **4 - Fyers Login** |
| `the scanner waits until … before it tries again` | A login was refused a short while ago; the wait protects your account | Fix what the first message said, then run **4 - Fyers Login** (it ignores the waiting) |
| `Fyers' login servers are busy` / `could not reach Fyers` | A hiccup at Fyers or the network | Nothing: the next run tries again |
| `the automatic Fyers login was tried 6 times today` | Fyers kept dropping or refusing the passes it gave | It rests until tomorrow; run **4 - Fyers Login** to try now; if it repeats, send me the message |
| `Fyers refuses the day-pass it handed out a moment ago` | The login works but Fyers rejects the price requests (for example your API app is not allowed to read data, or Fyers is having a problem) | Check that your Fyers API app is active (myapi.fyers.in), then run **0 - Check Setup** and send me the Fyers lines |
| Telegram "❌ Fyers login failed … Invalid auth code" | The pasted address was used already, is older than a few minutes, or was cut off | Run **4 - Fyers Login** with an empty box for a fresh link; copy the *whole* address |
| `Fyers: Fyers said we are going too fast … the rest of this run uses TradingView` | Since 1.2.3 the scanner already waited and tried again several times before giving up, so Fyers kept refusing (or named the per-minute / daily limit). The rest of that run used TradingView (no MCX there) | Send me the line; check no other program of yours uses the same Fyers app at the same time |
| Setup check: `Fyers asked the scanner to slow down N time(s) … carried on` | Fyers said "too fast" a few times; the scanner waited, lowered its pace and nothing was lost | Nothing to do; tell me if N is large |
| `Fyers: today's request allowance is used up` | The free plan's daily requests ran out (it is used almost fully; retries on a bad day tip it over) | The rest of the day those symbols come from TradingView (15 minutes late); the paid plan removes it |
| `Fyers: this run's time allowance … is used up` | A free-plan round was slower than 18 minutes | The rest came from TradingView; tell me if it repeats |
| `Fyers codes found for X of Y … not found: …` | Some names do not exist in Fyers' list under the name I expect | Those use TradingView; send me the names |
| `MCX contracts in use: …` looks wrong | Month roll-over or a renamed contract | Send me the line. Since 1.2.2 the scanner picks the nearest contract that has not expired (using the last trading day in Fyers' list when it has one) and tries the next contracts if one has no recent candles |
| Report or Setup check says `Commodities (MCX) 1h: … without data - Fyers: …` | The text after *Fyers:* is Fyers' own answer (for example *Please provide a valid symbol* = the contract code does not exist; *no candles* = nothing traded) | Send me the line - it names the commodities and the reason |
| `Fyers' list of commodity contracts could not be read …` | Fyers' public symbol list could not be downloaded or is in a layout I do not know | Commodity codes are worked out from the month and the first one with recent candles is kept for the day; nothing to do unless commodities still miss data |
| `No Fyers contract code was found for any commodity (the list had N usable entries; first ones: …)` | The list was read, but no entry looks like `MCX:GOLD26DECFUT` | Send me this line (it shows what the list contains) |
| Setup check on Telegram shows ⚠ lines | Every `[WARN]` / `[FAIL]` of the log is repeated there | Section 10 rows above, or send me a screenshot of the message |
| Two or three "15 MIN" messages in one quarter-hour | Slower feeds finish later; each message says which candle and which groups it covers | Normal (Section 5, "When alerts arrive") |
| Scans start at odd minutes | The outside timer is not working and GitHub's own timer is late | Check cron-job.org's history; the Actions tab shows `workflow_dispatch` runs when the outside timer fires |
| cron-job.org test shows 401 / 403 / 404 / 422 | Token wrong or expired / token lacks "Actions: Read and write" or the repository / wrong repository name / wrong branch name | Step F |
---

## 11. Testing performed (in my workspace, synthetic data and simulated services)

301 automated tests pass: 79 on the backtest, 100 on Fyers (the automatic login with your TOTP key - the 6-digit code is checked against the published test values and the whole login against a local copy of Fyers' login steps -, encrypted storage, even pacing, waiting and trying again on "too fast", daily budget, symbol matching, commodity contract choice and spare contracts, candles, fall-back to TradingView, commands, the Telegram setup message), 32 on TradingView and source switching, 27 on end-to-end runs (including the late-run safeguard), 23 on messages/lists/config/Telegram, 24 on the workflow files, the zip route and the save-a-copy steps of the backtest and the daily report (run against throw-away git repositories), 16 on EMA and candle timing.

- EMA and cross maths match the Pine definitions, including equal-value edge cases; candle building for every market (NSE, US, crypto, MCX, futures), 4h anchoring, short final candles, daylight-saving change, weekly candles.
- Forming candle never used; weekends and exchange-closed periods handled; a candle still being built inside a delayed feed is never judged.
- **Messages:** one message per timeframe; the "No crossovers" note; lines in your wording (`15 Min Crossover in Reliance Industries Limited, Bullish`); crossovers from an earlier candle labelled; splitting under Telegram's length limit; a failed send is retried and never lost or repeated; a late run still finds the crossover.
- **Fyers (against a simulated Fyers):** the automatic daily login (each step, the code made only when it still has time left, the cookie kept between steps, the code read from the redirect), what each refusal says and how long the scanner then waits (a wrong PIN until tomorrow), at most six tries a day, no login loop when Fyers keeps refusing a new pass; login link and address parsing; encrypted login that only your own secrets can open; one new login for all parallel requests; even pacing below the per-second, per-minute and per-day limits; MCX share of the daily allowance; wait-and-retry on "too fast" (stop only when it persists, or for a minute / daily limit); Check Setup asking for the commodities the way the report does; run time limit; symbol matching for stocks, indices (including second names) and MCX contracts with month roll; weekly candles from two daily requests; Check Setup output; TradingView fall-back with a Telegram notice.
- **Fast markets first:** on the free plan crypto and US alerts go out before the slow Indian round starts, and a crash in the slow round does not lose or repeat them.
- **Workflows:** all five parse; every one that reads prices gets the Fyers secrets; the pasted login address travels through an environment variable, never into shell text; Check Setup cannot change the memory; the saved login can never be committed; the daily report is not published in the repository.
- **Backtest:** trade-by-trade maths checked against an independent calculation on 32 random price paths; chunked downloading, time limit, best-timeframe rules and report text.

**Not testable here:** live Fyers, TradingView, Yahoo, NSE, Wikipedia, Telegram, GitHub and cron-job.org (my workspace blocks them). *Check Setup* verifies each of them on your GitHub.
---

## 12. Files

| File | Purpose |
|---|---|
| `EMA_Crossover_Scanner_Guide.md` | This guide |
| `ema_crossover.pine` | Updated Pine script (10 green / 20 red, richer alert text) |
| `config.yaml` | Your settings (data source, groups, lists) |
| `scanner/` | The scanner code: signals, candle timing, Fyers connection (`fyers.py`), TradingView connection (`tv.py`), Yahoo backup and source switching (`data.py`), the run loop and commands (`engine.py`, `cli.py`), Telegram messages (`alerts.py`), lists, report, backtest (`backtest.py`, `backtest_report.py`) |
| `.github/workflows/` | The five buttons: `check-setup` (0), `scan` (1), `daily-report` (2), `backtest` (3), `fyers-login` (4) |
| `workflow_files_to_paste/` | Copies of the five workflow files (for the paste method in Step B.3 and Step G) |
| `tests/` | Automated tests |
| `reports/` | Created on first run: `latest.md`, `latest.csv`, `archive/`; the backtest adds `backtest/` (`latest.md`, `results.csv`, `best_by_security.csv`, `archive/`) |

### Pine script changes
Defaults 9/21 → **10/20**; short line colour blue → **green**; long line orange → **red**; alert texts now include exchange, symbol, timeframe and close. In TradingView: Pine Editor → paste → **Add to chart**; for a manual alert choose condition *EMA Cross → Bullish/Bearish EMA Cross*, trigger **Once Per Bar Close**.

---

## 13. Sources

- [TradingView Terms of Use and policies — display-only, personal-use and machine-driven wording (sections 2, 3, 10)](https://in.tradingview.com/policies)
- [python-tradingview-ta FAQ — notes on TradingView data and delays](https://python-tradingview-ta.readthedocs.io/en/stable/faq.html)
- [tvdatafeed-enhanced](https://pypi.org/project/tvdatafeed-enhanced/) and [tradingview-scraper](https://pypi.org/project/tradingview-scraper/) — open-source libraries whose chart-feed connection format the scanner follows (code was read, not copied)
- [GitHub Actions scheduled workflows — interval, delays, 60-day rule, default branch](https://cronuru.com/guides/github-actions-scheduled-workflows)
- [GitHub Docs — Actions billing and usage (public repositories are free)](https://docs.github.com/en/actions/reference/usage-limits-billing-and-administration)
- [yfinance community discussion on Yahoo rate limiting](https://github.com/ranaroussi/yfinance/discussions/2431)
- [Fyers API v3 — Plans & Limits (requests per second / minute / day, what the free and paid plans allow)](https://fyers.in/api-docs/v3/getting-started/plans-and-limits/)
- [Fyers community — "Refresh token API is currently disabled to comply with SEBI regulations" (code -16)](https://fyers.in/community/t/code-16-message-refresh-token-api-is-currently-disabled-to-comply-with-se/22904)
- [FYERS support — how to set up TOTP (Profile → Others → External 2FA TOTP → Enable)](https://support.fyers.in/portal/en/kb/articles/how-to-set-up-time-based-one-time-password-totp-in-fyers)
- [FYERS support — how to disable TOTP](https://support.fyers.in/portal/en/kb/articles/how-to-disable-time-based-one-time-password-totp-in-fyers)
- [Fyers community — where the TOTP secret key is shown (text under the QR code, once)](https://fyers.in/community/questions-5gz5j8db/post/how-to-get-totp-secret-code-ZPMwKC7IUyKMFbI)
- [fyers-auto-auth (open-source) — the login steps: send OTP → verify TOTP → verify PIN → auth code → access token](https://pypi.org/project/fyers-auto-auth)
- [RFC 6238 — TOTP (the 6-digit code); the scanner's code generator is tested against its published values](https://www.rfc-editor.org/rfc/rfc6238)
- [GitHub Docs — Create a workflow dispatch event (needs a token with "Actions: write")](https://docs.github.com/en/rest/actions/workflows#create-a-workflow-dispatch-event)
- [cron-job.org FAQ — free, every minute, custom headers and POST bodies](https://cron-job.org/faq/)
- [GitHub Docs — events that trigger workflows: the `schedule` event "can be delayed during periods of high loads" and queued jobs "may be dropped"; shortest interval 5 minutes](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows)
- [Zerodha support — charges for Kite APIs (Personal free without data; Connect ₹500 a month per app)](https://support.zerodha.com/category/trading-and-markets/kite-api/articles/what-are-the-charges-for-kite-apis)
- [Kite Connect docs — API rate limits (3 history requests and 1 quote request a second)](https://kite.trade/docs/connect/v3/exceptions/)
- [Zerodha support — Kite Connect FAQs (access token valid for one trading day)](https://support.zerodha.com/category/trading-and-markets/general-kite/kite-api/articles/kite-connect-api-faqs)
- [FYERS support — how much FYERS Prime costs (₹499 a month + 18 % GST)](https://support.fyers.in/portal/en/kb/articles/how-much-does-fyers-prime-cost-17-7-2026)
- [FYERS — enhanced API benefits with FYERS Prime (5,00,000 data requests a day)](https://fyers.in/whats-new/enhanced-api-benefits-with-fyers-prime)
- [TradingView support — additional market data subscriptions (crypto real time; NASDAQ/NYSE real time is an add-on)](https://www.tradingview.com/support/solutions/43000471705)

## 14. Change log
- 1.3.0 · 05 Nov 2026 · Automatic daily Fyers login. Why: the 05 Nov Setup check showed *"Refresh token API is currently disabled to comply with SEBI regulations"* - Fyers no longer renews logins, a fresh two-step login is needed every day, so the 15-day routine (and with it every Fyers price) would have stopped at the next new day. Now: the scanner logs in by itself with your user ID, TOTP key and PIN (two new secrets `FYERS_USER_ID` and `FYERS_TOTP_KEY`), reuses the pass all day, logs in again if Fyers drops it, and never loops: a wrong PIN waits until tomorrow, other refusals 1-3 hours, six tries a day at most. **4 - Fyers Login** became the test button (and `link` in its box gives the old by-hand route). Removed: the refresh-token renewal, the "login ends in N days" warning and the 15-day countdown. Four workflow files gain two lines (the new secrets). 301 tests (25 more than 1.2.3) - the 6-digit code is checked against RFC 6238's published values and the login against a local copy of Fyers' login steps; **not yet tried on the real Fyers**.
- 1.2.3 · 04 Nov 2026 · Steady Fyers pace. Why: the 1.2.2 "Where data is missing" lines in the 03:02 report showed that Fyers had answered "You've reached the Standard plan limit of 5 requests/second" and the scanner then dropped Fyers for the rest of the run, so the commodities (which only Fyers can serve) were empty; the Setup check had not shown it because it asked one contract at a time. Now: (1) requests are spread evenly instead of in bursts (free plan at most 2 a second, paid 6; Fyers counts them on arrival), over one kept-open connection per worker; (2) "too fast" is no longer fatal: everybody waits 2.5 s, 3.5 s, … and the pace is lowered, the same request is sent again, and Fyers is dropped for the run only after more than 8 such answers, or at once for a per-minute or daily limit (a second per-minute answer also stops it, because Fyers blocks accounts that break that limit 3 times a day); (3) when an older chunk of day candles fails, the newest candles are still used; (4) Check Setup asks for every commodity contract exactly the way the report does (all together, weekly view included) and reads the candles the way the scanner does, so it shows the same problems; it also reads the weekly-view day candles of Nifty 50, no longer asks TradingView about MCX, and shows all contracts in use; (5) the report no longer claims Fyers has no code for hundreds of shares (it deliberately asks Fyers about commodities only on the free plan); (6) error messages about dates or expired contracts are no longer mistaken for "too fast" or a login problem; REITs/InvITs and Nifty Next 50 now get their Fyers codes; placeholder rows ("Dummy …") in NSE's list are ignored. No workflow files changed. Tests 276.
- 1.2.2 · 04 Nov 2026 · Commodities and plain-words diagnostics. Why: in the first real daily report the MCX row had gaps (1 Hour and 4 Hour empty, 1 Day and 1 Week from very few contracts) while the Setup check showed no failure - it tested one commodity only, and a commodity whose Fyers code could not be matched quietly went to TradingView, which has no MCX prices. Now: (1) the contract is the nearest one that has not expired (last trading day from Fyers' list when it carries one, otherwise the month in the code), with the next two contracts as spares; if Fyers' list cannot be read the next months' codes are tried and the first with recent candles is kept for the day; a contract with no recent candles is skipped automatically; (2) Setup check tests every commodity contract on every candle size in use, five shares and the indices, and its Telegram message lists all warnings/failures and the key facts (plan, contracts in use, TradingView data modes); warnings also appear as annotations on the run page; (3) the daily report and the digest say where data is missing and why (Fyers' own answer), and no longer show groups that were not scanned (the global stand-ins while Fyers is on); (4) the scan's health alert names the commodities Fyers has no code for (and shares only when more than 5 % of them are unmatched). No workflow files changed. Tests 260.
- 1.2.1 · 04 Nov 2026 · Late-run safeguard. Why: on 3 Nov GitHub's own timer started your scan only once in 11 hours, and the catch-up then sent hours of old crossovers at once ("many messages, but late"). Now: (1) a late run looks back over about the last five candles only (`max_alert_age_minutes` 75 min / 5 h / 20 h / 3 d / 10 d instead of 6 h / 12 h / 25 h / 3 d / 10 d) and the message says what was left out; (2) the first scan after updating from an older version starts silently (old alert memory discarded once); (3) guide: measured GitHub delays, Kite and FYERS Prime charges and limits, the TradingView data-mode check. Later on 04 Nov: `daily-report.yml` fixed - its last step (keeping the symbol lists in the repository) failed in the first real run because old report files still stored in the repository were rewritten and Git refused to update; it now drops such changes first and never turns the run red (same method as the backtest's step; 4 new tests against throw-away git repositories). Replace only `daily-report.yml`. Tests 244.
- 1.2.0 · 03 Nov 2026 · Your three requests. (1) **Messages:** one Telegram message per timeframe each time a candle closes, one line per security in your wording, a "No crossovers" message when nothing crossed (switchable per timeframe), clear timeframe and candle time on every message. (2) **Fyers** for NSE, BSE and MCX with TradingView for everything else: login with renewal, encrypted saved login, pacing below Fyers' limits, daily allowance counter, symbol matching, real MCX contracts with monthly roll, fall-back to TradingView with a Telegram notice, new workflow `4 - Fyers Login`, richer Check Setup, secrets `FYERS_APP_ID`, `FYERS_SECRET_ID`, `FYERS_PIN`, optional `FYERS_PLAN`, `FYERS_REDIRECT_URI`. On the free plan crypto and US alerts are sent before the slow Indian round. (3) **Schedule:** GitHub's timer every 5 minutes plus the outside-timer recipe; a late run now catches up on missed candles. Also: the daily report is no longer saved in the public repository. Tests 234.
- 1.1.4, workflow fix · 03 Nov 2026 · First real `3 - Backtest` run (about 16 minutes): the run itself finished and sent its answer to Telegram, but its last step (saving a copy into the repository) failed with exit code 128 - git refused to pull because the restored symbol memory had changed a tracked file. `backtest.yml` fixed and tested against throw-away git repositories (the code in the zip is unchanged, so no new zip is needed). Also on 03 Nov: the first scheduled run of `2 - Daily Report` came about 9 hours late and `1 - EMA Scan` had not started any automatic run 2 hours after being added - GitHub's timer is slow on new schedules. Tests 171.
- 1.1.4 · 02 Nov 2026 · New workflow `3 - Backtest` (3-year, every timeframe, every security, long-only, with costs; long-history view plus a same-period view; best timeframe per security; Telegram digest + CSV + Markdown). Report notes now describe TradingView's delay correctly and no longer mention MCX when it is off. Tests 168.
- 1.1.3 · 02 Nov 2026 · After the first live Check Setup: MCX group switched off by default (TradingView returned no MCX data) and commodities use global futures; Check Setup now judges the sample on codes TradingView recognises and prints TradingView's own reply for rejected ones; EOS marked optional.
- 1.1.2 · 02 Nov 2026 · Zip route: all three workflows can unpack `ema-scanner.zip` themselves, so no folder upload is needed. Tests 87.
- 1.1.1 · 01 Nov 2026 · Nasdaq 100 list: Wikipedia no longer carries the table, so the scanner now tries a second web page and, as a last resort, a copy built into the scanner (found by your first Check Setup run). Tests 83.
- 1.1.0 · 01 Nov 2026 · Prices now come from TradingView's chart feed (Yahoo is the automatic backup; `data_source` setting). Added MCX commodity contracts, 9 more NSE indices, a 15-minute data-delay allowance, symbol fall-backs and bad-code memory, and a TradingView-aware Check Setup. Tests 50 → 82.
- 1.0.0 · 01 Nov 2026 · First release (Yahoo Finance data).
