# EMA 10/20 Crossover Scanner

Watches Nifty 500, Nasdaq 100, S&P 500, major crypto, Indian indices and MCX commodities for
**EMA 10 (green) / EMA 20 (red) crossovers** on 15m, 1h, 4h, 1D and 1W candles, sends grouped
alerts to Telegram, and builds a daily Markdown/CSV report. It mirrors `ema_crossover.pine`.

Prices come from **TradingView's free chart feed** (unofficial, about 15 minutes delayed for NSE / US / MCX,
crypto live), with **Yahoo Finance as an automatic backup**. Switch in `config.yaml` -> `data_source`
(`auto`, `tradingview` or `yahoo`). Please read section 8 of the guide before relying on it.

**Start here: [`EMA_Crossover_Scanner_Guide.md`](EMA_Crossover_Scanner_Guide.md)** - step-by-step setup for non-coders.

Quick start
1. Create a Telegram bot with @BotFather and note the token and your chat ID.
2. Put these files in a new **public** GitHub repository.
3. Add two secrets: `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID`. (No TradingView login or key is needed.)
   (If folder upload misbehaves: upload `ema-scanner.zip` itself and paste the three workflow files - see section 4 of the guide.)
4. Actions tab: run **0 - Check Setup**, then **2 - Daily Report**, then **1 - EMA Scan** (and, whenever you like, **3 - Backtest**).

**Backtest:** workflow `3 - Backtest` replays the rule over the past 3 years on every timeframe and says which worked better (guide section 5A).

Settings live in `config.yaml` (data source, timeframes, EMA lengths, which groups and symbols to scan).
