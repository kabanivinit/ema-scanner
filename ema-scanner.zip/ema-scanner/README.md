# EMA 10/20 Crossover Scanner

Watches Nifty 500, Nasdaq 100, S&P 500, major crypto, Indian indices and MCX commodities for
**EMA 10 (green) / EMA 20 (red) crossovers** on 15m, 1h, 4h, 1D and 1W candles. After every closed candle it sends
**one Telegram message per timeframe** (one line per security, e.g. "15 Min Crossover in Reliance Industries Limited, Bullish",
or a "No crossovers" note) and it builds a daily Markdown/CSV report. It mirrors `ema_crossover.pine`.

Prices: **Fyers** (your own API login) for Indian stocks, indices and MCX commodities; **TradingView's chart feed** for US
stocks and crypto (US about 15 minutes late, crypto live); Yahoo Finance as the automatic last backup.

**Start here: [`EMA_Crossover_Scanner_Guide.md`](EMA_Crossover_Scanner_Guide.md)** - step-by-step setup for non-coders.

Quick start
1. Create a Telegram bot with @BotFather and note the token and your chat ID.
2. Put these files in a new **public** GitHub repository (or upload `ema-scanner.zip` and paste the five workflow files - guide, Step B / G).
3. Add the secrets `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID`; for Fyers also `FYERS_APP_ID`, `FYERS_SECRET_ID`, `FYERS_PIN`
   (and `FYERS_PLAN` = `prime` if you have the paid Fyers plan).
4. Actions tab: run **0 - Check Setup**, then **4 - Fyers Login** (twice, about every 15 days), then **0 - Check Setup** again,
   **2 - Daily Report** and **1 - EMA Scan**. For punctual alerts add the free outside timer (guide, Step F).
   Whenever you like: **3 - Backtest**.

Settings live in `config.yaml` (timeframes, EMA lengths, which groups to scan, which timeframes send "No crossovers" notes).
