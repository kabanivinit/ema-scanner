"""Fyers: login storage, pacing, symbol matching, candles, routing and the commands - all with a pretend Fyers."""
import base64
import hashlib
import json
import threading
import time
from datetime import date, datetime, timedelta, timezone

import pandas as pd
import pytest
import requests

from scanner import cli, data, engine, fyers, report, telegram
from scanner.config import load_config
from scanner.fyers import (BudgetExhausted, Creds, FyersError, FyersFeed, Limiter, LoginError, Master, Session,
                           TokenStore, parse_auth_code, resolve, totp_code)
from scanner.markets import MARKETS
from scanner.universe import Instrument
from synth import daily_raw, intraday_raw, uptrend

NOW = datetime(2026, 11, 3, 10, 0, tzinfo=timezone.utc)            # 15:30 IST on a Tuesday
FRI = date(2026, 10, 30)


USER, TOTP_KEY = "XY12345", "JBSWY3DPEHPK3PXP"


def creds(**kw):
    return Creds(**{"app_id": "ABCD1234-100", "secret": "S3CRET", "pin": "1234", "user_id": USER, "totp_key": TOTP_KEY, **kw})


def b64(text):
    return base64.b64encode(text.encode()).decode()


def candles_of(df):
    return [[int(t.timestamp()), r.Open, r.High, r.Low, r.Close, r.Volume] for t, r in df.iterrows()]


class FakeFyers:
    """Answers like the Fyers servers (as far as the scanner uses them), the login included."""

    def __init__(self):
        self.posts, self.gets, self.logins = [], [], 0
        self.series = {}               # Fyers code -> candles
        self.by_resolution = {}        # Fyers code -> {"60": candles, "D": candles} when the size of the candle matters
        self.stale = set()             # access tokens Fyers no longer accepts
        self.reject_all = False        # True = data requests refuse every access token, even new ones
        self.errors = {}               # Fyers code -> (status, body)
        self.rate_limit_after = None   # number of history calls after which Fyers says 429
        self.network_failures = 0
        self.refusals = []             # answers given (in order) to the next history requests instead of candles
        self.refuse_codes = {}         # Fyers code -> answers given (in order) to the next requests for that code
        self.masters = {}
        self.login_clock = lambda: NOW.timestamp()      # the time Fyers' login servers go by (they accept the neighbouring codes too)
        self.login_refuse = {}         # login step (last word of the address) -> answers given, in order, instead of the normal ones
        self.otps = []                 # the TOTP codes Fyers received

    def post(self, url, payload=None, headers=None, timeout=20, follow=True):
        self.posts.append((url, payload))
        step = url.rsplit("/", 1)[1]
        if self.login_refuse.get(step):
            return self.login_refuse[step].pop(0)
        if step == "send_login_otp_v2":
            if payload["fy_id"] != b64(USER) or payload["app_id"] != "2":
                return 400, {"s": "error", "code": -1, "message": "Invalid fy_id"}
            return 200, {"s": "ok", "code": 200, "message": "", "request_key": "RK1"}
        if step == "verify_otp":
            self.otps.append(payload["otp"])
            t = self.login_clock()
            if payload["request_key"] != "RK1" or payload["otp"] not in {totp_code(TOTP_KEY, t + d) for d in (-30, 0, 30)}:
                return 400, {"s": "error", "code": -2, "message": "Invalid TOTP"}
            return 200, {"s": "ok", "code": 200, "request_key": "RK2"}
        if step == "verify_pin_v2":
            if payload["request_key"] != "RK2" or payload["identity_type"] != "pin" or payload["identifier"] != b64("1234"):
                return 400, {"s": "error", "code": -3, "message": "Invalid PIN"}
            return 200, {"s": "ok", "code": 200, "data": {"access_token": "BEARER"}}
        if step == "token":
            assert headers["authorization"] == "Bearer BEARER" and follow is False
            assert (payload["fyers_id"], payload["app_id"], payload["appType"]) == (USER, "ABCD1234", "100")
            assert payload["response_type"] == "code" and payload["redirect_uri"].startswith("https://")
            self.logins += 1
            return 308, {"Url": "https://trade.fyers.in/api-login/redirect-uri/index.html?s=ok&code=200"
                                f"&auth_code=CODE-{self.logins}&state=ema_scanner"}
        if step == "validate-authcode":
            assert payload["appIdHash"] == hashlib.sha256(b"ABCD1234-100:S3CRET").hexdigest()
            code = payload["code"]
            if code == "GOOD-CODE":                                             # a login done by hand in the browser
                return 200, {"s": "ok", "code": 200, "message": "", "access_token": "AT-LOGIN", "refresh_token": "RT-LOGIN"}
            if code.startswith("CODE-"):                                        # a login the scanner did by itself
                return 200, {"s": "ok", "code": 200, "access_token": f"LOGIN-{code[5:]}"}
            return 200, {"s": "error", "code": -413, "message": "Invalid auth code"}
        raise AssertionError(url)

    def get(self, url, params=None, headers=None, timeout=20):
        self.gets.append((params, headers))
        if self.network_failures:
            self.network_failures -= 1
            raise requests.ConnectionError("boom")
        if self.refusals:
            return self.refusals.pop(0)
        if self.refuse_codes.get(params["symbol"]):
            return self.refuse_codes[params["symbol"]].pop(0)
        if self.rate_limit_after is not None and len(self.gets) > self.rate_limit_after:
            return 429, {"s": "error", "code": -429, "message": "request limit reached"}
        token = headers["Authorization"].split(":", 1)[1]
        if token in self.stale or self.reject_all:
            return 401, {"s": "error", "code": -16, "message": "Could not authenticate the user"}
        sym = params["symbol"]
        if sym in self.errors:
            return self.errors[sym]
        c = self.by_resolution.get(sym, {}).get(params["resolution"])
        if c is None:
            c = self.series.get(sym)
        if c is None:
            return 200, {"s": "error", "code": -300, "message": "Please provide a valid symbol"}
        return 200, {"s": "ok", "code": 200, "message": "", "candles": c}

    def text(self, url, timeout=60):
        name = url.rsplit("/", 1)[1][:-4]
        if name not in self.masters:
            raise requests.ConnectionError("no list")
        return self.masters[name]


class Clock:
    def __init__(self):
        self.t, self.slept = 1000.0, []

    def now(self):
        return self.t

    def sleep(self, s):
        self.slept.append(s)
        self.t += s


@pytest.fixture(autouse=True)
def quiet(monkeypatch, tmp_path):
    monkeypatch.setattr("time.sleep", lambda s: None)
    monkeypatch.setattr(fyers, "STATE_DIR", tmp_path / "state")
    clk, real = Clock(), fyers.Limiter

    class PretendTimeLimiter(real):                     # limiters made by the scanner itself wait on a pretend clock, not for real
        def __init__(self, *a, **k):
            k.setdefault("clock", clk.now)
            k.setdefault("sleep", clk.sleep)
            super().__init__(*a, **k)

    monkeypatch.setattr(fyers, "Limiter", PretendTimeLimiter)


def logged_in(tmp_path, http, plan="prime", now=NOW, **limits):
    """A feed whose day-pass is already saved (made this morning)."""
    c = creds()
    store = TokenStore(c, tmp_path / "tok.enc")
    store.save(access_token="AT1", access_at=fyers._iso(now - timedelta(hours=2)))
    cfg = load_config()["fyers"]
    lim = dict(cfg["limits"][plan], **limits)
    cfg["limits"] = {plan: lim}
    cfg["plan"] = plan
    session = Session(c, store, http, now=lambda: now)
    clk = Clock()                                       # a pretend clock that moves forward when the limiter "waits"
    limiter = Limiter(lim["per_second"], lim["per_minute"], lim["per_day"], clock=clk.now, sleep=clk.sleep)
    return FyersFeed(cfg, plan, c, session, http, limiter, now=lambda: now)


def feed_from(store, http, when, plan="prime"):
    """A feed for one more run: it reads the saved pass from `store` and goes by the moment `when`."""
    http.login_clock = lambda: when.timestamp()
    cfg = load_config()["fyers"]
    lim = cfg["limits"][plan]
    cfg["limits"], cfg["plan"] = {plan: lim}, plan
    clk = Clock()
    limiter = Limiter(lim["per_second"], lim["per_minute"], lim["per_day"], clock=clk.now, sleep=clk.sleep)
    session = Session(store.creds, store, http, now=lambda: when)
    return FyersFeed(cfg, plan, store.creds, session, http, limiter, now=lambda: when)


# ------------------------------------------------------------------------------------------ login
def test_login_link_hash_and_pasted_address():
    c = creds(redirect="https://example.com/cb")
    url = c.login_url()
    assert url.startswith("https://api-t1.fyers.in/api/v3/generate-authcode?client_id=ABCD1234-100&redirect_uri=https%3A%2F%2Fexample.com%2Fcb")
    assert "response_type=code" in url and "S3CRET" not in url                    # the link never carries the secret
    import hashlib
    assert c.app_hash == hashlib.sha256(b"ABCD1234-100:S3CRET").hexdigest()
    pasted = "https://trade.fyers.in/api-login/redirect-uri/index.html?s=ok&code=200&auth_code=eyJabc.def&state=ema_scanner"
    assert parse_auth_code(pasted) == "eyJabc.def"
    assert parse_auth_code("  eyJabc.def \n") == "eyJabc.def" and parse_auth_code("auth_code=XYZ&state=1") == "XYZ"


def test_totp_codes_match_the_published_test_values():
    key = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"                          # the secret '12345678901234567890' of RFC 6238
    for t, eight in [(59, "94287082"), (1111111109, "07081804"), (1111111111, "14050471"),
                     (1234567890, "89005924"), (2000000000, "69279037"), (20000000000, "65353130")]:
        assert totp_code(key, t, digits=8) == eight and totp_code(key, t) == eight[-6:]
    assert totp_code(key, 59) == totp_code(key, 30) != totp_code(key, 60)           # one code for every 30 seconds


def test_the_totp_key_may_be_typed_with_spaces_dashes_small_letters_or_padding():
    plain = totp_code("JBSWY3DPEHPK3PXP", 1_000_000_000)
    assert totp_code("jbsw y3dp-ehpk 3pxp", 1_000_000_000) == plain == totp_code("JBSWY3DPEHPK3PXP====", 1_000_000_000)
    for bad in ("", "not a key!", "JBSWY3DPEHPK3PX1", "ABC"):             # '1' is no base-32 digit; 3 letters are no whole key
        with pytest.raises(ValueError, match="FYERS_TOTP_KEY"):
            totp_code(bad, 0)


def test_secrets_are_read_from_the_environment_and_named_when_missing():
    assert Creds.from_env({"FYERS_APP_ID": "a", "FYERS_SECRET_ID": "b"}) is None
    assert fyers.missing_secrets({"FYERS_APP_ID": "a"}) == ["FYERS_SECRET_ID", "FYERS_PIN"]
    c = Creds.from_env({"FYERS_APP_ID": " a ", "FYERS_SECRET_ID": "b", "FYERS_PIN": "1234"})
    assert (c.app_id, c.redirect) == ("a", fyers.DEFAULT_REDIRECT) and fyers.configured({"FYERS_APP_ID": "a", "FYERS_SECRET_ID": "b", "FYERS_PIN": "1"})
    assert not c.can_log_in and c.missing_login_secrets() == ["FYERS_USER_ID", "FYERS_TOTP_KEY"]      # Fyers is on, the daily login is not
    c = Creds.from_env({"FYERS_APP_ID": "a", "FYERS_SECRET_ID": "b", "FYERS_PIN": "1234",
                        "FYERS_USER_ID": " XY12345 ", "FYERS_TOTP_KEY": "JBSWY3DPEHPK3PXP "})
    assert c.can_log_in and (c.user_id, c.totp_key) == ("XY12345", "JBSWY3DPEHPK3PXP")
    assert fyers.missing_login_secrets({"FYERS_USER_ID": "x"}) == ["FYERS_TOTP_KEY"]


def test_saved_login_is_encrypted_and_only_your_own_secrets_open_it(tmp_path):
    store = TokenStore(creds(), tmp_path / "t.enc")
    store.save(refresh_token="RT-VERY-SECRET", access_token="AT-X")
    raw = (tmp_path / "t.enc").read_bytes()
    assert b"RT-VERY-SECRET" not in raw and b"refresh" not in raw
    assert store.load()["refresh_token"] == "RT-VERY-SECRET"
    other = TokenStore(creds(pin="9999"), tmp_path / "t.enc")
    assert other.load() == {} and "log in again" in other.problem
    store.save(access_token="AT-Y")                                              # saving one field keeps the others
    assert store.load() == {"refresh_token": "RT-VERY-SECRET", "access_token": "AT-Y"}


def at(http, when):
    """Fyers' login servers and the scanner both go by this moment. Returns the clock to give the session."""
    http.login_clock = lambda: when.timestamp()
    return lambda: when


def test_session_logs_in_by_itself_the_way_the_fyers_app_does_and_reuses_todays_pass(tmp_path):
    http = FakeFyers()
    c, store = creds(), TokenStore(creds(), tmp_path / "t.enc")
    s = Session(c, store, http, now=lambda: NOW)
    assert s.start() and s.token == "LOGIN-1" and s.how == "login" and http.logins == 1
    steps = [u.split("fyers.in", 1)[1] for u, _ in http.posts]
    assert steps == ["/vagator/v2/send_login_otp_v2", "/vagator/v2/verify_otp", "/vagator/v2/verify_pin_v2",
                     "/api/v3/token", "/api/v3/validate-authcode"]
    assert http.otps == [totp_code(TOTP_KEY, NOW.timestamp())]                    # the code an authenticator app shows right now
    saved = store.load()
    assert saved["access_token"] == "LOGIN-1" and fyers._parse_iso(saved["access_at"]) == NOW and "refresh_token" not in saved
    s2 = Session(c, store, http, now=lambda: NOW + timedelta(hours=1))            # same day: the saved pass, no login
    assert s2.start() and s2.token == "LOGIN-1" and s2.how == "saved" and http.logins == 1
    s3 = Session(c, store, http, now=at(http, NOW + timedelta(days=1)))            # next day: a new login, all by itself
    assert s3.start() and s3.token == "LOGIN-2" and http.logins == 2


def test_a_code_that_is_about_to_run_out_is_not_used(tmp_path):
    http, slept = FakeFyers(), []
    t = [NOW.timestamp() + 27.0]                                                  # only 3 seconds are left of this code
    http.login_clock = lambda: t[0]

    def sleeper(seconds):
        slept.append(seconds)
        t[0] += seconds

    s = Session(creds(), TokenStore(creds(), tmp_path / "t.enc"), http, now=lambda: datetime.fromtimestamp(t[0], timezone.utc), sleep=sleeper)
    assert s.start()
    assert slept == [3.5] and http.otps == [totp_code(TOTP_KEY, NOW.timestamp() + 30)]      # it waited for the next code
    slept.clear()
    t[0] = NOW.timestamp() + 5.0                                                  # plenty of time left: no waiting
    s = Session(creds(), TokenStore(creds(), tmp_path / "u.enc"), http, now=lambda: datetime.fromtimestamp(t[0], timezone.utc), sleep=sleeper)
    assert s.start() and slept == [] and http.otps[-1] == totp_code(TOTP_KEY, NOW.timestamp() + 5)


@pytest.mark.parametrize("step, secret, hours", [("send_login_otp_v2", "FYERS_USER_ID", 1), ("verify_otp", "FYERS_TOTP_KEY", 3),
                                                  ("validate-authcode", "FYERS_SECRET_ID", 1)])
def test_a_refused_step_names_the_secret_and_the_scanner_waits_before_it_asks_again(tmp_path, step, secret, hours):
    http = FakeFyers()
    http.login_refuse[step] = [(400, {"s": "error", "code": -9, "message": "Nope"})]
    store = TokenStore(creds(), tmp_path / "t.enc")
    s = Session(creds(), store, http, now=lambda: NOW)
    assert not s.start() and secret in s.problem and "Nope" in s.problem
    asked = len(http.posts)
    soon = Session(creds(), store, http, now=lambda: NOW + timedelta(hours=hours - 0.5))
    assert not soon.start() and "waits until" in soon.problem and secret in soon.problem
    assert len(http.posts) == asked                                               # it did not even ask Fyers
    later = Session(creds(), store, http, now=at(http, NOW + timedelta(hours=hours + 0.1)))
    assert later.start() and later.token.startswith("LOGIN-")


def test_a_wrong_pin_is_tried_once_a_day_because_wrong_pins_can_lock_the_account(tmp_path):
    http = FakeFyers()
    http.login_refuse["verify_pin_v2"] = [(400, {"s": "error", "message": "Invalid PIN"})]
    store = TokenStore(creds(), tmp_path / "t.enc")
    s = Session(creds(), store, http, now=lambda: NOW)                             # 15:30 IST
    assert not s.start() and "FYERS_PIN" in s.problem and "not try again before tomorrow" in s.problem
    asked = len(http.posts)
    evening = Session(creds(), store, http, now=lambda: NOW + timedelta(hours=8))   # 23:30 IST, still the same day
    assert not evening.start() and "waits until 04 Nov 00:01 IST" in evening.problem and len(http.posts) == asked
    morning = Session(creds(), store, http, now=at(http, NOW + timedelta(hours=9)))  # 00:30 IST the next day
    assert morning.start() and morning.token == "LOGIN-1"


def test_fixing_a_secret_ends_the_wait_at_once(tmp_path):
    http = FakeFyers()
    store = TokenStore(creds(), tmp_path / "t.enc")
    wrong = creds(user_id="NOBODY1")
    assert not Session(wrong, store, http, now=lambda: NOW).start()                # Fyers does not know this user
    assert not Session(wrong, store, http, now=lambda: NOW + timedelta(minutes=5)).start()      # ... and the scanner now waits
    fixed = Session(creds(), store, http, now=at(http, NOW + timedelta(minutes=6)))
    assert fixed.start() and fixed.token == "LOGIN-1"


def test_a_hiccup_at_fyers_is_tried_once_more_and_never_held_against_the_next_run(tmp_path):
    http = FakeFyers()
    http.login_refuse["send_login_otp_v2"] = [(503, {})]
    store = TokenStore(creds(), tmp_path / "t.enc")
    assert Session(creds(), store, http, now=lambda: NOW).start() and http.logins == 1            # the second try worked
    other = FakeFyers()
    other.login_refuse["send_login_otp_v2"] = [(503, {})] * 3
    store2 = TokenStore(creds(), tmp_path / "u.enc")
    s = Session(creds(), store2, other, now=lambda: NOW)
    assert not s.start() and "busy" in s.problem and "next run" in s.problem
    assert [u for u, _ in other.posts if u.endswith("send_login_otp_v2")] == [fyers.VAGATOR + "/send_login_otp_v2"] * 2
    assert "hold_until" not in store2.load()
    again = Session(creds(), store2, other, now=at(other, NOW + timedelta(minutes=15)))
    assert again.start() and again.token == "LOGIN-1"                              # the next run simply tries again


def test_no_network_at_all_is_a_hiccup_too(tmp_path):
    class Offline(FakeFyers):
        def post(self, *a, **k):
            raise requests.ConnectionError("boom")

    store = TokenStore(creds(), tmp_path / "t.enc")
    s = Session(creds(), store, Offline(), now=lambda: NOW)
    assert not s.start() and "could not reach Fyers" in s.problem and "hold_until" not in store.load()


def test_too_many_requests_at_the_login_servers_means_half_an_hour_of_rest(tmp_path):
    http = FakeFyers()
    http.login_refuse["send_login_otp_v2"] = [(429, {})]
    store = TokenStore(creds(), tmp_path / "t.enc")
    s = Session(creds(), store, http, now=lambda: NOW)
    assert not s.start() and "too many requests" in s.problem
    assert not Session(creds(), store, http, now=lambda: NOW + timedelta(minutes=10)).start()
    assert Session(creds(), store, http, now=at(http, NOW + timedelta(minutes=40))).start()


def test_at_most_six_automatic_logins_a_day_but_you_can_always_log_in_yourself(tmp_path):
    http = FakeFyers()
    store = TokenStore(creds(), tmp_path / "t.enc")
    store.save(login_day="2026-11-03", login_n=fyers.MAX_LOGINS_PER_DAY)
    s = Session(creds(), store, http, now=lambda: NOW)
    assert not s.start() and f"tried {fyers.MAX_LOGINS_PER_DAY} times today" in s.problem and http.posts == []
    assert Session(creds(), store, http, now=lambda: NOW).start(force=True) and store.load()["login_n"] == 0
    store.save(login_day="2026-11-02", login_n=fyers.MAX_LOGINS_PER_DAY)           # yesterday's count means nothing today
    assert Session(creds(), store, http, now=lambda: NOW).start(fresh=True)


def test_a_pass_that_fyers_keeps_refusing_does_not_cause_a_login_every_15_minutes(tmp_path):
    http = FakeFyers()
    http.series["NSE:S-EQ"] = nse_series()
    http.reject_all = True                                                         # whatever pass the scanner brings, Fyers says no
    store = TokenStore(creds(), tmp_path / "t.enc")
    store.save(access_token="AT-OLD", access_at=fyers._iso(NOW - timedelta(hours=1)))
    logins = []
    for k in range(8):
        feed = feed_from(store, http, NOW + timedelta(minutes=15 * k))
        out, failed = feed.fetch({"S": "NSE:S-EQ"}, "1h")
        assert out == {} and failed == ["S"] and feed.down
        logins.append(http.logins)
    assert logins == [1, 2, 3, 4, 5, 6, 6, 6]                                       # and then it stops for the day
    assert f"tried {fyers.MAX_LOGINS_PER_DAY} times today" in feed.down


def test_a_pass_that_was_just_handed_out_and_is_refused_is_not_replaced_by_another_login(tmp_path):
    http = FakeFyers()
    s = Session(creds(), TokenStore(creds(), tmp_path / "t.enc"), http, now=lambda: NOW)
    assert s.start() and s.token == "LOGIN-1"
    assert not s.renew("LOGIN-1") and "refuses the day-pass" in s.problem and http.logins == 1
    assert not s.renew("LOGIN-1") and http.logins == 1


def test_without_the_two_login_secrets_a_new_day_needs_you_but_a_login_by_hand_still_works_today(tmp_path):
    http = FakeFyers()
    c = creds(user_id="", totp_key="")
    store = TokenStore(c, tmp_path / "t.enc")
    s = Session(c, store, http, now=lambda: NOW)
    assert not s.start() and "FYERS_USER_ID and FYERS_TOTP_KEY" in s.problem and "Step E" in s.problem and http.posts == []
    store.save(access_token="BY-HAND", access_at=fyers._iso(NOW - timedelta(hours=1)))
    today = Session(c, store, http, now=lambda: NOW)
    assert today.start() and today.token == "BY-HAND"
    assert not Session(c, store, http, now=lambda: NOW + timedelta(days=1)).start() and http.posts == []
    half = creds(totp_key="")
    s = Session(half, TokenStore(half, tmp_path / "u.enc"), http, now=lambda: NOW)
    assert not s.start() and "secret FYERS_TOTP_KEY" in s.problem and "FYERS_USER_ID" not in s.problem


def test_a_secret_that_cannot_be_right_is_reported_without_asking_fyers(tmp_path):
    http = FakeFyers()
    for n, (kw, word) in enumerate([({"totp_key": "not a key!"}, "FYERS_TOTP_KEY"), ({"user_id": "me@mail.com"}, "FYERS_USER_ID"),
                                     ({"app_id": "ABCD1234"}, "FYERS_APP_ID")]):
        c = creds(**kw)
        s = Session(c, TokenStore(c, tmp_path / f"{n}.enc"), http, now=lambda: NOW)
        assert not s.start() and word in s.problem
    assert http.posts == []


def test_an_answer_without_a_login_code_is_explained(tmp_path):
    http = FakeFyers()
    http.login_refuse["token"] = [(308, {"s": "error", "message": "app not allowed"})]
    s = Session(creds(), TokenStore(creds(), tmp_path / "t.enc"), http, now=lambda: NOW)
    assert not s.start() and "FYERS_APP_ID" in s.problem and "app not allowed" in s.problem


class LoginServer:
    """A small real web server that talks like Fyers' login servers (cookies, a redirect with the code in the address and
    in the body) - so the real HTTP code of the scanner is run too, not only the pretend one."""

    def __init__(self, redirect_in_body=True):
        import http.server
        outer = self
        self.paths, self.otps, self.cookies_seen, self.redirect_in_body = [], [], [], redirect_in_body

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def reply(self, status, body, headers=()):
                raw = json.dumps(body).encode()
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                for k, v in headers:
                    self.send_header(k, v)
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self):                                                       # nobody may walk to the redirect address
                outer.paths.append("GET " + self.path)
                self.reply(500, {"s": "error", "message": "the redirect must not be followed"})

            def do_POST(self):
                payload = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
                step = self.path.rsplit("/", 1)[1]
                outer.paths.append(step)
                outer.cookies_seen.append(self.headers.get("Cookie", ""))
                if step == "send_login_otp_v2":
                    return self.reply(200, {"s": "ok", "request_key": "RK1"}, [("Set-Cookie", "sid=abc; Path=/")])
                if "sid=abc" not in self.headers.get("Cookie", "") and step in ("verify_otp", "verify_pin_v2"):
                    return self.reply(401, {"s": "error", "message": "no session cookie"})
                if step == "verify_otp":
                    outer.otps.append(payload["otp"])
                    ok = payload["otp"] in {totp_code(TOTP_KEY, time.time() + d) for d in (-30, 0, 30)}
                    return self.reply(200, {"s": "ok", "request_key": "RK2"}) if ok else self.reply(400, {"s": "error", "message": "Invalid TOTP"})
                if step == "verify_pin_v2":
                    return self.reply(200, {"s": "ok", "data": {"access_token": "BEARER"}})
                if step == "token":
                    where = "https://trade.fyers.in/api-login/redirect-uri/index.html?s=ok&code=200&auth_code=REAL-CODE&state=x"
                    body = {"s": "ok", "Url": where} if outer.redirect_in_body else {}
                    return self.reply(308, body, [("Location", where)])
                if step == "validate-authcode":
                    return self.reply(200, {"s": "ok", "code": 200, "access_token": "REAL-PASS" if payload["code"] == "REAL-CODE" else "WRONG"})
                self.reply(404, {"s": "error", "message": "unknown"})

        self.server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.url = f"http://127.0.0.1:{self.server.server_address[1]}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def close(self):
        self.server.shutdown()
        self.server.server_close()


@pytest.mark.parametrize("redirect_in_body", [True, False])
def test_the_real_http_code_logs_in_keeps_the_login_cookie_and_reads_the_code_from_the_redirect(monkeypatch, redirect_in_body):
    monkeypatch.setenv("NO_PROXY", "127.0.0.1")
    monkeypatch.setenv("no_proxy", "127.0.0.1")
    server = LoginServer(redirect_in_body)
    try:
        monkeypatch.setattr(fyers, "VAGATOR", server.url + "/vagator/v2")
        monkeypatch.setattr(fyers, "API", server.url + "/api/v3")
        tokens = fyers.totp_login(creds(), fyers.RequestsHttp())
        assert tokens["access_token"] == "REAL-PASS"
        assert server.paths == ["send_login_otp_v2", "verify_otp", "verify_pin_v2", "token", "validate-authcode"]    # no GET: not redirected
        assert "sid=abc" in server.cookies_seen[1] and "sid=abc" in server.cookies_seen[2]                    # the cookie travelled along
        assert len(server.otps) == 1                                                                           # one code, checked by the server
    finally:
        server.close()


def test_the_real_http_code_reports_a_refused_code(monkeypatch):
    monkeypatch.setenv("NO_PROXY", "127.0.0.1")
    monkeypatch.setenv("no_proxy", "127.0.0.1")
    server = LoginServer()
    try:
        monkeypatch.setattr(fyers, "VAGATOR", server.url + "/vagator/v2")
        monkeypatch.setattr(fyers, "API", server.url + "/api/v3")
        with pytest.raises(LoginError) as e:
            fyers.totp_login(creds(totp_key="MFRGGZDFMZTWQ2LK"), fyers.RequestsHttp())                         # a different key
        assert e.value.kind == "totp" and "FYERS_TOTP_KEY" in str(e.value) and "Invalid TOTP" in str(e.value)
    finally:
        server.close()


# ------------------------------------------------------------------------------------------ pacing
def test_limiter_keeps_below_the_per_second_and_per_minute_limits_and_the_daily_allowance():
    c = Clock()
    lim = Limiter(per_second=2, per_minute=100, per_day=100, clock=c.now, sleep=c.sleep)
    times = []
    for _ in range(5):
        lim.acquire()
        times.append(c.t)
    assert all(b - a >= 0.5 for a, b in zip(times, times[1:])) and times[2] - times[0] > 1.0      # evenly spread: never 3 in a second
    c = Clock()
    lim = Limiter(per_second=100, per_minute=3, per_day=100, clock=c.now, sleep=c.sleep)
    for _ in range(4):
        lim.acquire()
    assert 59.9 < sum(c.slept) < 61                                               # the 4th waited for the minute to pass
    c = Clock()
    lim = Limiter(per_second=100, per_minute=100, per_day=2, clock=c.now, sleep=c.sleep)
    lim.acquire(), lim.acquire()
    with pytest.raises(BudgetExhausted):
        lim.acquire()


def test_the_free_plan_paces_below_fyers_limits_and_leaves_15_minute_candles_to_tradingview():
    cfg = load_config()["fyers"]
    std, prime = cfg["limits"]["standard"], cfg["limits"]["prime"]
    assert std["per_minute"] < 50 and std["per_second"] < 5 and std["per_day"] < 5000     # Fyers: 50/min, 5/s, 5,000/day
    assert prime["per_minute"] < 500 and prime["per_second"] < 10 and prime["per_day"] < 500000
    assert std["skip_intervals"] == ["15m"] and prime["skip_intervals"] == []


# ------------------------------------------------------------------------------------------ symbol matching
def nse_row(n, ticker, desc="X"):
    return [f"10100000{n:07d}", desc, "0", "1", "0.05", "INE", "0915-1530", "2026-11-02", "0", ticker, "10", "10", str(n)]


def mcx_row(n, ticker):
    return [f"11200000{n:07d}", ticker.split(":")[1], "11", "1", "1", "", "0900-2330", "2026-11-02", "1796000000", ticker, "11", "20", str(n)]


def csv_text(rows):
    import csv, io
    buf = io.StringIO()
    csv.writer(buf).writerows(rows)
    return buf.getvalue()


def lists():
    http = FakeFyers()
    http.masters["NSE_CM"] = csv_text(
        [nse_row(i, f"NSE:S{i}-EQ") for i in range(10)]
        + [nse_row(20, "NSE:RELIANCE-EQ", "RELIANCE INDUSTRIES LTD"), nse_row(21, "NSE:M&M-EQ"), nse_row(22, "NSE:GOVT-BE"),
           nse_row(30, "NSE:NIFTY50-INDEX", "Nifty 50"), nse_row(31, "NSE:FINNIFTY-INDEX", "Nifty Fin Service"),
           nse_row(32, "NSE:NIFTYFOO-INDEX", "Nifty Foo"), nse_row(33, "NSE:NIFTYSERVSECTOR-INDEX", "Nifty Serv Sector")])
    http.masters["BSE_CM"] = csv_text([nse_row(i, f"BSE:B{i}-A") for i in range(8)] + [nse_row(40, "BSE:SENSEX-INDEX", "Sensex")])
    http.masters["MCX_COM"] = csv_text(
        [mcx_row(i, t) for i, t in enumerate(["MCX:GOLD26DECFUT", "MCX:GOLD27FEBFUT", "MCX:GOLDM26DECFUT", "MCX:CRUDEOIL26NOVFUT",
                                              "MCX:CRUDEOIL26DECFUT", "MCX:SILVER26DECFUT", "MCX:SILVER27MARFUT"])])
    return http


def insts():
    mk = lambda sym, name, market="NSE", hint=(): Instrument(sym, name, market, fyers_hint=list(hint))
    return [mk("RELIANCE.NS", "Reliance Industries Ltd."), mk("M&M.NS", "Mahindra & Mahindra Ltd."), mk("GOVT.NS", "Gov Ltd"),
            mk("NOPE.NS", "Not Listed Ltd"), mk("^NSEI", "Nifty 50"), mk("^CNXFIN", "Nifty Financial Services"),
            mk("^CNXSERVICE", "Nifty Services Sector"), mk("NSE:CNXFOO", "Nifty Foo"), mk("^BSESN", "Sensex"),
            mk("MCX:GOLD1!", "Gold", "MCX"), mk("MCX:CRUDEOIL1!", "Crude Oil", "MCX"), mk("MCX:SILVER1!", "Silver", "MCX"),
            mk("MCX:GOLDM1!", "Gold Mini", "MCX"), mk("MCX:LEAD1!", "Lead", "MCX")]


def test_our_symbols_are_matched_to_fyers_codes(tmp_path):
    http, items = lists(), insts()
    master = Master(load_config()["fyers"], http, now=lambda: NOW, folder=tmp_path / "m")
    rep = resolve(items, load_config()["fyers"], master, today=date(2026, 11, 3))
    got = {i.symbol: i.fyers for i in items}
    assert got["RELIANCE.NS"] == "NSE:RELIANCE-EQ" and got["M&M.NS"] == "NSE:M&M-EQ"
    assert got["GOVT.NS"] == "NSE:GOVT-BE"                                       # not an EQ-series share: next series is tried
    assert got["NOPE.NS"] == ""                                                  # not on Fyers -> TradingView
    assert got["^NSEI"] == "NSE:NIFTY50-INDEX" and got["^CNXFIN"] == "NSE:FINNIFTY-INDEX"       # second code of the list
    assert got["^CNXSERVICE"] == "NSE:NIFTYSERVSECTOR-INDEX" and got["^BSESN"] == "BSE:SENSEX-INDEX"
    assert got["NSE:CNXFOO"] == "NSE:NIFTYFOO-INDEX"                             # found by name
    assert got["MCX:GOLD1!"] == "MCX:GOLD26DECFUT" and got["MCX:GOLDM1!"] == "MCX:GOLDM26DECFUT"    # nearest contract, root matched exactly
    assert got["MCX:CRUDEOIL1!"] == "MCX:CRUDEOIL26NOVFUT" and got["MCX:SILVER1!"] == "MCX:SILVER26DECFUT"
    assert got["MCX:LEAD1!"] == ""
    assert rep["missing"] == ["Not Listed Ltd", "Lead"] and rep["mapped"] == 12 and len(rep["notes"]) == 3


def test_mcx_rolls_to_next_month_near_the_end_of_the_month(tmp_path):
    http = lists()
    for today, want in [(date(2026, 11, 3), "MCX:CRUDEOIL26NOVFUT"), (date(2026, 11, 28), "MCX:CRUDEOIL26DECFUT")]:
        item = [Instrument("MCX:CRUDEOIL1!", "Crude Oil", "MCX")]
        resolve(item, load_config()["fyers"], Master(load_config()["fyers"], http, now=lambda: NOW, folder=tmp_path / "m2"), today=today)
        assert item[0].fyers == want


def test_without_the_symbol_lists_stocks_still_use_the_obvious_code_and_a_saved_copy_is_reused(tmp_path):
    http = FakeFyers()                                                           # downloads all fail
    item = [Instrument("RELIANCE.NS", "Reliance", "NSE"), Instrument("MCX:GOLD1!", "Gold", "MCX")]
    rep = resolve(item, load_config()["fyers"], Master(load_config()["fyers"], http, now=lambda: NOW, folder=tmp_path / "m"),
                  today=date(2026, 11, 3))
    assert item[0].fyers == "NSE:RELIANCE-EQ" and "download failed" in " ".join(rep["notes"])
    assert item[1].fyers == "MCX:GOLD26NOVFUT" and item[1].fyers_alts[0] == "MCX:GOLD26DECFUT" and rep["guessed"] == ["Gold"]
    http2 = lists()
    m = Master(load_config()["fyers"], http2, now=lambda: NOW, folder=tmp_path / "m3")
    assert m.tickers("NSE_CM")["NSE:RELIANCE-EQ"] == "RELIANCE INDUSTRIES LTD"
    m_again = Master(load_config()["fyers"], FakeFyers(), now=lambda: NOW, folder=tmp_path / "m3")        # no network now
    assert "NSE:RELIANCE-EQ" in m_again.tickers("NSE_CM") and "saved copy" in m_again.notes["NSE_CM"]


# ------------------------------------------------------------------------------------------ candles
def nse_series(n_days=3, minutes=15):
    return candles_of(intraday_raw("NSE", minutes, FRI, n_days, lambda n: uptrend(n)))


def test_candles_come_back_as_utc_frames_with_the_right_request(tmp_path):
    http = FakeFyers()
    http.series["NSE:RELIANCE-EQ"] = nse_series()
    feed = logged_in(tmp_path, http)
    out, failed = feed.fetch({"RELIANCE.NS": "NSE:RELIANCE-EQ"}, "15m")
    df = out["RELIANCE.NS"]
    assert failed == [] and len(df) == 75 and str(df.index.tz) == "UTC" and df.index.is_monotonic_increasing
    params, headers = http.gets[0]
    assert params["symbol"] == "NSE:RELIANCE-EQ" and params["resolution"] == "15" and params["date_format"] == "0"
    assert params["cont_flag"] == "1" and int(params["range_to"]) - int(params["range_from"]) == 30 * 86400
    assert headers["Authorization"] == "ABCD1234-100:AT1"
    assert feed.calls == 1 and feed.limiter.used == 1
    assert feed.covers("15m") and feed.covers("1h") and not feed.covers("1w")


def test_weekly_candles_get_two_years_of_daily_candles_in_two_requests(tmp_path):
    http = FakeFyers()
    http.series["NSE:RELIANCE-EQ"] = nse_series()
    feed = logged_in(tmp_path, http)
    feed.fetch({"R": "NSE:RELIANCE-EQ"}, "1d")
    assert len(http.gets) == 1
    http.gets.clear()
    out, _ = feed.fetch({"R": "NSE:RELIANCE-EQ"}, "1d", long_daily=True)
    assert len(http.gets) == 2
    (p1, _), (p2, _) = http.gets
    assert int(p1["range_from"]) > int(p2["range_to"]) and int(p2["range_to"]) - int(p2["range_from"]) == 360 * 86400
    assert len(out["R"]) == 75                                                    # identical candles in both chunks are merged


def test_unknown_symbols_are_reported_and_do_not_stop_the_others(tmp_path):
    http = FakeFyers()
    http.series["NSE:A-EQ"] = nse_series()
    feed = logged_in(tmp_path, http)
    out, failed = feed.fetch({"A": "NSE:A-EQ", "B": "NSE:NOPE-EQ"}, "1h")
    assert list(out) == ["A"] and failed == ["B"] and feed.invalid == {"B"} and "valid symbol" in feed.reasons["B"]
    assert not feed.down


def test_a_login_that_stopped_working_is_renewed_once_for_all_workers(tmp_path):
    http = FakeFyers()
    for k in range(6):
        http.series[f"NSE:S{k}-EQ"] = nse_series()
    feed = logged_in(tmp_path, http)
    feed.session.store.save(access_token="AT-OLD")
    http.stale.add("AT-OLD")                                                     # Fyers dropped this morning's token
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(6)}, "1h")
    assert len(out) == 6 and failed == [] and http.logins == 1                  # one login, shared by all four workers
    used = [h["Authorization"].split(":")[1] for _, h in http.gets]
    assert used[0] == "AT-OLD" and used[-1] == "LOGIN-1" and feed.session.store.load()["access_token"] == "LOGIN-1"


def test_a_login_fyers_refuses_stops_the_run_and_says_what_to_do(tmp_path):
    http = FakeFyers()
    http.series["NSE:S-EQ"] = nse_series()
    http.stale.add("AT1")
    http.login_refuse["verify_pin_v2"] = [(400, {"s": "error", "message": "Invalid PIN"})]
    feed = logged_in(tmp_path, http)                                             # the saved pass is refused AND the new login is
    out, failed = feed.fetch({"S": "NSE:S-EQ"}, "1h")
    assert out == {} and failed == ["S"] and "FYERS_PIN" in feed.down and "4 - Fyers Login" in feed.down
    assert any("login problem" in e for e in feed.events) and not feed.covers("1h")


def test_going_too_fast_again_and_again_stops_the_run_without_hammering(tmp_path):
    http = FakeFyers()
    for k in range(30):
        http.series[f"NSE:S{k}-EQ"] = nse_series()
    http.rate_limit_after = 3
    feed = logged_in(tmp_path, http)
    feed.fcfg["workers"] = 1
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(30)}, "1h")
    assert len(out) == 3 and len(failed) == 27 and "too fast" in feed.down
    assert len(http.gets) == 3 + 4                                               # the 4th symbol was tried 4 times, then the run stopped
    assert any("TradingView" in e for e in feed.events)


def test_the_daily_allowance_is_never_exceeded(tmp_path):
    http = FakeFyers()
    for k in range(10):
        http.series[f"NSE:S{k}-EQ"] = nse_series()
    feed = logged_in(tmp_path, http, per_day=4)
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(10)}, "1h")
    assert len(out) == 4 and len(failed) == 6 and len(http.gets) == 4 and "allowance is used up" in feed.down
    state = {}
    feed.save_state(state)
    assert state["fyers"] == {"day": "2026-11-03", "calls": 4}
    feed.limiter.used = 0
    feed.attach_state(state)
    assert feed.limiter.used == 4                                                # tomorrow's runs know what today's used ...
    state["fyers"]["day"] = "2026-11-02"
    feed.attach_state(state)
    assert feed.limiter.used == 0                                                # ... and a new day starts from zero


def test_a_network_hiccup_is_retried(tmp_path):
    http = FakeFyers()
    http.series["NSE:A-EQ"] = nse_series()
    http.network_failures = 1
    feed = logged_in(tmp_path, http)
    out, failed = feed.fetch({"A": "NSE:A-EQ"}, "1h")
    assert "A" in out and failed == []
    http.network_failures = 5
    out, failed = feed.fetch({"A": "NSE:A-EQ"}, "1h")
    assert failed == ["A"] and "network" in feed.reasons["A"]


def test_there_is_no_countdown_any_more_because_the_scanner_logs_in_by_itself_every_day(tmp_path):
    http = FakeFyers()
    http.series["NSE:A-EQ"] = nse_series()
    feed = logged_in(tmp_path, http)
    feed.fetch({"A": "NSE:A-EQ"}, "1h")
    assert feed.events == [] and not hasattr(feed.session, "days_left") and http.logins == 0


# ------------------------------------------------------------------------------------------ routing into the scanner
class StubTV:
    down, invalid = "", set()

    def __init__(self, frames):
        self.frames, self.asked = frames, []

    def fetch(self, symbols, interval):
        self.asked.append((tuple(symbols), interval))
        got = {s: self.frames[s] for s in symbols if s in self.frames}
        return got, [s for s in symbols if s not in got]


def routed(tmp_path, plan="prime"):
    http = FakeFyers()
    http.series["NSE:A-EQ"] = nse_series()
    items = [Instrument("A.NS", "A", "NSE", fyers="NSE:A-EQ"), Instrument("B.NS", "B", "NSE", fyers="NSE:B-EQ"),
             Instrument("MSFT", "Microsoft", "US")]
    raw = intraday_raw("NSE", 15, FRI, 3, lambda n: uptrend(n))
    tv = StubTV({"A.NS": raw, "B.NS": raw, "MSFT": raw})
    cfg = dict(load_config(), data_source="tradingview")
    feed = logged_in(tmp_path, http, plan=plan)
    return data.Fetcher(cfg, items, tv=tv, fyers=feed), tv, http, feed


def test_indian_symbols_use_fyers_everything_else_and_misses_use_tradingview(tmp_path):
    f, tv, http, feed = routed(tmp_path)
    out, failed = f(["A.NS", "B.NS", "MSFT"], "1h")
    assert sorted(out) == ["A.NS", "B.NS", "MSFT"] and failed == []
    assert [f.source_of(s, "1h") for s in ("A.NS", "B.NS", "MSFT")] == ["fyers", "tradingview", "tradingview"]
    assert tv.asked == [(("B.NS", "MSFT"), "1h")]                                # TradingView was asked only for what Fyers did not give
    assert f.served == {"tradingview": 2, "yahoo": 0, "fyers": 1}
    assert f.primary_source("NSE", "1h") == "fyers" and f.primary_source("US", "1h") == "tradingview"


def test_the_free_plan_sends_15_minute_candles_of_indian_markets_to_tradingview(tmp_path):
    f, tv, http, feed = routed(tmp_path, plan="standard")
    assert f.primary_source("NSE", "15m") == "tradingview" and f.primary_source("NSE", "1h") == "fyers"
    out, _ = f(["A.NS"], "15m")
    assert http.gets == [] and f.source_of("A.NS", "15m") == "tradingview" and tv.asked == [(("A.NS",), "15m")]


def test_when_fyers_breaks_the_scan_carries_on_with_delayed_data_and_says_so(tmp_path):
    f, tv, http, feed = routed(tmp_path)
    http.stale.add("AT1")
    http.login_refuse["verify_pin_v2"] = [(400, {"s": "error", "message": "Invalid PIN"})]
    out, failed = f(["A.NS", "B.NS"], "1h")
    assert sorted(out) == ["A.NS", "B.NS"] and f.source_of("A.NS", "1h") == "tradingview"
    assert any("Fyers is not usable" in e for e in f.events) and f.primary_source("NSE", "1h") == "tradingview"


def test_a_delayed_feed_is_given_time_to_finish_its_latest_candle():
    cfg = load_config()
    raw = intraday_raw("NSE", 15, FRI, 30, lambda n: uptrend(n))
    from scanner import bars
    last = bars.intraday_bars(raw, MARKETS["NSE"], 15)["end"].iloc[-1]
    now = last + pd.Timedelta(minutes=3)
    real, _ = engine.evaluate(raw, "NSE", "15m", cfg, now, source="fyers")
    slow, _ = engine.evaluate(raw, "NSE", "15m", cfg, now, source="tradingview")
    assert real["last_end"] == last and slow["last_end"] < last                   # TradingView's copy may still be mid-candle


def test_a_late_run_looks_further_back_but_never_beyond_the_alert_age_limit():
    cfg = load_config()
    exp = pd.Timestamp("2026-11-03 10:00", tz="UTC")
    prev = lambda minutes: (exp - pd.Timedelta(minutes=minutes)).isoformat()
    assert engine.window_for(cfg, "15m", None, exp) == 3 and engine.window_for(cfg, "15m", prev(15), exp) == 3
    assert engine.window_for(cfg, "15m", prev(45), exp) == 4                      # 3 candles missed + the newest
    assert engine.window_for(cfg, "15m", prev(90), exp) == 6                      # capped: 75 minutes of 15-minute candles + 1
    assert engine.window_for(cfg, "15m", prev(60 * 48), exp) == 6
    assert engine.window_for(cfg, "1d", prev(60 * 24 * 3), exp) == 4


# ------------------------------------------------------------------------------------------ commands
@pytest.fixture
def chat(monkeypatch, tmp_path):
    sent = {"messages": []}

    class R:
        status_code = 200

        def __init__(self, body):
            self._b = body

        def json(self):
            return self._b

    def fake_post(url, json=None, data=None, files=None, timeout=None):
        if url.endswith("sendMessage"):
            sent["messages"].append(json["text"])
        return R({"ok": True, "result": {"username": "bot"}})

    monkeypatch.setattr(telegram.requests, "post", fake_post)
    for k, v in {"TELEGRAM_BOT_TOKEN": "1:T", "TELEGRAM_CHAT_ID": "2", "FYERS_APP_ID": "ABCD1234-100",
                 "FYERS_SECRET_ID": "S3CRET", "FYERS_PIN": "1234", "FYERS_USER_ID": USER, "FYERS_TOTP_KEY": TOTP_KEY}.items():
        monkeypatch.setenv(k, v)
    monkeypatch.delenv("FYERS_REDIRECT_URI", raising=False)
    monkeypatch.delenv("FYERS_LOGIN_URL", raising=False)
    http = lists()
    http.login_clock = time.time                              # the commands go by the real clock
    for sym in ("NSE:NIFTY50-INDEX", "NSE:RELIANCE-EQ", "MCX:GOLD26DECFUT"):
        http.series[sym] = nse_series()
    monkeypatch.setattr(fyers, "RequestsHttp", lambda: http)
    monkeypatch.setattr(cli, "load_config", lambda path=None: load_config())
    return sent, http


def test_login_command_logs_in_by_itself_proves_it_works_and_saves_the_pass(chat):
    sent, http = chat
    assert cli.main(["fyers-login"]) == 0
    msg = sent["messages"][-1]
    assert "Fyers login works" in msg and "every day" in msg and "Nifty 50" in msg
    assert TokenStore(creds()).load()["access_token"] == "LOGIN-1" and http.logins == 1
    assert "NSE:NIFTY50-INDEX" in [p["symbol"] for p, _ in http.gets]
    assert not any(TOTP_KEY in m or "LOGIN-1" in m or "BEARER" in m for m in sent["messages"])      # secrets never go to Telegram
    assert cli.main(["fyers-login"]) == 0 and http.logins == 2                      # the button always logs in anew


def test_login_command_says_which_secret_is_wrong_and_can_be_run_again_at_once(chat):
    sent, http = chat
    http.login_refuse["verify_pin_v2"] = [(400, {"s": "error", "message": "Invalid PIN"})]
    assert cli.main(["fyers-login"]) == 1
    assert "Fyers login failed" in sent["messages"][-1] and "FYERS_PIN" in sent["messages"][-1]
    assert not TokenStore(creds()).load().get("access_token")
    assert cli.main(["fyers-login"]) == 0                                            # you fixed it: no waiting for tomorrow
    assert TokenStore(creds()).load().get("access_token") and "hold_until" not in TokenStore(creds()).load()


def test_login_command_reports_a_pass_that_logs_in_but_cannot_read_prices(chat):
    sent, http = chat
    http.reject_all = True
    assert cli.main(["fyers-login"]) == 1
    assert "login worked, but the test read failed" in sent["messages"][-1]


def test_login_command_without_the_login_secrets_sends_the_login_link(chat, monkeypatch):
    sent, http = chat
    monkeypatch.delenv("FYERS_USER_ID")
    monkeypatch.delenv("FYERS_TOTP_KEY")
    assert cli.main(["fyers-login"]) == 0
    msg = sent["messages"][-1]
    assert "Fyers login" in msg and "generate-authcode?client_id=ABCD1234-100" in msg and "S3CRET" not in msg
    assert "4 - Fyers Login" in msg and "FYERS_USER_ID and FYERS_TOTP_KEY" in msg
    sent["messages"].clear()
    monkeypatch.setenv("FYERS_LOGIN_URL", "https://x/?s=ok&auth_code=GOOD-CODE")     # how the workflow passes the pasted address
    assert cli.main(["fyers-login"]) == 0 and "good for today only" in sent["messages"][-1]


def test_typing_link_in_the_box_sends_the_by_hand_link_even_when_the_automatic_login_is_set_up(chat, monkeypatch):
    sent, http = chat
    monkeypatch.setenv("FYERS_LOGIN_URL", "link")
    assert cli.main(["fyers-login"]) == 0
    assert "generate-authcode?client_id=ABCD1234-100" in sent["messages"][-1] and http.logins == 0


def test_login_command_saves_a_login_done_by_hand_and_proves_it_works(chat, monkeypatch):
    sent, http = chat
    monkeypatch.delenv("FYERS_USER_ID")
    monkeypatch.delenv("FYERS_TOTP_KEY")
    pasted = "https://trade.fyers.in/api-login/redirect-uri/index.html?s=ok&code=200&auth_code=GOOD-CODE&state=ema_scanner"
    assert cli.main(["fyers-login", "--url", pasted]) == 0
    assert "Fyers login saved" in sent["messages"][-1] and "good for today only" in sent["messages"][-1]
    assert "FYERS_TOTP_KEY" in sent["messages"][-1]                                  # it says how to stop doing this by hand
    saved = TokenStore(creds()).load()
    assert saved["access_token"] == "AT-LOGIN" and "refresh_token" not in saved
    assert not any("RT-LOGIN" in m or "AT-LOGIN" in m for m in sent["messages"])      # tokens never go to Telegram
    assert "NSE:NIFTY50-INDEX" in [p["symbol"] for p, _ in http.gets]
    monkeypatch.setenv("FYERS_USER_ID", USER)
    monkeypatch.setenv("FYERS_TOTP_KEY", TOTP_KEY)
    assert cli.main(["fyers-login", "--url", pasted]) == 0 and "From tomorrow" in sent["messages"][-1]


def test_login_command_explains_a_rejected_address(chat):
    sent, http = chat
    assert cli.main(["fyers-login", "--url", "https://x/?auth_code=BAD"]) == 1
    assert "Fyers login failed" in sent["messages"][-1] and "Invalid auth code" in sent["messages"][-1]
    assert not TokenStore(creds()).load()


def test_login_command_needs_the_secrets(chat, monkeypatch):
    monkeypatch.delenv("FYERS_PIN")
    assert cli.main(["fyers-login", "--url", "x"]) == 2


def test_check_setup_logs_in_by_itself_and_reports_codes_candles_and_budget(chat):
    sent, http = chat
    cfg = load_config()
    items = [Instrument("RELIANCE.NS", "Reliance", "NSE"), Instrument("^NSEI", "Nifty 50", "NSE"),
             Instrument("MCX:GOLD1!", "Gold", "MCX"), Instrument("NOPE.NS", "Not Listed", "NSE")]
    lines = []
    feed = cli._check_fyers(cfg, items, pd.Timestamp("2026-11-03 10:00", tz="UTC"), lambda lvl, msg: lines.append(f"[{lvl}] {msg}"))
    text = "\n".join(lines)
    assert feed is not None and "[PASS] Fyers login works · the scanner logged in by itself just now" in text
    assert "[WARN] The automatic daily login" not in text
    assert "Fyers codes found for 3 of 4 Indian symbols" in text and "not found: Not Listed" in text
    assert "MCX contracts in use: Gold → GOLD26DECFUT" in text
    assert "[PASS] Fyers Nifty 50 (NSE:NIFTY50-INDEX) 1h: 75 candles" in text and "[PASS] Fyers Gold (MCX:GOLD26DECFUT) 1d" in text
    assert "Fyers requests needed per trading day" in text and "15m candles are NOT counted" in text
    assert sent["messages"] == [] and http.logins == 1


def test_check_setup_reuses_a_pass_saved_today_and_says_when_it_was_made(chat):
    sent, http = chat
    cli.main(["fyers-login"])
    logins = http.logins
    lines = []
    cli._check_fyers(load_config(), [Instrument("^NSEI", "Nifty 50", "NSE")], pd.Timestamp("2026-11-03 10:00", tz="UTC"),
                     lambda lvl, msg: lines.append(f"[{lvl}] {msg}"))
    text = "\n".join(lines)
    assert "[PASS] Fyers login works · today's saved login, made " in text and http.logins == logins


def test_check_setup_without_the_login_secrets_warns_and_sends_the_link_to_telegram_not_to_the_public_log(chat, monkeypatch):
    sent, http = chat
    monkeypatch.delenv("FYERS_USER_ID")
    monkeypatch.delenv("FYERS_TOTP_KEY")
    lines = []
    tg = telegram.Telegram.from_env()
    cli._check_fyers(load_config(), [Instrument("^NSEI", "Nifty 50", "NSE")], pd.Timestamp("2026-11-03 10:00", tz="UTC"),
                     lambda lvl, msg: lines.append(f"[{lvl}] {msg}"), tg)
    text = "\n".join(lines)
    assert "[FAIL] Fyers login: Fyers wants a new login every day" in text and "FYERS_USER_ID and FYERS_TOTP_KEY" in text
    assert "ABCD1234-100" not in text and "generate-authcode" not in text           # nothing about the app in a public log
    assert "generate-authcode?client_id=ABCD1234-100" in sent["messages"][-1]       # it goes to your private Telegram chat


def test_check_setup_after_a_login_by_hand_works_today_but_warns_about_tomorrow(chat, monkeypatch):
    sent, http = chat
    monkeypatch.delenv("FYERS_USER_ID")
    monkeypatch.delenv("FYERS_TOTP_KEY")
    cli.main(["fyers-login", "--url", "auth_code=GOOD-CODE"])
    lines = []
    cli._check_fyers(load_config(), [Instrument("^NSEI", "Nifty 50", "NSE")], pd.Timestamp("2026-11-03 10:00", tz="UTC"),
                     lambda lvl, msg: lines.append(f"[{lvl}] {msg}"))
    text = "\n".join(lines)
    assert "[PASS] Fyers login works · today's saved login" in text
    assert "[WARN] The automatic daily login is NOT set up (missing secrets: FYERS_USER_ID, FYERS_TOTP_KEY)" in text


def test_check_setup_with_a_wrong_secret_names_it_and_sends_no_login_link(chat):
    sent, http = chat
    http.login_refuse["verify_otp"] = [(400, {"s": "error", "message": "Invalid TOTP"})]
    lines = []
    tg = telegram.Telegram.from_env()
    feed = cli._check_fyers(load_config(), [Instrument("^NSEI", "Nifty 50", "NSE")], pd.Timestamp("2026-11-03 10:00", tz="UTC"),
                            lambda lvl, msg: lines.append(f"[{lvl}] {msg}"), tg)
    text = "\n".join(lines)
    assert feed is not None and "[FAIL] Fyers login: Fyers did not accept the 6-digit TOTP code" in text and "FYERS_TOTP_KEY" in text
    assert "Fix the secret named above" in text and sent["messages"] == []
    again = []                                                                        # Check Setup is not held back by the waiting time
    cli._check_fyers(load_config(), [Instrument("^NSEI", "Nifty 50", "NSE")], pd.Timestamp("2026-11-03 10:00", tz="UTC"),
                     lambda lvl, msg: again.append(f"[{lvl}] {msg}"))
    assert "[PASS] Fyers login works" in "\n".join(again)


def test_without_the_secrets_check_setup_says_how_to_switch_fyers_on(monkeypatch):
    for k in ("FYERS_APP_ID", "FYERS_SECRET_ID", "FYERS_PIN"):
        monkeypatch.delenv(k, raising=False)
    lines = []
    assert cli._check_fyers(load_config(), [Instrument("^NSEI", "Nifty 50", "NSE")], pd.Timestamp("2026-11-03 10:00", tz="UTC"),
                            lambda lvl, msg: lines.append(msg)) is None
    assert "FYERS_APP_ID, FYERS_SECRET_ID, FYERS_PIN" in lines[0]


def test_reports_and_backtests_do_not_spend_the_free_plans_requests(chat):
    items = [Instrument("RELIANCE.NS", "Reliance", "NSE")]
    cfg = load_config()
    assert data.make_fetcher(cfg, items, purpose="backtest").fy is None
    assert data.make_fetcher(cfg, items, purpose="report").fy is None                  # standard plan: TradingView is fine after the close
    assert data.make_fetcher(cfg, items, purpose="scan").fy is not None
    cfg["fyers"]["plan"] = "prime"
    assert data.make_fetcher(cfg, items, purpose="report").fy is not None


def test_a_broken_fyers_setup_never_stops_the_scanner(chat, monkeypatch):
    monkeypatch.setattr(fyers, "setup", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom")))
    f = data.make_fetcher(load_config(), [Instrument("RELIANCE.NS", "Reliance", "NSE")])
    assert f.fy is None and any("Fyers could not be set up" in e for e in f.events)


# ------------------------------------------------------------------------------------------ daily budget details
def test_the_free_plan_keeps_part_of_the_day_for_mcx_which_has_no_other_source():
    c = Clock()
    lim = Limiter(per_second=100, per_minute=1000, per_day=10, clock=c.now, sleep=c.sleep)
    for _ in range(7):
        lim.acquire(reserve=3)                                                   # NSE-type requests: 7 allowed (10 - 3 kept back)
    with pytest.raises(fyers.BudgetReserved):
        lim.acquire(reserve=3)
    for _ in range(3):
        lim.acquire()                                                            # MCX may still use what was kept back
    with pytest.raises(BudgetExhausted) as e:
        lim.acquire()
    assert not isinstance(e.value, fyers.BudgetReserved)
    std = load_config()["fyers"]["limits"]["standard"]
    assert std["reserve_mcx"] >= 300 and load_config()["fyers"]["limits"]["prime"]["reserve_mcx"] == 0


def test_when_the_nse_share_is_used_up_mcx_still_gets_candles_and_the_run_is_not_halted(tmp_path):
    http = FakeFyers()
    for k in range(5):
        http.series[f"NSE:S{k}-EQ"] = nse_series()
    for k in range(3):
        http.series[f"MCX:G{k}FUT"] = nse_series()
    feed = logged_in(tmp_path, http, plan="standard", per_day=6, reserve_mcx=3)
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(5)}, "1h")
    assert len(out) == 3 and len(failed) == 2 and not feed.down                  # only 3 of 6 requests were open to NSE
    assert "kept for MCX" in feed.reasons[failed[0]]
    out2, failed2 = feed.fetch({f"G{k}": f"MCX:G{k}FUT" for k in range(3)}, "1h")
    assert len(out2) == 3 and failed2 == [] and not feed.down


def test_a_run_never_spends_more_than_its_time_allowance_on_fyers(tmp_path):
    http = FakeFyers()
    for k in range(8):
        http.series[f"NSE:S{k}-EQ"] = nse_series()
    feed = logged_in(tmp_path, http, plan="prime")
    feed.fcfg = dict(feed.fcfg, max_seconds=100, workers=1)
    ticks = iter([0.0, 10.0, 20.0, 30.0, 500.0] + [500.0] * 50)                    # the 4th request finds the allowance gone
    feed.clock = lambda: next(ticks)
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(8)}, "1h")
    assert 0 < len(out) < 8 and len(out) + len(failed) == 8
    assert "time allowance" in feed.down and any("TradingView" in e for e in feed.events)


# ------------------------------------------------------------------------------------------ fast markets are not held up
def test_slow_indian_rounds_on_the_free_plan_never_hold_back_crypto_and_us_alerts(tmp_path):
    cfg = load_config()
    items = [Instrument("BTC-USD", "Bitcoin", "CRYPTO"), Instrument("MSFT", "Microsoft", "US"),
             Instrument("RELIANCE.NS", "Reliance", "NSE"), Instrument("MCX:GOLD1!", "Gold", "MCX")]

    class F:                                                                     # a fetcher that looks like the real one
        def __init__(self, plan):
            self.fy = type("Fy", (), {"plan": plan})() if plan else None

    assert [sorted(g) for g in cli._market_groups(items, F("standard"))] == [["CRYPTO", "US"], ["MCX", "NSE"]]
    assert [sorted(g) for g in cli._market_groups(items, F("prime"))] == [["CRYPTO", "MCX", "NSE", "US"]]
    assert [sorted(g) for g in cli._market_groups(items, F(None))] == [["CRYPTO", "MCX", "NSE", "US"]]
    only_indian = [i for i in items if i.market in ("NSE", "MCX")]
    assert [sorted(g) for g in cli._market_groups(only_indian, F("standard"))] == [["MCX", "NSE"]]


# ------------------------------------------------------------------------------------------ commodities on the free plan
ENV = {"FYERS_APP_ID": "ABCD1234-100", "FYERS_SECRET_ID": "S3CRET", "FYERS_PIN": "1234"}


def mcx_and_nse():
    m = Instrument("MCX:GOLD1!", "Gold", "MCX", tfs={"15m", "1h", "4h", "1d", "1w"})
    n = Instrument("RELIANCE.NS", "Reliance", "NSE", tfs={"15m", "1h", "4h", "1d", "1w"})
    return [m, n]


def test_commodities_lose_15_minute_candles_on_the_free_plan_because_no_other_source_has_mcx(tmp_path):
    cfg, items = load_config(), mcx_and_nse()
    feed = fyers.setup(cfg, items, "scan", http=lists(), env=ENV, now=lambda: NOW)
    assert feed is not None and items[0].fyers == "MCX:GOLD26DECFUT"
    assert items[0].tfs == {"1h", "4h", "1d", "1w"}                                # no 15 Min for Gold ...
    assert items[1].tfs == {"15m", "1h", "4h", "1d", "1w"}                         # ... Reliance keeps it (TradingView, delayed)


def test_the_paid_plan_keeps_every_timeframe_for_commodities():
    cfg, items = load_config(), mcx_and_nse()
    cfg["fyers"]["plan"] = "prime"
    fyers.setup(cfg, items, "scan", http=lists(), env=ENV, now=lambda: NOW)
    assert items[0].tfs == {"15m", "1h", "4h", "1d", "1w"}


def test_the_daily_report_on_the_free_plan_asks_fyers_for_commodities_only():
    cfg, items = load_config(), mcx_and_nse()
    feed = fyers.setup(cfg, items, "report", http=lists(), env=ENV, now=lambda: NOW)
    assert feed is not None and items[0].fyers == "MCX:GOLD26DECFUT" and items[1].fyers == ""
    assert fyers.setup(cfg, [items[1]], "report", http=lists(), env=ENV, now=lambda: NOW) is None      # nothing for Fyers to do
    cfg["fyers"]["plan"] = "prime"
    items2 = mcx_and_nse()
    fyers.setup(cfg, items2, "report", http=lists(), env=ENV, now=lambda: NOW)
    assert items2[1].fyers == "NSE:RELIANCE-EQ"                                    # the paid plan has room for everything


def test_the_backtest_keeps_the_global_stand_ins_because_real_mcx_history_needs_fyers(monkeypatch):
    from scanner import universe
    for k, v in ENV.items():
        monkeypatch.setenv(k, v)
    cfg = load_config()
    only = ("commodities", "commodities_global")
    live, notes = universe.build(cfg, only)
    assert {i.market for i in live} == {"MCX"} and "skipped" not in notes.get("commodities", "")
    test, notes = universe.build(cfg, only, purpose="backtest")
    assert {i.market for i in test} == {"FUT"} and "skipped" in notes["commodities"]


def test_the_plan_can_be_set_with_a_github_secret_without_editing_any_file(monkeypatch):
    from scanner.config import ConfigError
    assert load_config()["fyers"]["plan"] == "standard"
    monkeypatch.setenv("FYERS_PLAN", " Prime ")
    assert load_config()["fyers"]["plan"] == "prime"
    monkeypatch.setenv("FYERS_PLAN", "")                                           # an unset GitHub secret arrives as an empty text
    assert load_config()["fyers"]["plan"] == "standard"
    monkeypatch.setenv("FYERS_PLAN", "gold")
    with pytest.raises(ConfigError, match="FYERS_PLAN"):
        load_config()


# ------------------------------------------------------------------------------------------ commodity contracts that cannot be looked up
def mcx_series(last_day=FRI):
    return candles_of(intraday_raw("MCX", 60, last_day, 3, lambda n: uptrend(n)))


def mcx_feed(tmp_path, series, alts, plan="standard"):
    http = FakeFyers()
    http.series.update(series)
    feed = logged_in(tmp_path, http, plan=plan)
    feed.alts = {"MCX:GOLD1!": alts}
    return feed, http


def test_a_guessed_month_that_does_not_exist_is_skipped_and_the_working_contract_is_remembered(tmp_path):
    feed, http = mcx_feed(tmp_path, {"MCX:GOLD26DECFUT": mcx_series()}, ["MCX:GOLD26DECFUT", "MCX:GOLD27JAN" "FUT"])
    out, failed = feed.fetch({"MCX:GOLD1!": "MCX:GOLD26NOVFUT"}, "1h")                 # November: Gold has no such contract
    assert list(out) == ["MCX:GOLD1!"] and failed == [] and feed.picked == {"MCX:GOLD1!": "MCX:GOLD26DECFUT"}
    assert [g[0]["symbol"] for g in http.gets] == ["MCX:GOLD26NOVFUT", "MCX:GOLD26DECFUT"]
    assert "MCX:GOLD1!" not in feed.invalid and "using MCX:GOLD26DECFUT" in feed.switched[0]
    http.gets.clear()
    feed.fetch({"MCX:GOLD1!": "MCX:GOLD26NOVFUT"}, "1d")                                # later requests go straight to the right code
    assert [g[0]["symbol"] for g in http.gets] == ["MCX:GOLD26DECFUT"]


def test_a_contract_that_has_expired_is_not_used_even_though_it_still_answers(tmp_path):
    old = mcx_series(date(2026, 10, 9))                                                 # last candle three weeks ago
    feed, http = mcx_feed(tmp_path, {"MCX:GOLD26OCTFUT": old, "MCX:GOLD26DECFUT": mcx_series()}, ["MCX:GOLD26DECFUT"])
    out, failed = feed.fetch({"MCX:GOLD1!": "MCX:GOLD26OCTFUT"}, "1h")
    assert failed == [] and feed.picked["MCX:GOLD1!"] == "MCX:GOLD26DECFUT" and len(out["MCX:GOLD1!"]) > 0


def test_when_no_contract_works_the_symbol_fails_cleanly_and_other_commodities_carry_on(tmp_path):
    feed, http = mcx_feed(tmp_path, {"MCX:SILVER26DECFUT": mcx_series()}, ["MCX:GOLD26DECFUT"])
    out, failed = feed.fetch({"MCX:GOLD1!": "MCX:GOLD26NOVFUT", "MCX:SILVER1!": "MCX:SILVER26DECFUT"}, "1h")
    assert list(out) == ["MCX:SILVER1!"] and failed == ["MCX:GOLD1!"] and "valid symbol" in feed.reasons["MCX:GOLD1!"]
    assert not feed.down and "MCX:GOLD1!" in feed.invalid and feed.picked == {}


def test_a_login_or_rate_problem_does_not_make_the_scanner_try_every_month(tmp_path):
    feed, http = mcx_feed(tmp_path, {}, ["MCX:GOLD26DECFUT", "MCX:GOLD27FEBFUT"])
    http.rate_limit_after = 0
    out, failed = feed.fetch({"MCX:GOLD1!": "MCX:GOLD26NOVFUT"}, "1h")
    assert failed == ["MCX:GOLD1!"] and feed.down and {g[0]["symbol"] for g in http.gets} == {"MCX:GOLD26NOVFUT"}


def test_contracts_found_today_are_kept_in_the_saved_state_for_the_day_only(tmp_path):
    feed, http = mcx_feed(tmp_path, {"MCX:GOLD26DECFUT": mcx_series()}, ["MCX:GOLD26DECFUT"])
    feed.fetch({"MCX:GOLD1!": "MCX:GOLD26NOVFUT"}, "1h")
    state = {}
    feed.save_state(state)
    assert state["fyers"]["picked"] == {"MCX:GOLD1!": "MCX:GOLD26DECFUT"}
    same_day, _ = mcx_feed(tmp_path, {}, [])
    same_day.attach_state(state)
    assert same_day.picked == {"MCX:GOLD1!": "MCX:GOLD26DECFUT"}
    next_day, _ = mcx_feed(tmp_path, {}, [])
    next_day.now = lambda: NOW + timedelta(days=1)
    next_day.attach_state(state)
    assert next_day.picked == {}
    older = {"fyers": {"day": "2026-11-03", "calls": 5}}                                # state written by an older scanner version
    same_day.picked = {}
    same_day.attach_state(older)
    assert same_day.picked == {} and same_day.limiter.used == 5


def expiry_master(rows):
    """A commodity list whose 9th column holds the last trading day (epoch seconds), like the real one."""
    def row(n, ticker, expiry):
        r = mcx_row(n, ticker)
        r[8] = str(int(datetime(*expiry, 18, 0, tzinfo=timezone.utc).timestamp()))
        return r
    return csv_text([row(i, t, e) for i, (t, e) in enumerate(rows)])


def test_the_last_trading_day_in_the_list_decides_which_contract_is_in_use(tmp_path):
    http = lists()
    http.masters["MCX_COM"] = expiry_master([
        ("MCX:CRUDEOIL26OCTFUT", (2026, 10, 20)),         # expired two weeks ago but still in the file
        ("MCX:CRUDEOIL26NOVFUT", (2026, 11, 19)), ("MCX:CRUDEOIL26DECFUT", (2026, 12, 21)), ("MCX:CRUDEOIL27JANFUT", (2027, 1, 20)),
        ("MCX:GOLD26DECFUT", (2026, 12, 4)), ("MCX:GOLD27FEBFUT", (2027, 2, 4))])
    cfg = load_config()["fyers"]
    for today, want, spare in [(date(2026, 11, 3), "MCX:CRUDEOIL26NOVFUT", ["MCX:CRUDEOIL26DECFUT", "MCX:CRUDEOIL27JANFUT"]),
                               (date(2026, 11, 16), "MCX:CRUDEOIL26NOVFUT", ["MCX:CRUDEOIL26DECFUT", "MCX:CRUDEOIL27JANFUT"]),
                               (date(2026, 11, 17), "MCX:CRUDEOIL26DECFUT", ["MCX:CRUDEOIL27JANFUT"]),      # fewer than 3 days left
                               (date(2026, 11, 25), "MCX:CRUDEOIL26DECFUT", ["MCX:CRUDEOIL27JANFUT"])]:
        item = [Instrument("MCX:CRUDEOIL1!", "Crude Oil", "MCX"), Instrument("MCX:GOLD1!", "Gold", "MCX")]
        resolve(item, cfg, Master(cfg, http, now=lambda: NOW, folder=tmp_path / f"m{today.day}"), today=today)
        assert item[0].fyers == want and item[0].fyers_alts == spare
        assert item[1].fyers == "MCX:GOLD26DECFUT" and item[1].fyers_alts == ["MCX:GOLD27FEBFUT"]


def test_without_dates_in_the_list_contracts_of_past_months_are_skipped(tmp_path):
    http = lists()
    http.masters["MCX_COM"] = csv_text([mcx_row(i, t) for i, t in enumerate(
        ["MCX:CRUDEOIL26SEPFUT", "MCX:CRUDEOIL26OCTFUT", "MCX:CRUDEOIL26NOVFUT", "MCX:CRUDEOIL26DECFUT",
         "MCX:GOLD26DECFUT", "MCX:SILVER26DECFUT", "MCX:ZINC26NOVFUT"])])
    item = [Instrument("MCX:CRUDEOIL1!", "Crude Oil", "MCX")]
    cfg = load_config()["fyers"]
    resolve(item, cfg, Master(cfg, http, now=lambda: NOW, folder=tmp_path / "m"), today=date(2026, 11, 3))
    assert item[0].fyers == "MCX:CRUDEOIL26NOVFUT" and item[0].fyers_alts == ["MCX:CRUDEOIL26DECFUT"]


def test_guessed_contract_codes_run_from_this_month_across_the_new_year():
    from scanner.fyers import guess_contracts
    assert guess_contracts("GOLD", date(2026, 11, 3), 4) == ["MCX:GOLD26NOVFUT", "MCX:GOLD26DECFUT", "MCX:GOLD27JANFUT", "MCX:GOLD27FEBFUT"]


def test_setup_passes_the_spare_codes_to_the_feed_and_tells_when_the_list_was_unreadable(chat):
    sent, http = chat
    http.masters.pop("MCX_COM")
    cfg = load_config()
    items = [Instrument("MCX:GOLD1!", "Gold", "MCX"), Instrument("RELIANCE.NS", "Reliance", "NSE")]
    f = data.make_fetcher(cfg, items, purpose="scan")
    spare = f.fy.alts["MCX:GOLD1!"]
    assert len(spare) == 6 and all(c.startswith("MCX:GOLD") and c.endswith("FUT") for c in spare)      # the months after this one
    assert any("list of commodity contracts could not be read" in e for e in f.events)
    assert any("MCX_COM: download failed" in e for e in f.events)


def test_symbols_fyers_has_no_code_for_are_named_in_the_alert(chat):
    items = [Instrument("RELIANCE.NS", "Reliance", "NSE"), Instrument("NOPE.NS", "Not Listed Ltd", "NSE"),
             Instrument("MCX:LEAD1!", "Lead", "MCX"), Instrument("MCX:CPO1!", "Crude Palm Oil", "MCX", optional=True)]
    f = data.make_fetcher(load_config(), items, purpose="scan")
    assert any("no code for 1 commodity: Lead" in e and "skipped" in e for e in f.events)         # the optional one is not mentioned
    assert any("no code for 1 of 2 shares and indices: Not Listed Ltd" in e and "TradingView" in e for e in f.events)


def test_a_few_unmatched_shares_are_not_worth_an_alert(chat):
    sent, http = chat
    http.masters["NSE_CM"] = csv_text([nse_row(i, f"NSE:S{i}-EQ") for i in range(60)])
    cfg = load_config()
    few = [Instrument(f"S{k}.NS", f"S{k}", "NSE") for k in range(40)] + [Instrument("NOPE.NS", "Not Listed Ltd", "NSE")]
    assert not any("shares and indices" in e for e in data.make_fetcher(cfg, few, purpose="scan").events)       # 1 of 41: TradingView serves it
    many = [Instrument(f"S{k}.NS", f"S{k}", "NSE") for k in range(40)] + [Instrument(f"X{k}.NS", f"X{k}", "NSE") for k in range(10)]
    ev = data.make_fetcher(cfg, many, purpose="scan").events
    assert any("no code for 10 of 50 shares and indices: X0, X1" in e for e in ev)                           # 10 of 50: a real problem


def test_a_commodity_without_data_says_why_in_the_digest_and_the_report(tmp_path):
    cfg = load_config()
    cfg["timeframes"] = ["1h", "1d"]
    now = pd.Timestamp("2026-11-03 10:00", tz="UTC")
    gold, lead = Instrument("MCX:GOLD1!", "Gold", "MCX", universes=["commodities"], tfs={"1h", "1d"}), \
        Instrument("MCX:LEAD1!", "Lead", "MCX", universes=["commodities"], tfs={"1h", "1d"})
    raw = intraday_raw("MCX", 60, FRI, 40, lambda n: uptrend(n))
    daily = intraday_raw("MCX", 60, FRI, 40, lambda n: uptrend(n))

    class Fake:
        why = {}
        events = ["Fyers was slow today - some prices may be late."]

        def __call__(self, syms, itv):
            self.why = {s: "Fyers: Please provide a valid symbol; TradingView had no candles" for s in syms if s != gold.symbol}
            out = {s: (raw if itv == "1h" else daily) for s in syms if s == gold.symbol}
            return out, [s for s in syms if s not in out]

    coll = engine.collect(cfg, [gold, lead], {"MCX": ["1h", "1d"]}, now, Fake())
    notes = {"commodities": "2 symbols (from config.yaml)"}
    text = report.summary_text(coll, cfg, now, notes)
    assert "Where data is missing" in text and "Commodities (MCX)" in text and "1 of 2 without data" in text
    assert "Please provide a valid symbol" in text and "Fyers was slow today" in text
    md, _ = report.build_report(coll, [gold, lead], cfg, now, notes)
    assert "Where data is missing, and why" in md and "Please provide a valid symbol" in md
    assert "Commodities (global proxy" not in text and "Commodities (global proxy" not in md       # never built -> not shown


def test_the_setup_message_lists_every_warning_so_the_log_need_not_be_opened():
    lines = [("INFO", "Scanner v1.3.0 · Python 3.12"), ("PASS", "Telegram bot found: @bot"),
             ("WARN", "Fyers codes found for 5 of 9 Indian symbols · not found: Lead, Zinc"),
             ("FAIL", "Fyers login: Fyers did not accept the PIN (secret FYERS_PIN)"), ("PASS", "Fyers login works · today's saved login"),
             ("INFO", "Fyers plan: standard · pace 40 requests/minute"), ("INFO", "MCX contracts in use: Gold → GOLD26DECFUT"),
             ("PASS", "NSE: TradingView data mode 'delayed_streaming_900' = 15 min delay (matches config)"),
             ("INFO", "NSE newest day candle is labelled 03 Nov"), ("WARN", "Tags <b> & more")]
    text = cli.setup_message(lines)
    assert text.startswith("🩺 <b>Setup check</b> · scanner v") and "3 passed · 2 warnings · 1 failed" in text
    assert "⚠️ Fyers codes found for 5 of 9 Indian symbols · not found: Lead, Zinc" in text
    assert "❌ Fyers login: Fyers did not accept the PIN (secret FYERS_PIN)" in text and "Tags &lt;b&gt; &amp; more" in text
    assert "Fyers plan: standard" in text and "MCX contracts in use: Gold → GOLD26DECFUT" in text and "data mode" in text
    assert "newest day candle" not in text and len(text) < 3900
    many = [("WARN", "x" * 250 + f" {n}") for n in range(60)]
    assert len(cli.setup_message(many)) <= 3900
    names = "; ".join(f"Commodity{n} → CONTRACT{n}26DECFUT" for n in range(18))
    shown = cli.setup_message([("INFO", "MCX contracts in use: " + names)])
    assert "Commodity17 → CONTRACT1726DECFUT" in shown                                  # the whole list of contracts fits


def test_warnings_also_appear_as_github_annotations_but_only_inside_github(capsys, monkeypatch):
    monkeypatch.setenv("GITHUB_ACTIONS", "true")
    cli._annotate("WARN", "100% sure\nsecond line")
    cli._annotate("FAIL", "broken")
    cli._annotate("PASS", "fine")
    out = capsys.readouterr().out.splitlines()
    assert out == ["::warning title=Setup check::100%25 sure%0Asecond line", "::error title=Setup check::broken"]
    monkeypatch.delenv("GITHUB_ACTIONS")
    cli._annotate("WARN", "again")
    assert capsys.readouterr().out == ""


TFS = {"1h", "4h", "1d", "1w"}


def full_history(http, *codes):
    """Candles long enough for every timeframe (60 closed candles are needed, weekly ones too)."""
    for code in codes:
        http.by_resolution[code] = {"60": candles_of(intraday_raw("MCX", 60, FRI, 90, uptrend)),
                                    "D": candles_of(daily_raw("MCX", FRI, 700, uptrend))}
    http.by_resolution["NSE:NIFTY50-INDEX"] = {"D": candles_of(daily_raw("NSE", FRI, 700, uptrend))}


def commodities(*names):
    return [Instrument("^NSEI", "Nifty 50", "NSE")] + [Instrument(f"MCX:{n.upper().replace(' ', '')}1!", n, "MCX", tfs=set(TFS)) for n in names]


def check_setup_lines(items, now="2026-11-03 10:00"):
    lines = []
    cli._check_fyers(load_config(), items, pd.Timestamp(now, tz="UTC"), lambda lvl, msg: lines.append(f"[{lvl}] {msg}"))
    return "\n".join(lines)


def test_check_setup_asks_for_every_commodity_contract_the_way_the_report_does_and_names_the_ones_that_fail(chat):
    sent, http = chat
    cli.main(["fyers-login", "--url", "auth_code=GOOD-CODE"])
    full_history(http, "MCX:GOLD26DECFUT", "MCX:CRUDEOIL26NOVFUT")
    text = check_setup_lines(commodities("Gold", "Crude Oil", "Silver"))
    assert "[WARN] Fyers commodity candles, requested the way the daily report does (1 Hour 2/3 · 4 Hour 2/3 · 1 Day 2/3 · 1 Week 2/3)" in text
    assert "problems: Silver (1d: Please provide a valid symbol)" in text
    assert "MCX contracts in use: Gold → GOLD26DECFUT; Crude Oil → CRUDEOIL26NOVFUT; Silver → SILVER26DECFUT" in text
    assert "[PASS] Fyers Nifty 50 day candles for the weekly view: " in text


def test_check_setup_passes_when_every_commodity_works_on_every_timeframe(chat):
    sent, http = chat
    cli.main(["fyers-login", "--url", "auth_code=GOOD-CODE"])
    full_history(http, "MCX:GOLD26DECFUT", "MCX:CRUDEOIL26NOVFUT")
    text = check_setup_lines(commodities("Gold", "Crude Oil"))
    assert "[PASS] Fyers commodity candles, requested the way the daily report does (1 Hour 2/2 · 4 Hour 2/2 · 1 Day 2/2 · 1 Week 2/2)" in text
    assert "[WARN]" not in text and "[FAIL]" not in text


def test_check_setup_flags_commodities_whose_candles_are_too_few_to_judge(chat):
    sent, http = chat
    cli.main(["fyers-login", "--url", "auth_code=GOOD-CODE"])
    full_history(http, "MCX:GOLD26DECFUT")
    http.by_resolution["MCX:GOLD26DECFUT"]["D"] = candles_of(daily_raw("MCX", FRI, 200, uptrend))          # only about 40 weeks
    text = check_setup_lines(commodities("Gold"))
    assert "[WARN] Fyers commodity candles" in text and "Gold (1 Week: only 4" in text and "closed candles (need 60)" in text


def test_check_setup_shows_when_fyers_has_to_be_given_up_during_the_commodity_requests(chat):
    sent, http = chat
    cli.main(["fyers-login", "--url", "auth_code=GOOD-CODE"])
    full_history(http, "MCX:GOLD26DECFUT", "MCX:CRUDEOIL26NOVFUT")
    http.refuse_codes["MCX:CRUDEOIL26NOVFUT"] = [TOO_FAST] * 60                                            # Fyers refuses this one for good
    text = check_setup_lines(commodities("Gold", "Crude Oil"))
    assert "[WARN] Fyers commodity candles, requested the way the daily report does" in text
    assert "Crude Oil (1d: rate limit" in text                                                              # day candles are asked first
    assert "[WARN] Fyers: Fyers said we are going too fast" in text and "the rest of this run uses TradingView" in text


def test_check_setup_says_so_when_fyers_was_slowed_down_but_nothing_was_lost(chat):
    sent, http = chat
    cli.main(["fyers-login", "--url", "auth_code=GOOD-CODE"])
    full_history(http, "MCX:GOLD26DECFUT", "MCX:CRUDEOIL26NOVFUT")
    http.refuse_codes["MCX:CRUDEOIL26NOVFUT"] = [TOO_FAST]                                                 # once, in the middle of the requests
    text = check_setup_lines(commodities("Gold", "Crude Oil"))
    assert "[INFO] Fyers asked the scanner to slow down 1 time(s)" in text and "[PASS] Fyers commodity candles" in text
    assert "[WARN]" not in text


def test_check_setup_says_so_when_no_commodity_code_was_found_at_all(chat):
    sent, http = chat
    cli.main(["fyers-login", "--url", "auth_code=GOOD-CODE"])
    http.masters["MCX_COM"] = csv_text([mcx_row(i, f"MCX:WEIRD{i}") for i in range(8)])      # a list in a layout we do not know
    lines = []
    cli._check_fyers(load_config(), [Instrument("^NSEI", "Nifty 50", "NSE"), Instrument("MCX:GOLD1!", "Gold", "MCX")],
                     pd.Timestamp("2026-11-03 10:00", tz="UTC"), lambda lvl, msg: lines.append(f"[{lvl}] {msg}"))
    text = "\n".join(lines)
    assert "[WARN] No Fyers contract code was found for any commodity (the list had 8 usable entries; first ones: MCX:WEIRD0" in text


# ------------------------------------------------------------------------------------------ steady pace, patience with "too fast"
TOO_FAST = (429, {"s": "error", "code": 429, "message": "You've reached the Standard plan limit of 5 requests/second. "
                                                         "Upgrade to Prime for higher API limits."})
PER_MINUTE = (429, {"s": "error", "code": 429, "message": "You've reached the Standard plan limit of 50 requests/minute."})
PER_DAY = (429, {"s": "error", "code": 429, "message": "You've reached the daily limit of 5000 requests per day."})


def six_shares(tmp_path, refusals):
    http = FakeFyers()
    for k in range(6):
        http.series[f"NSE:S{k}-EQ"] = nse_series()
    http.refusals = list(refusals)
    feed = logged_in(tmp_path, http, plan="standard")
    feed.fcfg["workers"] = 1                                                     # one at a time: the order is then predictable
    return feed, http, feed.limiter._sleep.__self__


def test_requests_are_spread_out_evenly_and_never_sent_in_bursts():
    c = Clock()
    lim = Limiter(per_second=4, per_minute=1000, per_day=1000, clock=c.now, sleep=c.sleep)
    times = []
    for _ in range(12):
        lim.acquire()
        times.append(c.t)
    assert min(b - a for a, b in zip(times, times[1:])) >= 0.25                    # never two together
    assert all(times[i + 4] - times[i] > 1.0 for i in range(len(times) - 4))       # never five inside one second


def test_the_limiter_can_be_told_to_wait_and_to_slow_down():
    c = Clock()
    lim = Limiter(per_second=4, per_minute=1000, per_day=1000, clock=c.now, sleep=c.sleep)
    lim.acquire()
    lim.pause(5)
    lim.acquire()
    assert c.t - 1000.0 >= 5                                                       # the next request waited out the pause
    before = lim.gap
    lim.slow_down()
    assert lim.gap == pytest.approx(before * 1.5)
    for _ in range(10):
        lim.slow_down()
    assert lim.gap == 2.0                                                          # never slower than one request in 2 seconds


def test_the_free_and_paid_plans_pace_well_below_the_per_second_limits():
    cfg = load_config()["fyers"]["limits"]
    assert cfg["standard"]["per_second"] <= 3 and cfg["prime"]["per_second"] <= 6      # Fyers: 5/s and 10/s, counted on arrival


def test_rate_scope_reads_which_limit_fyers_means():
    assert fyers.rate_scope(TOO_FAST[1]["message"]) == "second"
    assert fyers.rate_scope(PER_MINUTE[1]["message"]) == "minute"
    assert fyers.rate_scope(PER_DAY[1]["message"]) == "day"
    assert fyers.rate_scope("request limit reached") == "" and fyers.rate_scope(None) == ""


def test_messages_about_dates_or_contracts_are_not_mistaken_for_a_rate_limit_or_a_login_problem():
    c = fyers.classify
    assert c(200, -99, "Invalid date range for this resolution") == "other"
    assert c(200, -99, "Contract has expired") == "other"
    assert c(200, -99, "Request limit exceeded for this date range") == "other"
    assert c(429, 429, "") == "rate" and c(200, -99, "Too many requests") == "rate" and c(200, -429, "x") == "rate"
    assert c(401, -16, "Could not authenticate the user") == "auth" and c(200, -8, "x") == "auth"
    assert c(200, -99, "Your token has expired") == "auth" and c(200, -300, "Please provide a valid symbol") == "invalid"


def test_a_too_fast_reply_makes_the_scanner_wait_and_carry_on(tmp_path):
    feed, http, clock = six_shares(tmp_path, [TOO_FAST, TOO_FAST])
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(6)}, "1h")
    assert len(out) == 6 and failed == [] and not feed.down and feed.events == []     # nothing was lost, nobody is alarmed
    assert feed.slowdowns == 2 and len(http.gets) == 6 + 2                             # the refused request was sent again
    assert clock.t - 1000.0 >= 6.0                                                     # ... after waiting 2.5 s, then 3.5 s
    assert feed.limiter.gap > 1.1                                                      # and the pace stays lower for the rest of the run


def test_a_per_minute_reply_waits_a_minute_once_and_a_second_one_stops_the_run(tmp_path):
    feed, http, clock = six_shares(tmp_path, [PER_MINUTE])
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(6)}, "1h")
    assert len(out) == 6 and not feed.down and clock.t - 1000.0 >= 62
    feed, http, clock = six_shares(tmp_path, [PER_MINUTE, PER_MINUTE])               # Fyers blocks accounts that do it 3 times a day
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(6)}, "1h")
    assert out == {} and len(failed) == 6 and "too fast" in feed.down and len(http.gets) == 2


def test_a_daily_limit_reply_stops_the_run_at_once(tmp_path):
    feed, http, clock = six_shares(tmp_path, [PER_DAY])
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(6)}, "1h")
    assert out == {} and len(failed) == 6 and "too fast" in feed.down and len(http.gets) == 1


def test_too_fast_replies_that_keep_coming_end_the_run_after_a_few_waits(tmp_path):
    feed, http, clock = six_shares(tmp_path, [TOO_FAST] * 40)
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(6)}, "1h")
    assert out == {} and "too fast" in feed.down and len(http.gets) == 4                 # 4 tries for the first request, then stop
    assert any("the rest of this run uses TradingView" in e for e in feed.events)


def test_the_report_on_the_free_plan_asks_fyers_for_commodities_only_and_does_not_complain_about_shares(chat):
    items = [Instrument(f"S{k}.NS", f"S{k}", "NSE") for k in range(8)] + [Instrument("MCX:GOLD1!", "Gold", "MCX")]
    f = data.make_fetcher(load_config(), items, purpose="report")
    assert f.fy is not None and f.fy.only_mcx
    assert not any("shares and indices" in e for e in f.events)                        # they were never looked up on purpose
    assert items[-1].fyers == "MCX:GOLD26DECFUT" and all(not i.fyers for i in items[:-1])


def test_each_thread_keeps_its_own_connection_open_instead_of_starting_a_new_one_every_time(monkeypatch):
    made = []

    class Reply:
        status_code = 200

        def json(self):
            return {"s": "ok"}

    class FakeSession:
        def __init__(self):
            made.append(self)

        def get(self, url, params=None, headers=None, timeout=None):
            return Reply()

    monkeypatch.setattr(fyers.requests, "Session", FakeSession)
    http = fyers.RequestsHttp()
    http.get("https://x"), http.get("https://x")
    assert len(made) == 1
    t = threading.Thread(target=lambda: http.get("https://x"))
    t.start(), t.join()
    assert len(made) == 2                                                              # a session is not shared between threads


def test_when_the_older_chunk_of_day_candles_fails_the_newest_candles_are_kept(tmp_path):
    http = FakeFyers()
    http.series["MCX:GOLD26DECFUT"] = mcx_series()
    feed = logged_in(tmp_path, http, plan="standard")
    real, n = http.get, {"calls": 0}

    def flaky(url, params=None, headers=None, timeout=20):
        n["calls"] += 1
        if n["calls"] in (2, 3):                                                       # the older chunk, and its one retry
            return 200, {"s": "error", "code": -99, "message": "Something odd about the older dates"}
        return real(url, params, headers, timeout)

    http.get = flaky
    out, failed = feed.fetch({"MCX:GOLD1!": "MCX:GOLD26DECFUT"}, "1d", long_daily=True)
    assert failed == [] and len(out["MCX:GOLD1!"]) > 0 and "MCX:GOLD1!" not in feed.invalid and n["calls"] == 3
