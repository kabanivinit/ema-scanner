"""Fyers: login storage, pacing, symbol matching, candles, routing and the commands - all with a pretend Fyers."""
import json
from datetime import date, datetime, timedelta, timezone

import pandas as pd
import pytest
import requests

from scanner import cli, data, engine, fyers, report, telegram
from scanner.config import load_config
from scanner.fyers import (BudgetExhausted, Creds, FyersError, FyersFeed, Limiter, Master, Session, TokenStore,
                           parse_auth_code, resolve)
from scanner.markets import MARKETS
from scanner.universe import Instrument
from synth import intraday_raw, uptrend

NOW = datetime(2026, 11, 3, 10, 0, tzinfo=timezone.utc)            # 15:30 IST on a Tuesday
FRI = date(2026, 10, 30)


def creds(**kw):
    return Creds(**{"app_id": "ABCD1234-100", "secret": "S3CRET", "pin": "1234", **kw})


def candles_of(df):
    return [[int(t.timestamp()), r.Open, r.High, r.Low, r.Close, r.Volume] for t, r in df.iterrows()]


class FakeFyers:
    """Answers like the Fyers servers (as far as the scanner uses them)."""

    def __init__(self):
        self.posts, self.gets, self.refreshes = [], [], 0
        self.series = {}               # Fyers code -> candles
        self.stale = set()             # access tokens Fyers no longer accepts
        self.errors = {}               # Fyers code -> (status, body)
        self.refuse_refresh = False    # True = Fyers no longer accepts the saved login (e.g. older than 15 days)
        self.new_refresh_token = ""    # if set, Fyers also hands out this fresh refresh token when renewing
        self.rate_limit_after = None   # number of history calls after which Fyers says 429
        self.network_failures = 0
        self.masters = {}

    def post(self, url, payload=None, headers=None, timeout=20):
        self.posts.append((url, payload))
        if url.endswith("/validate-authcode"):
            if payload["code"] == "GOOD-CODE":
                return 200, {"s": "ok", "code": 200, "message": "", "access_token": "AT-LOGIN", "refresh_token": "RT-LOGIN"}
            return 200, {"s": "error", "code": -413, "message": "Invalid auth code"}
        if url.endswith("/validate-refresh-token"):
            self.refreshes += 1
            if self.refuse_refresh:
                return 400, {"s": "error", "code": -501, "message": "Please provide valid refresh token"}
            if payload["refresh_token"] not in ("RT", "RT-LOGIN", "RT2") or payload["pin"] != "1234":
                return 200, {"s": "error", "code": -501, "message": "Invalid refresh token or pin"}
            out = {"s": "ok", "code": 200, "access_token": f"AT{self.refreshes}"}
            if self.new_refresh_token:
                out["refresh_token"] = self.new_refresh_token
            return 200, out
        raise AssertionError(url)

    def get(self, url, params=None, headers=None, timeout=20):
        self.gets.append((params, headers))
        if self.network_failures:
            self.network_failures -= 1
            raise requests.ConnectionError("boom")
        if self.rate_limit_after is not None and len(self.gets) > self.rate_limit_after:
            return 429, {"s": "error", "code": -429, "message": "request limit reached"}
        token = headers["Authorization"].split(":", 1)[1]
        if token in self.stale:
            return 401, {"s": "error", "code": -16, "message": "Could not authenticate the user"}
        sym = params["symbol"]
        if sym in self.errors:
            return self.errors[sym]
        c = self.series.get(sym)
        if c is None:
            return 200, {"s": "error", "code": -300, "message": "Please provide a valid symbol"}
        return 200, {"s": "ok", "code": 200, "message": "", "candles": c}

    def text(self, url, timeout=60):
        name = url.rsplit("/", 1)[1][:-4]
        if name not in self.masters:
            raise requests.ConnectionError("no list")
        return self.masters[name]


class Clock:
    def __init__(self):
        self.t, self.slept = 1000.0, []

    def now(self):
        return self.t

    def sleep(self, s):
        self.slept.append(s)
        self.t += s


@pytest.fixture(autouse=True)
def quiet(monkeypatch, tmp_path):
    monkeypatch.setattr("time.sleep", lambda s: None)
    monkeypatch.setattr(fyers, "STATE_DIR", tmp_path / "state")


def logged_in(tmp_path, http, plan="prime", now=NOW, **limits):
    """A feed whose login is already saved (refresh token from 3 days ago, access token from this morning)."""
    c = creds()
    store = TokenStore(c, tmp_path / "tok.enc")
    store.save(refresh_token="RT", refresh_at=fyers._iso(now - timedelta(days=3)),
               access_token="AT1", access_at=fyers._iso(now - timedelta(hours=2)))
    cfg = load_config()["fyers"]
    lim = dict(cfg["limits"][plan], **limits)
    cfg["limits"] = {plan: lim}
    cfg["plan"] = plan
    session = Session(c, store, http, now=lambda: now)
    clk = Clock()                                       # a pretend clock that moves forward when the limiter "waits"
    limiter = Limiter(lim["per_second"], lim["per_minute"], lim["per_day"], clock=clk.now, sleep=clk.sleep)
    return FyersFeed(cfg, plan, c, session, http, limiter, now=lambda: now)


# ------------------------------------------------------------------------------------------ login
def test_login_link_hash_and_pasted_address():
    c = creds(redirect="https://example.com/cb")
    url = c.login_url()
    assert url.startswith("https://api-t1.fyers.in/api/v3/generate-authcode?client_id=ABCD1234-100&redirect_uri=https%3A%2F%2Fexample.com%2Fcb")
    assert "response_type=code" in url and "S3CRET" not in url                    # the link never carries the secret
    import hashlib
    assert c.app_hash == hashlib.sha256(b"ABCD1234-100:S3CRET").hexdigest()
    pasted = "https://trade.fyers.in/api-login/redirect-uri/index.html?s=ok&code=200&auth_code=eyJabc.def&state=ema_scanner"
    assert parse_auth_code(pasted) == "eyJabc.def"
    assert parse_auth_code("  eyJabc.def \n") == "eyJabc.def" and parse_auth_code("auth_code=XYZ&state=1") == "XYZ"


def test_secrets_are_read_from_the_environment_and_named_when_missing():
    assert Creds.from_env({"FYERS_APP_ID": "a", "FYERS_SECRET_ID": "b"}) is None
    assert fyers.missing_secrets({"FYERS_APP_ID": "a"}) == ["FYERS_SECRET_ID", "FYERS_PIN"]
    c = Creds.from_env({"FYERS_APP_ID": " a ", "FYERS_SECRET_ID": "b", "FYERS_PIN": "1234"})
    assert (c.app_id, c.redirect) == ("a", fyers.DEFAULT_REDIRECT) and fyers.configured({"FYERS_APP_ID": "a", "FYERS_SECRET_ID": "b", "FYERS_PIN": "1"})


def test_saved_login_is_encrypted_and_only_your_own_secrets_open_it(tmp_path):
    store = TokenStore(creds(), tmp_path / "t.enc")
    store.save(refresh_token="RT-VERY-SECRET", access_token="AT-X")
    raw = (tmp_path / "t.enc").read_bytes()
    assert b"RT-VERY-SECRET" not in raw and b"refresh" not in raw
    assert store.load()["refresh_token"] == "RT-VERY-SECRET"
    other = TokenStore(creds(pin="9999"), tmp_path / "t.enc")
    assert other.load() == {} and "log in again" in other.problem
    store.save(access_token="AT-Y")                                              # saving one field keeps the others
    assert store.load() == {"refresh_token": "RT-VERY-SECRET", "access_token": "AT-Y"}


def test_session_renews_from_the_saved_login_and_reuses_todays_token(tmp_path):
    http = FakeFyers()
    c, store = creds(), TokenStore(creds(), tmp_path / "t.enc")
    s = Session(c, store, http, now=lambda: NOW)
    assert not s.start() and "4 - Fyers Login" in s.problem                      # nothing saved yet
    store.save(refresh_token="RT", refresh_at=fyers._iso(NOW - timedelta(days=3)))
    assert s.start() and s.token == "AT1" and http.refreshes == 1
    url, body = http.posts[-1]
    assert url.endswith("/validate-refresh-token") and body["pin"] == "1234" and body["appIdHash"] == c.app_hash
    assert 11.9 < s.days_left < 12.1
    s2 = Session(c, store, http, now=lambda: NOW + timedelta(hours=1))           # same day: no second renewal
    assert s2.start() and s2.token == "AT1" and http.refreshes == 1
    s3 = Session(c, store, http, now=lambda: NOW + timedelta(days=1))            # next day: a fresh day-pass
    assert s3.start() and s3.token == "AT2" and http.refreshes == 2


def test_expired_or_refused_login_is_explained(tmp_path):
    http = FakeFyers()
    store = TokenStore(creds(), tmp_path / "t.enc")
    store.save(refresh_token="RT", refresh_at=fyers._iso(NOW - timedelta(days=16)))
    s = Session(creds(), store, http, now=lambda: NOW)
    assert s.start() and http.refreshes == 1 and s.days_left < 0                 # past 15 days: still tried - Fyers decides
    http.refuse_refresh = True
    s = Session(creds(), store, http, now=lambda: NOW + timedelta(days=1))       # a new day needs a renewal, Fyers now says no
    assert not s.start() and "expired" in s.problem and "Please provide valid refresh token" in s.problem
    assert "4 - Fyers Login" in s.problem
    http.refuse_refresh = False
    store.save(refresh_token="WRONG", refresh_at=fyers._iso(NOW - timedelta(days=1)))
    s = Session(creds(), store, http, now=lambda: NOW + timedelta(days=2))
    assert not s.start() and "refused the saved login" in s.problem and "Invalid refresh token" in s.problem


def test_a_fresh_refresh_token_from_fyers_restarts_the_15_day_count(tmp_path):
    http = FakeFyers()
    http.new_refresh_token = "RT2"
    store = TokenStore(creds(), tmp_path / "t.enc")
    store.save(refresh_token="RT", refresh_at=fyers._iso(NOW - timedelta(days=14)))
    s = Session(creds(), store, http, now=lambda: NOW)
    assert s.start() and s.days_left == fyers.REFRESH_DAYS
    saved = store.load()
    assert saved["refresh_token"] == "RT2" and fyers._parse_iso(saved["refresh_at"]) == NOW


# ------------------------------------------------------------------------------------------ pacing
def test_limiter_keeps_below_the_per_second_and_per_minute_limits_and_the_daily_allowance():
    c = Clock()
    lim = Limiter(per_second=2, per_minute=100, per_day=100, clock=c.now, sleep=c.sleep)
    for _ in range(3):
        lim.acquire()
    assert len(c.slept) == 1 and 1.0 <= c.slept[0] < 1.1                          # the 3rd call waited out the second
    c = Clock()
    lim = Limiter(per_second=100, per_minute=3, per_day=100, clock=c.now, sleep=c.sleep)
    for _ in range(4):
        lim.acquire()
    assert 59.9 < sum(c.slept) < 61                                               # the 4th waited for the minute to pass
    c = Clock()
    lim = Limiter(per_second=100, per_minute=100, per_day=2, clock=c.now, sleep=c.sleep)
    lim.acquire(), lim.acquire()
    with pytest.raises(BudgetExhausted):
        lim.acquire()


def test_the_free_plan_paces_below_fyers_limits_and_leaves_15_minute_candles_to_tradingview():
    cfg = load_config()["fyers"]
    std, prime = cfg["limits"]["standard"], cfg["limits"]["prime"]
    assert std["per_minute"] < 50 and std["per_second"] < 5 and std["per_day"] < 5000     # Fyers: 50/min, 5/s, 5,000/day
    assert prime["per_minute"] < 500 and prime["per_second"] < 10 and prime["per_day"] < 500000
    assert std["skip_intervals"] == ["15m"] and prime["skip_intervals"] == []


# ------------------------------------------------------------------------------------------ symbol matching
def nse_row(n, ticker, desc="X"):
    return [f"10100000{n:07d}", desc, "0", "1", "0.05", "INE", "0915-1530", "2026-11-02", "0", ticker, "10", "10", str(n)]


def mcx_row(n, ticker):
    return [f"11200000{n:07d}", ticker.split(":")[1], "11", "1", "1", "", "0900-2330", "2026-11-02", "1796000000", ticker, "11", "20", str(n)]


def csv_text(rows):
    import csv, io
    buf = io.StringIO()
    csv.writer(buf).writerows(rows)
    return buf.getvalue()


def lists():
    http = FakeFyers()
    http.masters["NSE_CM"] = csv_text(
        [nse_row(i, f"NSE:S{i}-EQ") for i in range(10)]
        + [nse_row(20, "NSE:RELIANCE-EQ", "RELIANCE INDUSTRIES LTD"), nse_row(21, "NSE:M&M-EQ"), nse_row(22, "NSE:GOVT-BE"),
           nse_row(30, "NSE:NIFTY50-INDEX", "Nifty 50"), nse_row(31, "NSE:FINNIFTY-INDEX", "Nifty Fin Service"),
           nse_row(32, "NSE:NIFTYFOO-INDEX", "Nifty Foo"), nse_row(33, "NSE:NIFTYSERVSECTOR-INDEX", "Nifty Serv Sector")])
    http.masters["BSE_CM"] = csv_text([nse_row(i, f"BSE:B{i}-A") for i in range(8)] + [nse_row(40, "BSE:SENSEX-INDEX", "Sensex")])
    http.masters["MCX_COM"] = csv_text(
        [mcx_row(i, t) for i, t in enumerate(["MCX:GOLD26DECFUT", "MCX:GOLD27FEBFUT", "MCX:GOLDM26DECFUT", "MCX:CRUDEOIL26NOVFUT",
                                              "MCX:CRUDEOIL26DECFUT", "MCX:SILVER26DECFUT", "MCX:SILVER27MARFUT"])])
    return http


def insts():
    mk = lambda sym, name, market="NSE", hint=(): Instrument(sym, name, market, fyers_hint=list(hint))
    return [mk("RELIANCE.NS", "Reliance Industries Ltd."), mk("M&M.NS", "Mahindra & Mahindra Ltd."), mk("GOVT.NS", "Gov Ltd"),
            mk("NOPE.NS", "Not Listed Ltd"), mk("^NSEI", "Nifty 50"), mk("^CNXFIN", "Nifty Financial Services"),
            mk("^CNXSERVICE", "Nifty Services Sector"), mk("NSE:CNXFOO", "Nifty Foo"), mk("^BSESN", "Sensex"),
            mk("MCX:GOLD1!", "Gold", "MCX"), mk("MCX:CRUDEOIL1!", "Crude Oil", "MCX"), mk("MCX:SILVER1!", "Silver", "MCX"),
            mk("MCX:GOLDM1!", "Gold Mini", "MCX"), mk("MCX:LEAD1!", "Lead", "MCX")]


def test_our_symbols_are_matched_to_fyers_codes(tmp_path):
    http, items = lists(), insts()
    master = Master(load_config()["fyers"], http, now=lambda: NOW, folder=tmp_path / "m")
    rep = resolve(items, load_config()["fyers"], master, today=date(2026, 11, 3))
    got = {i.symbol: i.fyers for i in items}
    assert got["RELIANCE.NS"] == "NSE:RELIANCE-EQ" and got["M&M.NS"] == "NSE:M&M-EQ"
    assert got["GOVT.NS"] == "NSE:GOVT-BE"                                       # not an EQ-series share: next series is tried
    assert got["NOPE.NS"] == ""                                                  # not on Fyers -> TradingView
    assert got["^NSEI"] == "NSE:NIFTY50-INDEX" and got["^CNXFIN"] == "NSE:FINNIFTY-INDEX"       # second code of the list
    assert got["^CNXSERVICE"] == "NSE:NIFTYSERVSECTOR-INDEX" and got["^BSESN"] == "BSE:SENSEX-INDEX"
    assert got["NSE:CNXFOO"] == "NSE:NIFTYFOO-INDEX"                             # found by name
    assert got["MCX:GOLD1!"] == "MCX:GOLD26DECFUT" and got["MCX:GOLDM1!"] == "MCX:GOLDM26DECFUT"    # nearest contract, root matched exactly
    assert got["MCX:CRUDEOIL1!"] == "MCX:CRUDEOIL26NOVFUT" and got["MCX:SILVER1!"] == "MCX:SILVER26DECFUT"
    assert got["MCX:LEAD1!"] == ""
    assert rep["missing"] == ["Not Listed Ltd", "Lead"] and rep["mapped"] == 12 and len(rep["notes"]) == 3


def test_mcx_rolls_to_next_month_near_the_end_of_the_month(tmp_path):
    http = lists()
    for today, want in [(date(2026, 11, 3), "MCX:CRUDEOIL26NOVFUT"), (date(2026, 11, 28), "MCX:CRUDEOIL26DECFUT")]:
        item = [Instrument("MCX:CRUDEOIL1!", "Crude Oil", "MCX")]
        resolve(item, load_config()["fyers"], Master(load_config()["fyers"], http, now=lambda: NOW, folder=tmp_path / "m2"), today=today)
        assert item[0].fyers == want


def test_without_the_symbol_lists_stocks_still_use_the_obvious_code_and_a_saved_copy_is_reused(tmp_path):
    http = FakeFyers()                                                           # downloads all fail
    item = [Instrument("RELIANCE.NS", "Reliance", "NSE"), Instrument("MCX:GOLD1!", "Gold", "MCX")]
    rep = resolve(item, load_config()["fyers"], Master(load_config()["fyers"], http, now=lambda: NOW, folder=tmp_path / "m"),
                  today=date(2026, 11, 3))
    assert item[0].fyers == "NSE:RELIANCE-EQ" and "download failed" in " ".join(rep["notes"])
    assert item[1].fyers == "MCX:GOLD26NOVFUT" and item[1].fyers_alts[0] == "MCX:GOLD26DECFUT" and rep["guessed"] == ["Gold"]
    http2 = lists()
    m = Master(load_config()["fyers"], http2, now=lambda: NOW, folder=tmp_path / "m3")
    assert m.tickers("NSE_CM")["NSE:RELIANCE-EQ"] == "RELIANCE INDUSTRIES LTD"
    m_again = Master(load_config()["fyers"], FakeFyers(), now=lambda: NOW, folder=tmp_path / "m3")        # no network now
    assert "NSE:RELIANCE-EQ" in m_again.tickers("NSE_CM") and "saved copy" in m_again.notes["NSE_CM"]


# ------------------------------------------------------------------------------------------ candles
def nse_series(n_days=3, minutes=15):
    return candles_of(intraday_raw("NSE", minutes, FRI, n_days, lambda n: uptrend(n)))


def test_candles_come_back_as_utc_frames_with_the_right_request(tmp_path):
    http = FakeFyers()
    http.series["NSE:RELIANCE-EQ"] = nse_series()
    feed = logged_in(tmp_path, http)
    out, failed = feed.fetch({"RELIANCE.NS": "NSE:RELIANCE-EQ"}, "15m")
    df = out["RELIANCE.NS"]
    assert failed == [] and len(df) == 75 and str(df.index.tz) == "UTC" and df.index.is_monotonic_increasing
    params, headers = http.gets[0]
    assert params["symbol"] == "NSE:RELIANCE-EQ" and params["resolution"] == "15" and params["date_format"] == "0"
    assert params["cont_flag"] == "1" and int(params["range_to"]) - int(params["range_from"]) == 30 * 86400
    assert headers["Authorization"] == "ABCD1234-100:AT1"
    assert feed.calls == 1 and feed.limiter.used == 1
    assert feed.covers("15m") and feed.covers("1h") and not feed.covers("1w")


def test_weekly_candles_get_two_years_of_daily_candles_in_two_requests(tmp_path):
    http = FakeFyers()
    http.series["NSE:RELIANCE-EQ"] = nse_series()
    feed = logged_in(tmp_path, http)
    feed.fetch({"R": "NSE:RELIANCE-EQ"}, "1d")
    assert len(http.gets) == 1
    http.gets.clear()
    out, _ = feed.fetch({"R": "NSE:RELIANCE-EQ"}, "1d", long_daily=True)
    assert len(http.gets) == 2
    (p1, _), (p2, _) = http.gets
    assert int(p1["range_from"]) > int(p2["range_to"]) and int(p2["range_to"]) - int(p2["range_from"]) == 360 * 86400
    assert len(out["R"]) == 75                                                    # identical candles in both chunks are merged


def test_unknown_symbols_are_reported_and_do_not_stop_the_others(tmp_path):
    http = FakeFyers()
    http.series["NSE:A-EQ"] = nse_series()
    feed = logged_in(tmp_path, http)
    out, failed = feed.fetch({"A": "NSE:A-EQ", "B": "NSE:NOPE-EQ"}, "1h")
    assert list(out) == ["A"] and failed == ["B"] and feed.invalid == {"B"} and "valid symbol" in feed.reasons["B"]
    assert not feed.down


def test_a_login_that_stopped_working_is_renewed_once_for_all_workers(tmp_path):
    http = FakeFyers()
    for k in range(6):
        http.series[f"NSE:S{k}-EQ"] = nse_series()
    feed = logged_in(tmp_path, http)
    feed.session.store.save(access_token="AT-OLD")
    http.stale.add("AT-OLD")                                                     # Fyers dropped this morning's token
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(6)}, "1h")
    assert len(out) == 6 and failed == [] and http.refreshes == 1               # one renewal, shared by all four workers
    used = [h["Authorization"].split(":")[1] for _, h in http.gets]
    assert used[0] == "AT-OLD" and used[-1] == "AT1" and feed.session.store.load()["access_token"] == "AT1"


def test_a_login_fyers_refuses_stops_the_run_and_says_what_to_do(tmp_path):
    http = FakeFyers()
    http.series["NSE:S-EQ"] = nse_series()
    http.stale.add("AT1")
    feed = logged_in(tmp_path, http)
    feed.session.store.save(refresh_token="REVOKED")                             # access token stale AND the saved login revoked
    out, failed = feed.fetch({"S": "NSE:S-EQ"}, "1h")
    assert out == {} and failed == ["S"] and "4 - Fyers Login" in feed.down
    assert any("login problem" in e for e in feed.events) and not feed.covers("1h")


def test_going_too_fast_stops_requests_immediately(tmp_path):
    http = FakeFyers()
    for k in range(30):
        http.series[f"NSE:S{k}-EQ"] = nse_series()
    http.rate_limit_after = 3
    feed = logged_in(tmp_path, http)
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(30)}, "1h")
    assert len(out) == 3 and len(failed) == 27 and "too fast" in feed.down
    assert len(http.gets) <= 3 + 4 + 1                                           # in-flight requests only: no hammering
    assert any("TradingView" in e for e in feed.events)


def test_the_daily_allowance_is_never_exceeded(tmp_path):
    http = FakeFyers()
    for k in range(10):
        http.series[f"NSE:S{k}-EQ"] = nse_series()
    feed = logged_in(tmp_path, http, per_day=4)
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(10)}, "1h")
    assert len(out) == 4 and len(failed) == 6 and len(http.gets) == 4 and "allowance is used up" in feed.down
    state = {}
    feed.save_state(state)
    assert state["fyers"] == {"day": "2026-11-03", "calls": 4}
    feed.limiter.used = 0
    feed.attach_state(state)
    assert feed.limiter.used == 4                                                # tomorrow's runs know what today's used ...
    state["fyers"]["day"] = "2026-11-02"
    feed.attach_state(state)
    assert feed.limiter.used == 0                                                # ... and a new day starts from zero


def test_a_network_hiccup_is_retried(tmp_path):
    http = FakeFyers()
    http.series["NSE:A-EQ"] = nse_series()
    http.network_failures = 1
    feed = logged_in(tmp_path, http)
    out, failed = feed.fetch({"A": "NSE:A-EQ"}, "1h")
    assert "A" in out and failed == []
    http.network_failures = 5
    out, failed = feed.fetch({"A": "NSE:A-EQ"}, "1h")
    assert failed == ["A"] and "network" in feed.reasons["A"]


def test_warns_two_days_before_the_login_runs_out(tmp_path):
    http = FakeFyers()
    http.series["NSE:A-EQ"] = nse_series()
    feed = logged_in(tmp_path, http)
    feed.session.store.save(refresh_at=fyers._iso(NOW - timedelta(days=13.5)))
    feed.fetch({"A": "NSE:A-EQ"}, "1h")
    assert any("Fyers login ends in about 2 day" in e for e in feed.events)


# ------------------------------------------------------------------------------------------ routing into the scanner
class StubTV:
    down, invalid = "", set()

    def __init__(self, frames):
        self.frames, self.asked = frames, []

    def fetch(self, symbols, interval):
        self.asked.append((tuple(symbols), interval))
        got = {s: self.frames[s] for s in symbols if s in self.frames}
        return got, [s for s in symbols if s not in got]


def routed(tmp_path, plan="prime"):
    http = FakeFyers()
    http.series["NSE:A-EQ"] = nse_series()
    items = [Instrument("A.NS", "A", "NSE", fyers="NSE:A-EQ"), Instrument("B.NS", "B", "NSE", fyers="NSE:B-EQ"),
             Instrument("MSFT", "Microsoft", "US")]
    raw = intraday_raw("NSE", 15, FRI, 3, lambda n: uptrend(n))
    tv = StubTV({"A.NS": raw, "B.NS": raw, "MSFT": raw})
    cfg = dict(load_config(), data_source="tradingview")
    feed = logged_in(tmp_path, http, plan=plan)
    return data.Fetcher(cfg, items, tv=tv, fyers=feed), tv, http, feed


def test_indian_symbols_use_fyers_everything_else_and_misses_use_tradingview(tmp_path):
    f, tv, http, feed = routed(tmp_path)
    out, failed = f(["A.NS", "B.NS", "MSFT"], "1h")
    assert sorted(out) == ["A.NS", "B.NS", "MSFT"] and failed == []
    assert [f.source_of(s, "1h") for s in ("A.NS", "B.NS", "MSFT")] == ["fyers", "tradingview", "tradingview"]
    assert tv.asked == [(("B.NS", "MSFT"), "1h")]                                # TradingView was asked only for what Fyers did not give
    assert f.served == {"tradingview": 2, "yahoo": 0, "fyers": 1}
    assert f.primary_source("NSE", "1h") == "fyers" and f.primary_source("US", "1h") == "tradingview"


def test_the_free_plan_sends_15_minute_candles_of_indian_markets_to_tradingview(tmp_path):
    f, tv, http, feed = routed(tmp_path, plan="standard")
    assert f.primary_source("NSE", "15m") == "tradingview" and f.primary_source("NSE", "1h") == "fyers"
    out, _ = f(["A.NS"], "15m")
    assert http.gets == [] and f.source_of("A.NS", "15m") == "tradingview" and tv.asked == [(("A.NS",), "15m")]


def test_when_fyers_breaks_the_scan_carries_on_with_delayed_data_and_says_so(tmp_path):
    f, tv, http, feed = routed(tmp_path)
    http.stale.add("AT1")
    feed.session.store.save(refresh_token="REVOKED")
    out, failed = f(["A.NS", "B.NS"], "1h")
    assert sorted(out) == ["A.NS", "B.NS"] and f.source_of("A.NS", "1h") == "tradingview"
    assert any("Fyers is not usable" in e for e in f.events) and f.primary_source("NSE", "1h") == "tradingview"


def test_a_delayed_feed_is_given_time_to_finish_its_latest_candle():
    cfg = load_config()
    raw = intraday_raw("NSE", 15, FRI, 30, lambda n: uptrend(n))
    from scanner import bars
    last = bars.intraday_bars(raw, MARKETS["NSE"], 15)["end"].iloc[-1]
    now = last + pd.Timedelta(minutes=3)
    real, _ = engine.evaluate(raw, "NSE", "15m", cfg, now, source="fyers")
    slow, _ = engine.evaluate(raw, "NSE", "15m", cfg, now, source="tradingview")
    assert real["last_end"] == last and slow["last_end"] < last                   # TradingView's copy may still be mid-candle


def test_a_late_run_looks_further_back_but_never_beyond_the_alert_age_limit():
    cfg = load_config()
    exp = pd.Timestamp("2026-11-03 10:00", tz="UTC")
    prev = lambda minutes: (exp - pd.Timedelta(minutes=minutes)).isoformat()
    assert engine.window_for(cfg, "15m", None, exp) == 3 and engine.window_for(cfg, "15m", prev(15), exp) == 3
    assert engine.window_for(cfg, "15m", prev(45), exp) == 4                      # 3 candles missed + the newest
    assert engine.window_for(cfg, "15m", prev(90), exp) == 6                      # capped: 75 minutes of 15-minute candles + 1
    assert engine.window_for(cfg, "15m", prev(60 * 48), exp) == 6
    assert engine.window_for(cfg, "1d", prev(60 * 24 * 3), exp) == 4


# ------------------------------------------------------------------------------------------ commands
@pytest.fixture
def chat(monkeypatch, tmp_path):
    sent = {"messages": []}

    class R:
        status_code = 200

        def __init__(self, body):
            self._b = body

        def json(self):
            return self._b

    def fake_post(url, json=None, data=None, files=None, timeout=None):
        if url.endswith("sendMessage"):
            sent["messages"].append(json["text"])
        return R({"ok": True, "result": {"username": "bot"}})

    monkeypatch.setattr(telegram.requests, "post", fake_post)
    for k, v in {"TELEGRAM_BOT_TOKEN": "1:T", "TELEGRAM_CHAT_ID": "2", "FYERS_APP_ID": "ABCD1234-100",
                 "FYERS_SECRET_ID": "S3CRET", "FYERS_PIN": "1234"}.items():
        monkeypatch.setenv(k, v)
    monkeypatch.delenv("FYERS_REDIRECT_URI", raising=False)
    monkeypatch.delenv("FYERS_LOGIN_URL", raising=False)
    http = lists()
    for sym in ("NSE:NIFTY50-INDEX", "NSE:RELIANCE-EQ", "MCX:GOLD26DECFUT"):
        http.series[sym] = nse_series()
    monkeypatch.setattr(fyers, "RequestsHttp", lambda: http)
    monkeypatch.setattr(cli, "load_config", lambda path=None: load_config())
    return sent, http


def test_login_command_without_an_address_sends_the_login_link(chat, monkeypatch):
    sent, http = chat
    assert cli.main(["fyers-login"]) == 0
    msg = sent["messages"][-1]
    assert "Fyers login" in msg and "generate-authcode?client_id=ABCD1234-100" in msg and "S3CRET" not in msg
    assert "4 - Fyers Login" in msg
    sent["messages"].clear()
    monkeypatch.setenv("FYERS_LOGIN_URL", "https://x/?s=ok&auth_code=GOOD-CODE")     # how the workflow passes the pasted address
    assert cli.main(["fyers-login"]) == 0 and "Fyers login saved" in sent["messages"][-1]


def test_login_command_saves_the_login_proves_it_works_and_tells_you_when_it_ends(chat, tmp_path):
    sent, http = chat
    pasted = "https://trade.fyers.in/api-login/redirect-uri/index.html?s=ok&code=200&auth_code=GOOD-CODE&state=ema_scanner"
    assert cli.main(["fyers-login", "--url", pasted]) == 0
    assert "Fyers login saved" in sent["messages"][-1] and "15 days" in sent["messages"][-1]
    saved = TokenStore(creds()).load()
    assert saved["refresh_token"] == "RT-LOGIN" and saved["access_token"] == "AT-LOGIN"
    assert not any("RT-LOGIN" in m or "AT-LOGIN" in m for m in sent["messages"])      # tokens never go to Telegram
    assert "NSE:NIFTY50-INDEX" in [p["symbol"] for p, _ in http.gets]


def test_login_command_explains_a_rejected_address(chat):
    sent, http = chat
    assert cli.main(["fyers-login", "--url", "https://x/?auth_code=BAD"]) == 1
    assert "Fyers login failed" in sent["messages"][-1] and "Invalid auth code" in sent["messages"][-1]
    assert not TokenStore(creds()).load()


def test_login_command_needs_the_secrets(chat, monkeypatch):
    monkeypatch.delenv("FYERS_PIN")
    assert cli.main(["fyers-login", "--url", "x"]) == 2


def test_check_setup_reports_login_codes_candles_and_budget(chat):
    sent, http = chat
    cli.main(["fyers-login", "--url", "auth_code=GOOD-CODE"])
    cfg = load_config()
    items = [Instrument("RELIANCE.NS", "Reliance", "NSE"), Instrument("^NSEI", "Nifty 50", "NSE"),
             Instrument("MCX:GOLD1!", "Gold", "MCX"), Instrument("NOPE.NS", "Not Listed", "NSE")]
    lines = []
    feed = cli._check_fyers(cfg, items, pd.Timestamp("2026-11-03 10:00", tz="UTC"), lambda lvl, msg: lines.append(f"[{lvl}] {msg}"))
    text = "\n".join(lines)
    assert feed is not None and "[PASS] Fyers login works" in text
    assert "Fyers codes found for 3 of 4 Indian symbols" in text and "not found: Not Listed" in text
    assert "MCX contracts in use: Gold → GOLD26DECFUT" in text
    assert "[PASS] Fyers Nifty 50 (NSE:NIFTY50-INDEX) 1h: 75 candles" in text and "[PASS] Fyers Gold (MCX:GOLD26DECFUT) 1d" in text
    assert "Fyers requests needed per trading day" in text and "15m candles are NOT counted" in text


def test_check_setup_without_a_login_sends_the_link_to_telegram_not_to_the_public_log(chat):
    sent, http = chat
    lines = []
    tg = telegram.Telegram.from_env()
    cli._check_fyers(load_config(), [Instrument("^NSEI", "Nifty 50", "NSE")], pd.Timestamp("2026-11-03 10:00", tz="UTC"),
                     lambda lvl, msg: lines.append(f"[{lvl}] {msg}"), tg)
    text = "\n".join(lines)
    assert "[FAIL] Fyers login: no Fyers login saved yet" in text and "4 - Fyers Login" in text
    assert "ABCD1234-100" not in text and "generate-authcode" not in text           # nothing about the app in a public log
    assert "generate-authcode?client_id=ABCD1234-100" in sent["messages"][-1]       # it goes to your private Telegram chat


def test_without_the_secrets_check_setup_says_how_to_switch_fyers_on(monkeypatch):
    for k in ("FYERS_APP_ID", "FYERS_SECRET_ID", "FYERS_PIN"):
        monkeypatch.delenv(k, raising=False)
    lines = []
    assert cli._check_fyers(load_config(), [Instrument("^NSEI", "Nifty 50", "NSE")], pd.Timestamp("2026-11-03 10:00", tz="UTC"),
                            lambda lvl, msg: lines.append(msg)) is None
    assert "FYERS_APP_ID, FYERS_SECRET_ID, FYERS_PIN" in lines[0]


def test_reports_and_backtests_do_not_spend_the_free_plans_requests(chat):
    items = [Instrument("RELIANCE.NS", "Reliance", "NSE")]
    cfg = load_config()
    assert data.make_fetcher(cfg, items, purpose="backtest").fy is None
    assert data.make_fetcher(cfg, items, purpose="report").fy is None                  # standard plan: TradingView is fine after the close
    assert data.make_fetcher(cfg, items, purpose="scan").fy is not None
    cfg["fyers"]["plan"] = "prime"
    assert data.make_fetcher(cfg, items, purpose="report").fy is not None


def test_a_broken_fyers_setup_never_stops_the_scanner(chat, monkeypatch):
    monkeypatch.setattr(fyers, "setup", lambda *a, **k: (_ for _ in ()).throw(RuntimeError("boom")))
    f = data.make_fetcher(load_config(), [Instrument("RELIANCE.NS", "Reliance", "NSE")])
    assert f.fy is None and any("Fyers could not be set up" in e for e in f.events)


# ------------------------------------------------------------------------------------------ daily budget details
def test_the_free_plan_keeps_part_of_the_day_for_mcx_which_has_no_other_source():
    c = Clock()
    lim = Limiter(per_second=100, per_minute=1000, per_day=10, clock=c.now, sleep=c.sleep)
    for _ in range(7):
        lim.acquire(reserve=3)                                                   # NSE-type requests: 7 allowed (10 - 3 kept back)
    with pytest.raises(fyers.BudgetReserved):
        lim.acquire(reserve=3)
    for _ in range(3):
        lim.acquire()                                                            # MCX may still use what was kept back
    with pytest.raises(BudgetExhausted) as e:
        lim.acquire()
    assert not isinstance(e.value, fyers.BudgetReserved)
    std = load_config()["fyers"]["limits"]["standard"]
    assert std["reserve_mcx"] >= 300 and load_config()["fyers"]["limits"]["prime"]["reserve_mcx"] == 0


def test_when_the_nse_share_is_used_up_mcx_still_gets_candles_and_the_run_is_not_halted(tmp_path):
    http = FakeFyers()
    for k in range(5):
        http.series[f"NSE:S{k}-EQ"] = nse_series()
    for k in range(3):
        http.series[f"MCX:G{k}FUT"] = nse_series()
    feed = logged_in(tmp_path, http, plan="standard", per_day=6, reserve_mcx=3)
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(5)}, "1h")
    assert len(out) == 3 and len(failed) == 2 and not feed.down                  # only 3 of 6 requests were open to NSE
    assert "kept for MCX" in feed.reasons[failed[0]]
    out2, failed2 = feed.fetch({f"G{k}": f"MCX:G{k}FUT" for k in range(3)}, "1h")
    assert len(out2) == 3 and failed2 == [] and not feed.down


def test_a_run_never_spends_more_than_its_time_allowance_on_fyers(tmp_path):
    http = FakeFyers()
    for k in range(8):
        http.series[f"NSE:S{k}-EQ"] = nse_series()
    feed = logged_in(tmp_path, http, plan="prime")
    feed.fcfg = dict(feed.fcfg, max_seconds=100, workers=1)
    ticks = iter([0.0, 10.0, 20.0, 30.0, 500.0] + [500.0] * 50)                    # the 4th request finds the allowance gone
    feed.clock = lambda: next(ticks)
    out, failed = feed.fetch({f"S{k}": f"NSE:S{k}-EQ" for k in range(8)}, "1h")
    assert 0 < len(out) < 8 and len(out) + len(failed) == 8
    assert "time allowance" in feed.down and any("TradingView" in e for e in feed.events)


# ------------------------------------------------------------------------------------------ fast markets are not held up
def test_slow_indian_rounds_on_the_free_plan_never_hold_back_crypto_and_us_alerts(tmp_path):
    cfg = load_config()
    items = [Instrument("BTC-USD", "Bitcoin", "CRYPTO"), Instrument("MSFT", "Microsoft", "US"),
             Instrument("RELIANCE.NS", "Reliance", "NSE"), Instrument("MCX:GOLD1!", "Gold", "MCX")]

    class F:                                                                     # a fetcher that looks like the real one
        def __init__(self, plan):
            self.fy = type("Fy", (), {"plan": plan})() if plan else None

    assert [sorted(g) for g in cli._market_groups(items, F("standard"))] == [["CRYPTO", "US"], ["MCX", "NSE"]]
    assert [sorted(g) for g in cli._market_groups(items, F("prime"))] == [["CRYPTO", "MCX", "NSE", "US"]]
    assert [sorted(g) for g in cli._market_groups(items, F(None))] == [["CRYPTO", "MCX", "NSE", "US"]]
    only_indian = [i for i in items if i.market in ("NSE", "MCX")]
    assert [sorted(g) for g in cli._market_groups(only_indian, F("standard"))] == [["MCX", "NSE"]]


# ------------------------------------------------------------------------------------------ commodities on the free plan
ENV = {"FYERS_APP_ID": "ABCD1234-100", "FYERS_SECRET_ID": "S3CRET", "FYERS_PIN": "1234"}


def mcx_and_nse():
    m = Instrument("MCX:GOLD1!", "Gold", "MCX", tfs={"15m", "1h", "4h", "1d", "1w"})
    n = Instrument("RELIANCE.NS", "Reliance", "NSE", tfs={"15m", "1h", "4h", "1d", "1w"})
    return [m, n]


def test_commodities_lose_15_minute_candles_on_the_free_plan_because_no_other_source_has_mcx(tmp_path):
    cfg, items = load_config(), mcx_and_nse()
    feed = fyers.setup(cfg, items, "scan", http=lists(), env=ENV, now=lambda: NOW)
    assert feed is not None and items[0].fyers == "MCX:GOLD26DECFUT"
    assert items[0].tfs == {"1h", "4h", "1d", "1w"}                                # no 15 Min for Gold ...
    assert items[1].tfs == {"15m", "1h", "4h", "1d", "1w"}                         # ... Reliance keeps it (TradingView, delayed)


def test_the_paid_plan_keeps_every_timeframe_for_commodities():
    cfg, items = load_config(), mcx_and_nse()
    cfg["fyers"]["plan"] = "prime"
    fyers.setup(cfg, items, "scan", http=lists(), env=ENV, now=lambda: NOW)
    assert items[0].tfs == {"15m", "1h", "4h", "1d", "1w"}


def test_the_daily_report_on_the_free_plan_asks_fyers_for_commodities_only():
    cfg, items = load_config(), mcx_and_nse()
    feed = fyers.setup(cfg, items, "report", http=lists(), env=ENV, now=lambda: NOW)
    assert feed is not None and items[0].fyers == "MCX:GOLD26DECFUT" and items[1].fyers == ""
    assert fyers.setup(cfg, [items[1]], "report", http=lists(), env=ENV, now=lambda: NOW) is None      # nothing for Fyers to do
    cfg["fyers"]["plan"] = "prime"
    items2 = mcx_and_nse()
    fyers.setup(cfg, items2, "report", http=lists(), env=ENV, now=lambda: NOW)
    assert items2[1].fyers == "NSE:RELIANCE-EQ"                                    # the paid plan has room for everything


def test_the_backtest_keeps_the_global_stand_ins_because_real_mcx_history_needs_fyers(monkeypatch):
    from scanner import universe
    for k, v in ENV.items():
        monkeypatch.setenv(k, v)
    cfg = load_config()
    only = ("commodities", "commodities_global")
    live, notes = universe.build(cfg, only)
    assert {i.market for i in live} == {"MCX"} and "skipped" not in notes.get("commodities", "")
    test, notes = universe.build(cfg, only, purpose="backtest")
    assert {i.market for i in test} == {"FUT"} and "skipped" in notes["commodities"]


def test_the_plan_can_be_set_with_a_github_secret_without_editing_any_file(monkeypatch):
    from scanner.config import ConfigError
    assert load_config()["fyers"]["plan"] == "standard"
    monkeypatch.setenv("FYERS_PLAN", " Prime ")
    assert load_config()["fyers"]["plan"] == "prime"
    monkeypatch.setenv("FYERS_PLAN", "")                                           # an unset GitHub secret arrives as an empty text
    assert load_config()["fyers"]["plan"] == "standard"
    monkeypatch.setenv("FYERS_PLAN", "gold")
    with pytest.raises(ConfigError, match="FYERS_PLAN"):
        load_config()


# ------------------------------------------------------------------------------------------ commodity contracts that cannot be looked up
def mcx_series(last_day=FRI):
    return candles_of(intraday_raw("MCX", 60, last_day, 3, lambda n: uptrend(n)))


def mcx_feed(tmp_path, series, alts, plan="standard"):
    http = FakeFyers()
    http.series.update(series)
    feed = logged_in(tmp_path, http, plan=plan)
    feed.alts = {"MCX:GOLD1!": alts}
    return feed, http


def test_a_guessed_month_that_does_not_exist_is_skipped_and_the_working_contract_is_remembered(tmp_path):
    feed, http = mcx_feed(tmp_path, {"MCX:GOLD26DECFUT": mcx_series()}, ["MCX:GOLD26DECFUT", "MCX:GOLD27JAN" "FUT"])
    out, failed = feed.fetch({"MCX:GOLD1!": "MCX:GOLD26NOVFUT"}, "1h")                 # November: Gold has no such contract
    assert list(out) == ["MCX:GOLD1!"] and failed == [] and feed.picked == {"MCX:GOLD1!": "MCX:GOLD26DECFUT"}
    assert [g[0]["symbol"] for g in http.gets] == ["MCX:GOLD26NOVFUT", "MCX:GOLD26DECFUT"]
    assert "MCX:GOLD1!" not in feed.invalid and "using MCX:GOLD26DECFUT" in feed.switched[0]
    http.gets.clear()
    feed.fetch({"MCX:GOLD1!": "MCX:GOLD26NOVFUT"}, "1d")                                # later requests go straight to the right code
    assert [g[0]["symbol"] for g in http.gets] == ["MCX:GOLD26DECFUT"]


def test_a_contract_that_has_expired_is_not_used_even_though_it_still_answers(tmp_path):
    old = mcx_series(date(2026, 10, 9))                                                 # last candle three weeks ago
    feed, http = mcx_feed(tmp_path, {"MCX:GOLD26OCTFUT": old, "MCX:GOLD26DECFUT": mcx_series()}, ["MCX:GOLD26DECFUT"])
    out, failed = feed.fetch({"MCX:GOLD1!": "MCX:GOLD26OCTFUT"}, "1h")
    assert failed == [] and feed.picked["MCX:GOLD1!"] == "MCX:GOLD26DECFUT" and len(out["MCX:GOLD1!"]) > 0


def test_when_no_contract_works_the_symbol_fails_cleanly_and_other_commodities_carry_on(tmp_path):
    feed, http = mcx_feed(tmp_path, {"MCX:SILVER26DECFUT": mcx_series()}, ["MCX:GOLD26DECFUT"])
    out, failed = feed.fetch({"MCX:GOLD1!": "MCX:GOLD26NOVFUT", "MCX:SILVER1!": "MCX:SILVER26DECFUT"}, "1h")
    assert list(out) == ["MCX:SILVER1!"] and failed == ["MCX:GOLD1!"] and "valid symbol" in feed.reasons["MCX:GOLD1!"]
    assert not feed.down and "MCX:GOLD1!" in feed.invalid and feed.picked == {}


def test_a_login_or_rate_problem_does_not_make_the_scanner_try_every_month(tmp_path):
    feed, http = mcx_feed(tmp_path, {}, ["MCX:GOLD26DECFUT", "MCX:GOLD27FEBFUT"])
    http.rate_limit_after = 0
    out, failed = feed.fetch({"MCX:GOLD1!": "MCX:GOLD26NOVFUT"}, "1h")
    assert failed == ["MCX:GOLD1!"] and len(http.gets) == 1 and feed.down


def test_contracts_found_today_are_kept_in_the_saved_state_for_the_day_only(tmp_path):
    feed, http = mcx_feed(tmp_path, {"MCX:GOLD26DECFUT": mcx_series()}, ["MCX:GOLD26DECFUT"])
    feed.fetch({"MCX:GOLD1!": "MCX:GOLD26NOVFUT"}, "1h")
    state = {}
    feed.save_state(state)
    assert state["fyers"]["picked"] == {"MCX:GOLD1!": "MCX:GOLD26DECFUT"}
    same_day, _ = mcx_feed(tmp_path, {}, [])
    same_day.attach_state(state)
    assert same_day.picked == {"MCX:GOLD1!": "MCX:GOLD26DECFUT"}
    next_day, _ = mcx_feed(tmp_path, {}, [])
    next_day.now = lambda: NOW + timedelta(days=1)
    next_day.attach_state(state)
    assert next_day.picked == {}
    older = {"fyers": {"day": "2026-11-03", "calls": 5}}                                # state written by an older scanner version
    same_day.picked = {}
    same_day.attach_state(older)
    assert same_day.picked == {} and same_day.limiter.used == 5


def expiry_master(rows):
    """A commodity list whose 9th column holds the last trading day (epoch seconds), like the real one."""
    def row(n, ticker, expiry):
        r = mcx_row(n, ticker)
        r[8] = str(int(datetime(*expiry, 18, 0, tzinfo=timezone.utc).timestamp()))
        return r
    return csv_text([row(i, t, e) for i, (t, e) in enumerate(rows)])


def test_the_last_trading_day_in_the_list_decides_which_contract_is_in_use(tmp_path):
    http = lists()
    http.masters["MCX_COM"] = expiry_master([
        ("MCX:CRUDEOIL26OCTFUT", (2026, 10, 20)),         # expired two weeks ago but still in the file
        ("MCX:CRUDEOIL26NOVFUT", (2026, 11, 19)), ("MCX:CRUDEOIL26DECFUT", (2026, 12, 21)), ("MCX:CRUDEOIL27JANFUT", (2027, 1, 20)),
        ("MCX:GOLD26DECFUT", (2026, 12, 4)), ("MCX:GOLD27FEBFUT", (2027, 2, 4))])
    cfg = load_config()["fyers"]
    for today, want, spare in [(date(2026, 11, 3), "MCX:CRUDEOIL26NOVFUT", ["MCX:CRUDEOIL26DECFUT", "MCX:CRUDEOIL27JANFUT"]),
                               (date(2026, 11, 16), "MCX:CRUDEOIL26NOVFUT", ["MCX:CRUDEOIL26DECFUT", "MCX:CRUDEOIL27JANFUT"]),
                               (date(2026, 11, 17), "MCX:CRUDEOIL26DECFUT", ["MCX:CRUDEOIL27JANFUT"]),      # fewer than 3 days left
                               (date(2026, 11, 25), "MCX:CRUDEOIL26DECFUT", ["MCX:CRUDEOIL27JANFUT"])]:
        item = [Instrument("MCX:CRUDEOIL1!", "Crude Oil", "MCX"), Instrument("MCX:GOLD1!", "Gold", "MCX")]
        resolve(item, cfg, Master(cfg, http, now=lambda: NOW, folder=tmp_path / f"m{today.day}"), today=today)
        assert item[0].fyers == want and item[0].fyers_alts == spare
        assert item[1].fyers == "MCX:GOLD26DECFUT" and item[1].fyers_alts == ["MCX:GOLD27FEBFUT"]


def test_without_dates_in_the_list_contracts_of_past_months_are_skipped(tmp_path):
    http = lists()
    http.masters["MCX_COM"] = csv_text([mcx_row(i, t) for i, t in enumerate(
        ["MCX:CRUDEOIL26SEPFUT", "MCX:CRUDEOIL26OCTFUT", "MCX:CRUDEOIL26NOVFUT", "MCX:CRUDEOIL26DECFUT",
         "MCX:GOLD26DECFUT", "MCX:SILVER26DECFUT", "MCX:ZINC26NOVFUT"])])
    item = [Instrument("MCX:CRUDEOIL1!", "Crude Oil", "MCX")]
    cfg = load_config()["fyers"]
    resolve(item, cfg, Master(cfg, http, now=lambda: NOW, folder=tmp_path / "m"), today=date(2026, 11, 3))
    assert item[0].fyers == "MCX:CRUDEOIL26NOVFUT" and item[0].fyers_alts == ["MCX:CRUDEOIL26DECFUT"]


def test_guessed_contract_codes_run_from_this_month_across_the_new_year():
    from scanner.fyers import guess_contracts
    assert guess_contracts("GOLD", date(2026, 11, 3), 4) == ["MCX:GOLD26NOVFUT", "MCX:GOLD26DECFUT", "MCX:GOLD27JANFUT", "MCX:GOLD27FEBFUT"]


def test_setup_passes_the_spare_codes_to_the_feed_and_tells_when_the_list_was_unreadable(chat):
    sent, http = chat
    http.masters.pop("MCX_COM")
    cfg = load_config()
    items = [Instrument("MCX:GOLD1!", "Gold", "MCX"), Instrument("RELIANCE.NS", "Reliance", "NSE")]
    f = data.make_fetcher(cfg, items, purpose="scan")
    spare = f.fy.alts["MCX:GOLD1!"]
    assert len(spare) == 6 and all(c.startswith("MCX:GOLD") and c.endswith("FUT") for c in spare)      # the months after this one
    assert any("list of commodity contracts could not be read" in e for e in f.events)
    assert any("MCX_COM: download failed" in e for e in f.events)


def test_symbols_fyers_has_no_code_for_are_named_in_the_alert(chat):
    items = [Instrument("RELIANCE.NS", "Reliance", "NSE"), Instrument("NOPE.NS", "Not Listed Ltd", "NSE"),
             Instrument("MCX:LEAD1!", "Lead", "MCX"), Instrument("MCX:CPO1!", "Crude Palm Oil", "MCX", optional=True)]
    f = data.make_fetcher(load_config(), items, purpose="scan")
    assert any("no code for 1 commodity: Lead" in e and "skipped" in e for e in f.events)         # the optional one is not mentioned
    assert any("no code for 1 of 2 shares and indices: Not Listed Ltd" in e and "TradingView" in e for e in f.events)


def test_a_few_unmatched_shares_are_not_worth_an_alert(chat):
    sent, http = chat
    http.masters["NSE_CM"] = csv_text([nse_row(i, f"NSE:S{i}-EQ") for i in range(60)])
    cfg = load_config()
    few = [Instrument(f"S{k}.NS", f"S{k}", "NSE") for k in range(40)] + [Instrument("NOPE.NS", "Not Listed Ltd", "NSE")]
    assert not any("shares and indices" in e for e in data.make_fetcher(cfg, few, purpose="scan").events)       # 1 of 41: TradingView serves it
    many = [Instrument(f"S{k}.NS", f"S{k}", "NSE") for k in range(40)] + [Instrument(f"X{k}.NS", f"X{k}", "NSE") for k in range(10)]
    ev = data.make_fetcher(cfg, many, purpose="scan").events
    assert any("no code for 10 of 50 shares and indices: X0, X1" in e for e in ev)                           # 10 of 50: a real problem


def test_a_commodity_without_data_says_why_in_the_digest_and_the_report(tmp_path):
    cfg = load_config()
    cfg["timeframes"] = ["1h", "1d"]
    now = pd.Timestamp("2026-11-03 10:00", tz="UTC")
    gold, lead = Instrument("MCX:GOLD1!", "Gold", "MCX", universes=["commodities"], tfs={"1h", "1d"}), \
        Instrument("MCX:LEAD1!", "Lead", "MCX", universes=["commodities"], tfs={"1h", "1d"})
    raw = intraday_raw("MCX", 60, FRI, 40, lambda n: uptrend(n))
    daily = intraday_raw("MCX", 60, FRI, 40, lambda n: uptrend(n))

    class Fake:
        why = {}
        events = ["Fyers login ends in about 2 days - run workflow '4 - Fyers Login' soon."]

        def __call__(self, syms, itv):
            self.why = {s: "Fyers: Please provide a valid symbol; TradingView had no candles" for s in syms if s != gold.symbol}
            out = {s: (raw if itv == "1h" else daily) for s in syms if s == gold.symbol}
            return out, [s for s in syms if s not in out]

    coll = engine.collect(cfg, [gold, lead], {"MCX": ["1h", "1d"]}, now, Fake())
    notes = {"commodities": "2 symbols (from config.yaml)"}
    text = report.summary_text(coll, cfg, now, notes)
    assert "Where data is missing" in text and "Commodities (MCX)" in text and "1 of 2 without data" in text
    assert "Please provide a valid symbol" in text and "Fyers login ends in about 2 days" in text
    md, _ = report.build_report(coll, [gold, lead], cfg, now, notes)
    assert "Where data is missing, and why" in md and "Please provide a valid symbol" in md
    assert "Commodities (global proxy" not in text and "Commodities (global proxy" not in md       # never built -> not shown


def test_the_setup_message_lists_every_warning_so_the_log_need_not_be_opened():
    lines = [("INFO", "Scanner v1.2.2 · Python 3.12"), ("PASS", "Telegram bot found: @bot"),
             ("WARN", "Fyers codes found for 5 of 9 Indian symbols · not found: Lead, Zinc"),
             ("FAIL", "Fyers login: no Fyers login saved yet"), ("PASS", "Fyers login works · about 14 more day(s)"),
             ("INFO", "Fyers plan: standard · pace 40 requests/minute"), ("INFO", "MCX contracts in use: Gold → GOLD26DECFUT"),
             ("PASS", "NSE: TradingView data mode 'delayed_streaming_900' = 15 min delay (matches config)"),
             ("INFO", "NSE newest day candle is labelled 03 Nov"), ("WARN", "Tags <b> & more")]
    text = cli.setup_message(lines)
    assert text.startswith("🩺 <b>Setup check</b> · scanner v") and "3 passed · 2 warnings · 1 failed" in text
    assert "⚠️ Fyers codes found for 5 of 9 Indian symbols · not found: Lead, Zinc" in text
    assert "❌ Fyers login: no Fyers login saved yet" in text and "Tags &lt;b&gt; &amp; more" in text
    assert "Fyers plan: standard" in text and "MCX contracts in use: Gold → GOLD26DECFUT" in text and "data mode" in text
    assert "newest day candle" not in text and len(text) < 3900
    many = [("WARN", "x" * 250 + f" {n}") for n in range(60)]
    assert len(cli.setup_message(many)) <= 3900


def test_warnings_also_appear_as_github_annotations_but_only_inside_github(capsys, monkeypatch):
    monkeypatch.setenv("GITHUB_ACTIONS", "true")
    cli._annotate("WARN", "100% sure\nsecond line")
    cli._annotate("FAIL", "broken")
    cli._annotate("PASS", "fine")
    out = capsys.readouterr().out.splitlines()
    assert out == ["::warning title=Setup check::100%25 sure%0Asecond line", "::error title=Setup check::broken"]
    monkeypatch.delenv("GITHUB_ACTIONS")
    cli._annotate("WARN", "again")
    assert capsys.readouterr().out == ""


def test_check_setup_tests_every_commodity_contract_and_names_the_ones_without_candles(chat):
    sent, http = chat
    cli.main(["fyers-login", "--url", "auth_code=GOOD-CODE"])
    http.series["MCX:CRUDEOIL26NOVFUT"] = nse_series()
    cfg = load_config()
    items = [Instrument("^NSEI", "Nifty 50", "NSE"), Instrument("MCX:GOLD1!", "Gold", "MCX"), Instrument("MCX:CRUDEOIL1!", "Crude Oil", "MCX"),
             Instrument("MCX:SILVER1!", "Silver", "MCX")]
    lines = []
    cli._check_fyers(cfg, items, pd.Timestamp("2026-11-03 10:00", tz="UTC"), lambda lvl, msg: lines.append(f"[{lvl}] {msg}"))
    text = "\n".join(lines)
    assert "[WARN] Fyers commodity candles (1h, 1d): 2 of 3 contracts delivered them · missing: Silver (1h: " in text
    assert "MCX contracts in use: Gold → GOLD26DECFUT; Crude Oil → CRUDEOIL26NOVFUT; Silver → SILVER26DECFUT" in text


def test_check_setup_says_so_when_no_commodity_code_was_found_at_all(chat):
    sent, http = chat
    cli.main(["fyers-login", "--url", "auth_code=GOOD-CODE"])
    http.masters["MCX_COM"] = csv_text([mcx_row(i, f"MCX:WEIRD{i}") for i in range(8)])      # a list in a layout we do not know
    lines = []
    cli._check_fyers(load_config(), [Instrument("^NSEI", "Nifty 50", "NSE"), Instrument("MCX:GOLD1!", "Gold", "MCX")],
                     pd.Timestamp("2026-11-03 10:00", tz="UTC"), lambda lvl, msg: lines.append(f"[{lvl}] {msg}"))
    text = "\n".join(lines)
    assert "[WARN] No Fyers contract code was found for any commodity (the list had 8 usable entries; first ones: MCX:WEIRD0" in text
