from pathlib import Path

import yaml

WF = Path(__file__).resolve().parents[1] / ".github" / "workflows"


def load(name):
    doc = yaml.safe_load((WF / name).read_text(encoding="utf-8"))
    doc["on"] = doc.get("on", doc.get(True))             # PyYAML reads the key `on` as True
    return doc


def test_three_workflows_exist_and_parse():
    assert sorted(p.name for p in WF.glob("*.yml")) == ["check-setup.yml", "daily-report.yml", "scan.yml"]
    for p in WF.glob("*.yml"):
        doc = load(p.name)
        assert "workflow_dispatch" in doc["on"] and doc["jobs"]


def test_scan_runs_every_quarter_hour_after_the_candle_closes():
    cron = load("scan.yml")["on"]["schedule"][0]["cron"].split()
    assert len(cron) == 5
    minutes = [int(m) for m in cron[0].split(",")]
    assert minutes == [3, 18, 33, 48]                    # 3 minutes after :00/:15/:30/:45 closes


def test_secrets_are_only_referenced_never_written_in_files():
    for p in WF.glob("*.yml"):
        for line in p.read_text(encoding="utf-8").splitlines():
            if "TELEGRAM_" in line and ":" in line and "secrets." not in line and "env" not in line:
                raise AssertionError(f"{p.name}: {line}")
        assert "123456" not in p.read_text()


def test_state_cache_is_restored_and_always_saved_and_scan_is_serialised():
    for name in ("scan.yml", "daily-report.yml"):
        doc = load(name)
        steps = next(iter(doc["jobs"].values()))["steps"]
        uses = [s.get("uses", "") for s in steps]
        assert "actions/cache/restore@v4" in uses and "actions/cache/save@v4" in uses
        assert doc["concurrency"]["group"] == "ema-scanner" and doc["concurrency"]["cancel-in-progress"] is False
    assert load("daily-report.yml")["permissions"]["contents"] == "write"
    assert load("scan.yml")["permissions"]["contents"] == "read"


# ---- the "I uploaded ema-scanner.zip instead of the folders" route -------------------------------------------------
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
UNPACK = "Unpack the scanner"


def _unpack_script(name="check-setup.yml"):
    steps = next(iter(load(name)["jobs"].values()))["steps"]
    return next(s["run"] for s in steps if s.get("name", "").startswith(UNPACK))


def test_every_workflow_unpacks_the_zip_before_python_is_set_up():
    for p in WF.glob("*.yml"):
        steps = next(iter(load(p.name)["jobs"].values()))["steps"]
        names = [s.get("name", s.get("uses", "")) for s in steps]
        i = next(k for k, n in enumerate(names) if n.startswith(UNPACK))
        assert names[i - 1].startswith("actions/checkout") and names[i + 1].startswith("actions/setup-python")
    assert (ROOT / "workflow_files_to_paste").is_dir()
    for p in WF.glob("*.yml"):
        assert (ROOT / "workflow_files_to_paste" / p.name).read_text() == p.read_text()


def _make_zip(path, top="ema-scanner/"):
    with zipfile.ZipFile(path, "w") as z:
        for f in sorted((ROOT / "scanner").glob("*.py")):
            z.write(f, f"{top}scanner/{f.name}")
        for name in ("config.yaml", "requirements.txt"):
            z.write(ROOT / name, f"{top}{name}")
        z.write(WF / "check-setup.yml", f"{top}.github/workflows/check-setup.yml")
        z.writestr(f"{top}scanner/", "")                      # a folder entry, as zip tools write them


def _run_unpack(cwd):
    r = subprocess.run(["bash", "-e", "-c", _unpack_script()], cwd=cwd, capture_output=True, text=True,
                       env={"PATH": str(Path(shutil.which("python3")).parent) + ":/usr/bin:/bin"})
    assert r.returncode == 0, r.stderr
    return r.stdout


def test_zip_route_unpacks_code_keeps_your_config_and_replaces_stale_files(tmp_path):
    (tmp_path / "scanner").mkdir()
    (tmp_path / "scanner" / "config.py").write_text("OLD = 1\n")             # a stale file from an earlier upload
    mine = ("data_source: yahoo\nuniverses:\n  crypto: {enabled: true, label: Crypto, market: CRYPTO, source: list, list: crypto}\n"
            "lists:\n  crypto: [{symbol: BTC-USD, name: Bitcoin}]\n")
    (tmp_path / "config.yaml").write_text(mine)                                # the user's own settings
    _make_zip(tmp_path / "ema-scanner.zip")
    assert "Unpacked ema-scanner.zip" in _run_unpack(tmp_path)
    assert (tmp_path / "scanner" / "tv.py").exists() and (tmp_path / "requirements.txt").exists()
    assert "VALID_MARKETS" in (tmp_path / "scanner" / "config.py").read_text()      # replaced
    assert (tmp_path / "config.yaml").read_text() == mine                            # kept
    assert not (tmp_path / ".github").exists()                                       # workflows never touched
    ok = subprocess.run([shutil.which("python3"), "-c", "from scanner.config import load_config; "
                         "c = load_config(); assert c['data_source'] == 'yahoo'"], cwd=tmp_path)
    assert ok.returncode == 0


def test_zip_route_works_without_top_folder_default_config_and_odd_zips(tmp_path):
    _make_zip(tmp_path / "ema-scanner (1).zip", top="")                              # zipped the contents directly
    with zipfile.ZipFile(tmp_path / "other.zip", "w") as z:
        z.writestr("notes.txt", "not ours")
    _run_unpack(tmp_path)
    assert (tmp_path / "scanner" / "__main__.py").exists() and (tmp_path / "config.yaml").exists()
    assert not (tmp_path / "notes.txt").exists()


def test_no_zip_means_nothing_happens(tmp_path):
    assert _run_unpack(tmp_path) == "" and list(tmp_path.iterdir()) == []
