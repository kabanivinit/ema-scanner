from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
WF = ROOT / ".github" / "workflows"


def load(name):
    doc = yaml.safe_load((WF / name).read_text(encoding="utf-8"))
    doc["on"] = doc.get("on", doc.get(True))             # PyYAML reads the key `on` as True
    return doc


def test_five_workflows_exist_and_parse():
    assert sorted(p.name for p in WF.glob("*.yml")) == ["backtest.yml", "check-setup.yml", "daily-report.yml",
                                                       "fyers-login.yml", "scan.yml"]
    for p in WF.glob("*.yml"):
        doc = load(p.name)
        assert "workflow_dispatch" in doc["on"] and doc["jobs"]


def test_scan_runs_every_five_minutes_with_a_slot_3_minutes_after_every_quarter_hour_close():
    cron = load("scan.yml")["on"]["schedule"][0]["cron"].split()
    assert len(cron) == 5 and cron[1:] == ["*"] * 4
    minutes = [int(m) for m in cron[0].split(",")]
    assert {3, 18, 33, 48} <= set(minutes)               # 3 minutes after :00/:15/:30/:45 closes
    assert len(minutes) == 12 and all(b - a == 5 for a, b in zip(minutes, minutes[1:]))     # GitHub's shortest interval
    assert 0 not in minutes                              # the top of the hour is when GitHub is busiest


def test_secrets_are_only_referenced_never_written_in_files():
    for p in WF.glob("*.yml"):
        for line in p.read_text(encoding="utf-8").splitlines():
            if "TELEGRAM_" in line and ":" in line and "secrets." not in line and "env" not in line:
                raise AssertionError(f"{p.name}: {line}")
            if "FYERS_" in line and ":" in line and not line.strip().startswith("#"):
                key, _, value = line.strip().partition(":")
                assert "${{ secrets." in value or "${{ inputs." in value, f"{p.name}: {line}"
        assert "123456" not in p.read_text()


FYERS_SECRETS = ["FYERS_APP_ID", "FYERS_SECRET_ID", "FYERS_PIN", "FYERS_REDIRECT_URI", "FYERS_PLAN"]


def _env_of(name):
    """All env variables of all steps of a workflow."""
    out = {}
    for job in load(name)["jobs"].values():
        for step in job["steps"]:
            out.update(step.get("env") or {})
    return out


def test_every_workflow_that_reads_prices_gets_all_the_fyers_secrets():
    for name in ("scan.yml", "check-setup.yml", "daily-report.yml", "fyers-login.yml"):
        env = _env_of(name)
        for k in FYERS_SECRETS:
            assert env.get(k) == "${{ secrets." + k + " }}", (name, k)
    assert not any(k.startswith("FYERS_") for k in _env_of("backtest.yml"))        # the backtest uses TradingView history only


def test_fyers_login_is_manual_passes_the_pasted_address_safely_and_keeps_the_login_in_the_memory():
    doc = load("fyers-login.yml")
    assert list(doc["on"]) == ["workflow_dispatch"]
    box = doc["on"]["workflow_dispatch"]["inputs"]["login_address"]
    assert box["required"] is False and box["default"] == ""                      # empty = "send me the login link"
    assert doc["concurrency"]["group"] == "ema-scanner" and doc["concurrency"]["cancel-in-progress"] is False
    steps = doc["jobs"]["login"]["steps"]
    run = next(s for s in steps if s.get("name") == "Fyers login")
    assert run["run"].strip() == "python -m scanner fyers-login"
    assert run["env"]["FYERS_LOGIN_URL"] == "${{ inputs.login_address }}"          # through the environment, never into shell text
    assert not any("inputs." in str(s.get("run", "")) for s in steps)
    uses = [s.get("uses", "") for s in steps]
    assert "actions/cache/restore@v4" in uses and "actions/cache/save@v4" in uses
    assert next(s for s in steps if s.get("uses") == "actions/cache/save@v4")["if"] == "${{ always() }}"
    assert doc["permissions"] == {"contents": "read"}


def test_a_scan_has_time_for_a_slow_fyers_round_plus_the_tradingview_backup():
    from scanner.config import load_config
    cfg = load_config()
    need = (cfg["fyers"]["max_seconds"] + cfg["tradingview"]["max_seconds"]) / 60
    assert load_config() and need < load_scan_timeout() <= 360            # GitHub's own limit is 6 hours


def load_scan_timeout():
    return load("scan.yml")["jobs"]["scan"]["timeout-minutes"]


def test_check_setup_may_read_the_memory_but_never_changes_it():
    steps = load("check-setup.yml")["jobs"]["check"]["steps"]
    uses = [s.get("uses", "") for s in steps]
    assert "actions/cache/restore@v4" in uses and "actions/cache/save@v4" not in uses


def test_the_saved_fyers_login_is_never_committed_to_the_repository():
    for p in WF.glob("*.yml"):
        for line in p.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith("git add"):
                assert " state" not in line and "." != line.split()[-1], f"{p.name}: {line}"
    assert "state/" in (ROOT / ".gitignore").read_text().split()


def test_the_daily_report_is_not_published_in_the_public_repository():
    text = (WF / "daily-report.yml").read_text(encoding="utf-8")
    adds = [ln.strip() for ln in text.splitlines() if ln.strip().startswith("git add")]
    assert adds == ["git add universe_cache 2>/dev/null || true"]       # prices-derived figures go to Telegram only
    assert "reports" not in " ".join(adds)


def test_requirements_include_what_the_fyers_login_needs():
    reqs = (ROOT / "requirements.txt").read_text()
    assert "cryptography" in reqs


def test_state_cache_is_restored_and_always_saved_and_scan_is_serialised():
    for name in ("scan.yml", "daily-report.yml"):
        doc = load(name)
        steps = next(iter(doc["jobs"].values()))["steps"]
        uses = [s.get("uses", "") for s in steps]
        assert "actions/cache/restore@v4" in uses and "actions/cache/save@v4" in uses
        assert doc["concurrency"]["group"] == "ema-scanner" and doc["concurrency"]["cancel-in-progress"] is False
    assert load("daily-report.yml")["permissions"]["contents"] == "write"
    assert load("scan.yml")["permissions"]["contents"] == "read"


# ---- the "I uploaded ema-scanner.zip instead of the folders" route -------------------------------------------------
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
UNPACK = "Unpack the scanner"


def _unpack_script(name="check-setup.yml"):
    steps = next(iter(load(name)["jobs"].values()))["steps"]
    return next(s["run"] for s in steps if s.get("name", "").startswith(UNPACK))


def test_every_workflow_unpacks_the_zip_before_python_is_set_up():
    for p in WF.glob("*.yml"):
        steps = next(iter(load(p.name)["jobs"].values()))["steps"]
        names = [s.get("name", s.get("uses", "")) for s in steps]
        i = next(k for k, n in enumerate(names) if n.startswith(UNPACK))
        assert names[i - 1].startswith("actions/checkout") and names[i + 1].startswith("actions/setup-python")
    assert (ROOT / "workflow_files_to_paste").is_dir()
    for p in WF.glob("*.yml"):
        assert (ROOT / "workflow_files_to_paste" / p.name).read_text() == p.read_text()


def _make_zip(path, top="ema-scanner/"):
    with zipfile.ZipFile(path, "w") as z:
        for f in sorted((ROOT / "scanner").glob("*.py")):
            z.write(f, f"{top}scanner/{f.name}")
        for name in ("config.yaml", "requirements.txt"):
            z.write(ROOT / name, f"{top}{name}")
        z.write(WF / "check-setup.yml", f"{top}.github/workflows/check-setup.yml")
        z.writestr(f"{top}scanner/", "")                      # a folder entry, as zip tools write them


def _run_unpack(cwd):
    r = subprocess.run(["bash", "-e", "-c", _unpack_script()], cwd=cwd, capture_output=True, text=True,
                       env={"PATH": str(Path(shutil.which("python3")).parent) + ":/usr/bin:/bin"})
    assert r.returncode == 0, r.stderr
    return r.stdout


def test_zip_route_unpacks_code_keeps_your_config_and_replaces_stale_files(tmp_path):
    (tmp_path / "scanner").mkdir()
    (tmp_path / "scanner" / "config.py").write_text("OLD = 1\n")             # a stale file from an earlier upload
    mine = ("data_source: yahoo\nuniverses:\n  crypto: {enabled: true, label: Crypto, market: CRYPTO, source: list, list: crypto}\n"
            "lists:\n  crypto: [{symbol: BTC-USD, name: Bitcoin}]\n")
    (tmp_path / "config.yaml").write_text(mine)                                # the user's own settings
    _make_zip(tmp_path / "ema-scanner.zip")
    assert "Unpacked ema-scanner.zip" in _run_unpack(tmp_path)
    assert (tmp_path / "scanner" / "tv.py").exists() and (tmp_path / "requirements.txt").exists()
    assert "VALID_MARKETS" in (tmp_path / "scanner" / "config.py").read_text()      # replaced
    assert (tmp_path / "config.yaml").read_text() == mine                            # kept
    assert not (tmp_path / ".github").exists()                                       # workflows never touched
    ok = subprocess.run([shutil.which("python3"), "-c", "from scanner.config import load_config; "
                         "c = load_config(); assert c['data_source'] == 'yahoo'"], cwd=tmp_path)
    assert ok.returncode == 0


def test_zip_route_works_without_top_folder_default_config_and_odd_zips(tmp_path):
    _make_zip(tmp_path / "ema-scanner (1).zip", top="")                              # zipped the contents directly
    with zipfile.ZipFile(tmp_path / "other.zip", "w") as z:
        z.writestr("notes.txt", "not ours")
    _run_unpack(tmp_path)
    assert (tmp_path / "scanner" / "__main__.py").exists() and (tmp_path / "config.yaml").exists()
    assert not (tmp_path / "notes.txt").exists()


def test_no_zip_means_nothing_happens(tmp_path):
    assert _run_unpack(tmp_path) == "" and list(tmp_path.iterdir()) == []


# ---- the backtest workflow -----------------------------------------------------------------------------------------
def test_backtest_workflow_is_manual_has_its_own_queue_and_never_touches_the_alert_memory():
    doc = load("backtest.yml")
    assert list(doc["on"]) == ["workflow_dispatch"]                        # never runs by itself
    assert set(doc["on"]["workflow_dispatch"]["inputs"]) == {"only", "years", "limit"}
    assert doc["concurrency"]["group"] == "ema-backtest" and doc["concurrency"]["cancel-in-progress"] is False
    assert doc["concurrency"]["group"] != load("scan.yml")["concurrency"]["group"]      # never blocks the 15-minute scans
    assert doc["permissions"]["contents"] == "write"
    job = doc["jobs"]["backtest"]
    assert job["timeout-minutes"] <= 360                                    # GitHub's limit for hosted runners
    uses = [s.get("uses", "") for s in job["steps"]]
    assert "actions/cache/restore@v4" in uses and "actions/cache/save@v4" not in uses   # read-only: scans keep their memory
    run = next(s for s in job["steps"] if s.get("name", "").startswith("Run the backtest"))
    assert "python -m scanner backtest" in run["run"] and "BT_YEARS" in run["env"]
    assert "${{ github.event.inputs" not in run["run"]                      # inputs go through env variables, not into the shell text
    keep = next(s for s in job["steps"] if s.get("name", "").startswith("Keep a copy"))
    assert keep["if"] == "${{ always() }}" and "git add reports/backtest" in keep["run"]


def test_all_workflows_share_the_same_unpack_step():
    assert len({_unpack_script(p.name) for p in WF.glob("*.yml")}) == 1


# ---- the backtest's last step: "keep a copy of the results in the repository" ----------------------------------------
# A real run failed here with "error: cannot pull with rebase: You have unstaged changes" (exit code 128): the restored
# symbol memory had changed a tracked file. These tests run the step's real script against throw-away git repositories.
import os

import pytest

needs_git = pytest.mark.skipif(shutil.which("git") is None, reason="git is not installed")


def _keep_script():
    steps = load("backtest.yml")["jobs"]["backtest"]["steps"]
    return next(s["run"] for s in steps if s.get("name", "").startswith("Keep a copy"))


def _genv(home):
    return dict(os.environ, HOME=str(home), GIT_CONFIG_NOSYSTEM="1", GIT_TERMINAL_PROMPT="0")


def _git(cwd, home, *args):
    r = subprocess.run(["git", *args], cwd=cwd, capture_output=True, text=True, env=_genv(home))
    assert r.returncode == 0, r.stderr
    return r.stdout


def _repos(tmp_path):
    """A remote with one commit, plus the checkout a runner would have (code unpacked, restored memory changed)."""
    home = tmp_path / "home"
    home.mkdir()
    remote, seed, runner = tmp_path / "remote.git", tmp_path / "seed", tmp_path / "runner"
    _git(tmp_path, home, "init", "-q", "--bare", "-b", "main", str(remote))
    _git(tmp_path, home, "clone", "-q", str(remote), str(seed))
    (seed / "universe_cache").mkdir()
    (seed / "reports").mkdir()
    (seed / "universe_cache" / "a.json").write_text('{"a": 1}')
    (seed / "reports" / "latest.md").write_text("old")
    _git(seed, home, "add", "-A")
    _git(seed, home, "-c", "user.name=seed", "-c", "user.email=s@example.com", "commit", "-q", "-m", "init")
    _git(seed, home, "push", "-q", "origin", "HEAD:main")
    _git(tmp_path, home, "clone", "-q", str(remote), str(runner))
    (runner / "scanner").mkdir()
    (runner / "scanner" / "unpacked.py").write_text("x = 1\n")                  # unpacked from the zip: untracked
    (runner / "universe_cache" / "a.json").write_text('{"a": 2}')               # restored memory differs from the repository's copy
    return home, remote, seed, runner


def _run_keep(runner, home):
    return subprocess.run(["bash", "--noprofile", "--norc", "-e", "-o", "pipefail", "-c", _keep_script()], cwd=runner,
                          capture_output=True, text=True, env=_genv(home))


@needs_git
def test_backtest_copy_step_saves_results_despite_changed_tracked_files_and_a_remote_that_moved_on(tmp_path):
    home, remote, seed, runner = _repos(tmp_path)
    (runner / "reports" / "backtest").mkdir(parents=True)
    (runner / "reports" / "backtest" / "latest.md").write_text("# results")
    (seed / "reports" / "latest.md").write_text("newer daily report")             # the daily report pushed meanwhile
    _git(seed, home, "-c", "user.name=seed", "-c", "user.email=s@example.com", "commit", "-q", "-am", "daily")
    _git(seed, home, "push", "-q", "origin", "HEAD:main")
    r = _run_keep(runner, home)
    assert r.returncode == 0, r.stdout + r.stderr
    assert "::warning::" not in r.stdout
    check = tmp_path / "check"
    _git(tmp_path, home, "clone", "-q", str(remote), str(check))
    assert (check / "reports" / "backtest" / "latest.md").read_text() == "# results"
    assert (check / "reports" / "latest.md").read_text() == "newer daily report"      # nothing of the daily report lost
    assert (check / "universe_cache" / "a.json").read_text() == '{"a": 1}'            # the restored memory is not saved


@needs_git
def test_backtest_copy_step_with_no_results_does_nothing(tmp_path):
    home, remote, seed, runner = _repos(tmp_path)
    r = _run_keep(runner, home)
    assert r.returncode == 0 and "Nothing new to save." in r.stdout and "::warning::" not in r.stdout


@needs_git
def test_backtest_copy_step_only_warns_when_the_repository_cannot_be_reached(tmp_path):
    home, remote, seed, runner = _repos(tmp_path)
    (runner / "reports" / "backtest").mkdir(parents=True)
    (runner / "reports" / "backtest" / "latest.md").write_text("# results")
    _git(runner, home, "remote", "set-url", "origin", str(tmp_path / "nowhere.git"))
    r = _run_keep(runner, home)
    assert r.returncode == 0                                                           # the answer already reached Telegram
    assert "::warning::Could not save a copy of the results" in r.stdout


# ---- the daily report's last step: "keep the symbol lists in the repository" -------------------------------------------
# A real run (04 Nov 2026) failed here with "error: cannot pull with rebase: You have unstaged changes" (exit code 128):
# the run rewrites the report files of earlier days, which are still tracked in the repository, and only the symbol lists
# are committed. Same safeguard as the backtest's step; tested the same way.
def _daily_keep_script():
    steps = load("daily-report.yml")["jobs"]["report"]["steps"]
    return next(s["run"] for s in steps if s.get("name", "").startswith("Keep the symbol lists"))


def _run_daily_keep(runner, home):
    return subprocess.run(["bash", "--noprofile", "--norc", "-e", "-o", "pipefail", "-c", _daily_keep_script()], cwd=runner,
                          capture_output=True, text=True, env=_genv(home))


def _clone(tmp_path, home, remote, name="check"):
    _git(tmp_path, home, "clone", "-q", str(remote), str(tmp_path / name))
    return tmp_path / name


@needs_git
def test_daily_report_step_saves_the_symbol_lists_although_an_old_report_file_was_rewritten(tmp_path):
    home, remote, seed, runner = _repos(tmp_path)
    (runner / "reports" / "latest.md").write_text("today's report")                    # tracked since an earlier day, rewritten now
    r = _run_daily_keep(runner, home)
    assert r.returncode == 0, r.stdout + r.stderr
    assert "::warning::" not in r.stdout
    check = _clone(tmp_path, home, remote)
    assert (check / "universe_cache" / "a.json").read_text() == '{"a": 2}'               # the new symbol list is saved ...
    assert (check / "reports" / "latest.md").read_text() == "old"                        # ... today's report is not published


@needs_git
def test_daily_report_step_copes_with_a_remote_that_moved_on(tmp_path):
    home, remote, seed, runner = _repos(tmp_path)
    (runner / "reports" / "latest.md").write_text("today's report")
    (seed / "notes.txt").write_text("pushed meanwhile")
    _git(seed, home, "add", "notes.txt")
    _git(seed, home, "-c", "user.name=seed", "-c", "user.email=s@example.com", "commit", "-q", "-m", "other")
    _git(seed, home, "push", "-q", "origin", "HEAD:main")
    r = _run_daily_keep(runner, home)
    assert r.returncode == 0 and "::warning::" not in r.stdout, r.stdout + r.stderr
    check = _clone(tmp_path, home, remote)
    assert (check / "notes.txt").read_text() == "pushed meanwhile"
    assert (check / "universe_cache" / "a.json").read_text() == '{"a": 2}'


@needs_git
def test_daily_report_step_with_unchanged_symbol_lists_does_nothing_even_if_reports_changed(tmp_path):
    home, remote, seed, runner = _repos(tmp_path)
    (runner / "universe_cache" / "a.json").write_text('{"a": 1}')                      # same as the repository's copy
    (runner / "reports" / "latest.md").write_text("today's report")
    r = _run_daily_keep(runner, home)
    assert r.returncode == 0 and "Nothing new to save." in r.stdout and "::warning::" not in r.stdout
    assert (_clone(tmp_path, home, remote) / "reports" / "latest.md").read_text() == "old"


@needs_git
def test_daily_report_step_only_warns_when_the_repository_cannot_be_reached(tmp_path):
    home, remote, seed, runner = _repos(tmp_path)
    _git(runner, home, "remote", "set-url", "origin", str(tmp_path / "nowhere.git"))
    r = _run_daily_keep(runner, home)
    assert r.returncode == 0                                                           # the report already reached Telegram
    assert "::warning::Could not save the symbol lists" in r.stdout
