"""Backtest: the arithmetic (checked against an independent bar-by-bar loop), the plumbing, the reports, the command."""
from datetime import date
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

from scanner import backtest as bt
from scanner import backtest_report as rep
from scanner import cli, telegram
from scanner.config import ConfigError, load_config
from scanner.signals import cross_flags, pine_ema
from scanner.universe import Instrument
from synth import daily_raw, first_cross, intraday_raw, vshape

FRI = date(2026, 10, 30)
ALL_TFS = ("15m", "1h", "4h", "1d", "1w")


# ------------------------------------------------------------------------------------------------ helpers
def walk(seed, n, drift=0.0003, vol=0.01):
    rng = np.random.default_rng(seed)
    return 100.0 * np.exp(np.cumsum(rng.normal(drift, vol, n)))


def frame(close, open_=None, start="2023-01-02", freq="1D"):
    close = np.asarray(close, dtype=float)
    if open_ is None:
        open_ = np.concatenate([[close[0]], close[:-1]])          # no gaps: each candle opens at the previous close
    return pd.DataFrame({"open": np.asarray(open_, dtype=float), "close": close,
                         "end": pd.date_range(start, periods=len(close), freq=freq, tz="UTC")})


def ref_loop(f, short, long, cost, warmup, years):
    """An independent, plain bar-by-bar version of the rule (no vector tricks) to check `simulate` against."""
    close, open_ = f["close"].to_numpy(), f["open"].to_numpy()
    ends = pd.DatetimeIndex(f["end"])
    n = len(close)
    s = pd.Series(close)
    es = s.ewm(alpha=2 / (short + 1), adjust=False).mean().to_numpy()
    el = s.ewm(alpha=2 / (long + 1), adjust=False).mean().to_numpy()
    cutoff = ends[-1] - pd.Timedelta(days=365.25 * years)
    first = next(i for i in range(n) if ends[i] >= cutoff)
    i0 = max(warmup, first)
    eq, peak, maxdd, pos, entry, nets = 1.0, 1.0, 0.0, False, None, []
    for t in range(i0 + 1, n):
        sig = t - 1
        up = es[sig] > el[sig] and es[sig - 1] <= el[sig - 1]
        dn = es[sig] < el[sig] and es[sig - 1] >= el[sig - 1]
        if up and not pos:
            pos, entry = True, open_[t]
            eq *= (1 - cost) * close[t] / open_[t]
        elif dn and pos:
            eq *= open_[t] / close[t - 1] * (1 - cost)
            nets.append(open_[t] / entry * (1 - cost) ** 2 - 1)
            pos = False
        elif pos:
            eq *= close[t] / close[t - 1]
        if t == n - 1 and pos:                                  # still in: counted as sold at the last close
            eq *= (1 - cost)
            nets.append(close[-1] / entry * (1 - cost) ** 2 - 1)
        peak = max(peak, eq)
        maxdd = min(maxdd, eq / peak - 1)
    return eq, maxdd, nets


def inst(symbol, name, market="NSE", unis=("nifty500",), tfs=ALL_TFS):
    return Instrument(symbol=symbol, name=name, market=market, universes=list(unis), tv=f"{market}:{name}",
                      currency="₹", tfs=set(tfs))


def fcfg(**over):
    cfg = load_config()
    cfg["data_source"] = "yahoo"                 # no feed delay in these tests
    for k, v in over.items():
        cfg["backtest"][k] = v
    return bt.fetch_cfg(cfg)


# --------------------------------------------------------------------------------------- the arithmetic
@pytest.mark.parametrize("seed", range(8))
@pytest.mark.parametrize("cost,years", [(0.0, 3), (0.0005, 3), (0.002, 1), (0.001, 10)])
def test_simulation_matches_an_independent_bar_by_bar_loop(seed, cost, years):
    rng = np.random.default_rng(100 + seed)
    close = walk(seed, 900, vol=0.012)
    open_ = np.concatenate([[100.0], close[:-1]]) * (1 + rng.normal(0, 0.004, 900))      # gaps between candles
    f = frame(close, open_)
    r = bt.simulate(f, 10, 20, cost, 60, years)
    eq, maxdd, nets = ref_loop(f, 10, 20, cost, 60, years)
    assert r["trades"] == len(nets) > 0
    assert list(r["_net"]) == pytest.approx(nets, rel=1e-9, abs=1e-12)
    assert r["total_return_pct"] == pytest.approx((eq - 1) * 100, rel=1e-9, abs=1e-9)
    assert r["max_dd_pct"] == pytest.approx(maxdd * 100, rel=1e-9, abs=1e-9)
    assert np.prod(1 + r["_net"]) == pytest.approx(eq, rel=1e-9)                          # trades and account agree


def test_known_case_one_bullish_cross_bought_at_next_open_and_held_to_the_end():
    close = vshape(300)
    k = first_cross(close, after=60)
    f = frame(close)
    r = bt.simulate(f, 10, 20, 0.001, 60, 10)
    assert r["trades"] == 1 and r["open_trade"] is True
    e, x, entry_px, exit_px = r["_trades"][0]
    assert e == k + 1 and x is None
    assert entry_px == pytest.approx(close[k]) and exit_px == close[-1]                  # next open = previous close here
    expected = close[-1] / close[k] * (1 - 0.001) ** 2 - 1
    assert r["_net"][0] == pytest.approx(expected)
    assert r["total_return_pct"] == pytest.approx(expected * 100)
    assert r["win_rate_pct"] == 100.0 and r["profit_factor"] is None                     # no losing trade at all


def test_costs_lower_every_trade_by_exactly_the_two_fees():
    f = frame(walk(3, 900))
    free, paid = bt.simulate(f, 10, 20, 0.0, 60, 3), bt.simulate(f, 10, 20, 0.001, 60, 3)
    assert free["trades"] == paid["trades"] > 3
    assert list(paid["_net"]) == pytest.approx((1 + free["_net"]) * (1 - 0.001) ** 2 - 1)
    assert paid["total_return_pct"] < free["total_return_pct"]
    assert free["avg_trade_pct"] == pytest.approx(free["gross_avg_trade_pct"])


def test_window_limits_trading_to_the_last_years_and_reports_the_covered_period():
    f = frame(walk(5, 1500))
    r = bt.simulate(f, 10, 20, 0.0005, 60, 1)
    assert 0.98 <= r["years"] <= 1.0
    cutoff = f["end"].iloc[-1] - pd.Timedelta(days=365.25)
    i0 = int(np.argmax((f["end"] >= cutoff).to_numpy()))
    assert all(t[0] >= i0 + 1 for t in r["_trades"])
    assert r["window_to"] == f["end"].iloc[-1].date().isoformat()


def test_no_trade_before_the_warm_up_is_over():
    f = frame(walk(6, 400))
    late, early = bt.simulate(f, 10, 20, 0.0, 60, 10), bt.simulate(f, 10, 20, 0.0, 5, 10)
    assert all(t[0] >= 61 for t in late["_trades"])
    assert min(t[0] for t in early["_trades"]) < 61                    # with a shorter warm-up an earlier trade appears


def test_too_short_series_returns_none():
    assert bt.simulate(frame(walk(1, 40)), 10, 20, 0.0, 60, 3) is None
    assert bt.simulate(frame(walk(1, 62)), 10, 20, 0.0, 60, 3) is None             # nothing left to trade after the warm-up
    tiny = bt.simulate(frame(walk(1, 70)), 10, 20, 0.0, 60, 3)
    assert tiny is not None and tiny["bars"] == 9


def test_a_signal_on_the_very_last_candle_cannot_be_bought_yet():
    close = vshape(300)
    k = first_cross(close, after=60)
    r = bt.simulate(frame(close[: k + 1]), 10, 20, 0.0, 60, 10)                          # the cross is the last candle
    assert r["trades"] == 0 and r["total_return_pct"] == 0.0 and r["max_dd_pct"] == 0.0
    assert r["exposure_pct"] == 0.0


def test_exit_signal_on_the_last_candle_leaves_the_trade_open_at_the_last_close():
    close = walk(11, 700)
    up, dn = cross_flags(pine_ema(pd.Series(close), 10), pine_ema(pd.Series(close), 20))
    first_up = next(i for i in np.flatnonzero(up.to_numpy()) if i >= 60)
    j = next(i for i in np.flatnonzero(dn.to_numpy()) if i > first_up)
    f = frame(close[: j + 1])
    r = bt.simulate(f, 10, 20, 0.0, 60, 10)
    assert r["open_trade"] and r["_trades"][-1][1] is None and r["_trades"][-1][3] == close[j]
    eq, maxdd, nets = ref_loop(f, 10, 20, 0.0, 60, 10)
    assert r["total_return_pct"] == pytest.approx((eq - 1) * 100)


def test_buy_and_hold_and_yearly_return_use_the_same_period():
    f = frame(walk(7, 1000, drift=0.0008))
    r = bt.simulate(f, 10, 20, 0.0005, 60, 3)
    i0 = max(60, int(np.argmax((f["end"] >= f["end"].iloc[-1] - pd.Timedelta(days=365.25 * 3)).to_numpy())))
    first_open = f["open"].iloc[i0 + 1]
    assert r["bh_return_pct"] == pytest.approx((f["close"].iloc[-1] / first_open - 1) * 100)
    assert r["bh_cagr_pct"] == pytest.approx(((1 + r["bh_return_pct"] / 100) ** (1 / r["years"]) - 1) * 100, rel=1e-3)
    assert r["bh_max_dd_pct"] <= 0 and r["max_dd_pct"] <= 0


def test_cagr_edge_cases():
    assert bt.cagr_pct(2.0, 1.0) == pytest.approx(100.0)
    assert bt.cagr_pct(1.21, 2.0) == pytest.approx(10.0)
    assert bt.cagr_pct(0.0, 1.0) == -100.0 and bt.cagr_pct(-0.5, 1.0) == -100.0
    assert bt.cagr_pct(1.5, 0.01) is None


def test_missing_or_zero_opens_fall_back_to_the_close():
    close = walk(2, 600)
    open_ = np.concatenate([[100.0], close[:-1]])
    open_[200:260] = np.nan
    open_[300] = 0.0
    r = bt.simulate(frame(close, open_), 10, 20, 0.0005, 60, 10)
    assert r is not None and np.isfinite(r["total_return_pct"]) and np.isfinite(r["max_dd_pct"])


def test_profit_factor_and_pooled_numbers():
    f = frame(walk(3, 900))
    r = bt.simulate(f, 10, 20, 0.0005, 60, 3)
    net = r["_net"] * 100
    assert r["pos_sum_pct"] == pytest.approx(net[net > 0].sum()) and r["neg_sum_pct"] == pytest.approx(net[net < 0].sum())
    assert r["profit_factor"] == pytest.approx(net[net > 0].sum() / -net[net < 0].sum())
    assert r["wins"] == int((net > 0).sum()) and r["win_rate_pct"] == pytest.approx((net > 0).mean() * 100)


# ------------------------------------------------------------------------------- from raw candles to a result
def test_every_timeframe_runs_through_the_candle_builders():
    cfg = fcfg()
    now = pd.Timestamp("2026-10-30 16:30", tz="Asia/Kolkata").tz_convert("UTC")
    raw = {"15m": intraday_raw("NSE", 15, FRI, 30, lambda n: walk(1, n, vol=0.002)),
           "1h": intraday_raw("NSE", 60, FRI, 120, lambda n: walk(2, n, vol=0.004)),
           "1d": daily_raw("NSE", FRI, 900, lambda n: walk(3, n))}
    for tf, itv in (("15m", "15m"), ("1h", "1h"), ("4h", "1h"), ("1d", "1d"), ("1w", "1d")):
        res = bt.backtest_series(raw[itv], "NSE", tf, cfg, now, 3.0, 0.0005)
        assert res["status"] == "ok", (tf, res)
        assert res["years"] > 0.05 and res["bars"] > 20
    daily = bt.backtest_series(raw["1d"], "NSE", "1d", cfg, now, 3.0, 0.0005)
    assert 2.9 <= daily["years"] <= 3.0


def test_reasons_when_a_series_cannot_be_tested():
    cfg = fcfg()
    now = pd.Timestamp("2026-10-30 16:30", tz="Asia/Kolkata").tz_convert("UTC")
    assert bt.backtest_series(None, "NSE", "1d", cfg, now, 3.0, 0.0005)["status"] == "no data from the data feed"
    short = daily_raw("NSE", FRI, 50, lambda n: walk(1, n))
    assert bt.backtest_series(short, "NSE", "1d", cfg, now, 3.0, 0.0005)["status"].startswith("only 50 closed candles")


def test_the_forming_candle_is_never_tested():
    cfg = fcfg()
    raw = daily_raw("NSE", FRI, 300, lambda n: walk(4, n))
    after = pd.Timestamp("2026-10-30 16:30", tz="Asia/Kolkata").tz_convert("UTC")
    during = pd.Timestamp("2026-10-30 12:00", tz="Asia/Kolkata").tz_convert("UTC")        # Friday's candle still forming
    a = bt.backtest_series(raw, "NSE", "1d", cfg, after, 3.0, 0.0005)
    d = bt.backtest_series(raw, "NSE", "1d", cfg, during, 3.0, 0.0005)
    assert a["window_to"] == "2026-10-30" and d["window_to"] == "2026-10-29"


# ------------------------------------------------------------------------------------------ the run
def make_data(symbols, market="NSE", seed0=0):
    raw = {}
    for k, s in enumerate(symbols):
        raw[(s, "1d")] = daily_raw(market, FRI, 900, lambda n, k=k: walk(seed0 + k, n))
    return raw


def fake_fetcher(raw, calls=None, slow=None):
    def fetch(symbols, interval):
        if calls is not None:
            calls.append((tuple(symbols), interval))
        if slow:
            slow()
        out = {s: raw[(s, interval)] for s in symbols if (s, interval) in raw}
        return out, [s for s in symbols if s not in out]
    return fetch


NOW = pd.Timestamp("2026-10-30 16:30", tz="Asia/Kolkata").tz_convert("UTC")


def full(rows):
    """The main-period rows (each series also gets a 'recent' row for the same-period comparison)."""
    return [r for r in rows if r["window"] == "full"]


def test_run_downloads_in_chunks_and_returns_one_row_per_security_and_timeframe():
    names = [f"S{i}.NS" for i in range(5)]
    insts = [inst(s, s[:-3], tfs=("1d", "1w")) for s in names]
    calls, saved = [], []
    cfg = fcfg(chunk_symbols=2)
    rows = bt.run_backtest(cfg, insts, NOW, fake_fetcher(make_data(names), calls), 3.0, ["1d", "1w"],
                           on_chunk=lambda r: saved.append(len(r)))
    assert [len(c[0]) for c in calls] == [2, 2, 1] and {c[1] for c in calls} == {"1d"}      # 1d and 1w share one download
    assert len(full(rows)) == 10 and {r["status"] for r in rows} == {"ok"}
    assert len(rows) == 20 and saved == [8, 16, 20]                                      # progress is saved after every chunk
    assert {r["timeframe"] for r in rows} == {"1d", "1w"}


def test_missing_data_and_unused_timeframes_are_reported_per_row():
    insts = [inst("A.NS", "A", tfs=("1d",)), inst("GONE.NS", "GONE", tfs=("1d", "1w"))]
    rows = bt.run_backtest(fcfg(), insts, NOW, fake_fetcher(make_data(["A.NS"])), 3.0, ["1d", "1w"])
    by = {(r["symbol"], r["timeframe"]): r["status"] for r in full(rows)}
    assert by == {("A.NS", "1d"): "ok", ("GONE.NS", "1d"): "no data from the data feed",
                  ("GONE.NS", "1w"): "no data from the data feed"}


def test_each_market_uses_its_own_cost():
    cfg = fcfg()
    cfg["backtest"]["cost_pct_per_side"] = {"NSE": 0.0, "US": 0.5}
    insts = [inst("A.NS", "A", tfs=("1d",)), inst("A", "A", market="US", tfs=("1d",))]
    raw = {("A.NS", "1d"): daily_raw("NSE", FRI, 900, lambda n: walk(9, n)),
           ("A", "1d"): daily_raw("US", FRI, 900, lambda n: walk(9, n))}
    rows = {r["market"]: r for r in full(bt.run_backtest(cfg, insts, NOW, fake_fetcher(raw), 3.0, ["1d"]))}
    assert rows["NSE"]["gross_avg_trade_pct"] == pytest.approx(rows["NSE"]["avg_trade_pct"])        # no cost on NSE
    assert rows["US"]["avg_trade_pct"] < rows["US"]["gross_avg_trade_pct"] - 0.9                    # 2 x 0.5% on US


def test_a_failing_chunk_does_not_stop_the_run():
    names = [f"S{i}.NS" for i in range(4)]
    insts = [inst(s, s[:-3], tfs=("1d",)) for s in names]
    good = fake_fetcher(make_data(names))
    state = {"n": 0}

    def flaky(symbols, interval):
        state["n"] += 1
        if state["n"] == 2:
            raise RuntimeError("boom")
        return good(symbols, interval)

    rows = bt.run_backtest(fcfg(chunk_symbols=2), insts, NOW, flaky, 3.0, ["1d"])
    status = {r["symbol"]: r["status"] for r in full(rows)}
    assert status["S0.NS"] == status["S1.NS"] == "ok" and status["S2.NS"] == status["S3.NS"] == "error: boom"


def test_time_limit_stops_new_chunks_and_says_so():
    names = [f"S{i}.NS" for i in range(6)]
    insts = [inst(s, s[:-3], tfs=("1d",)) for s in names]
    clock = SimpleNamespace(t=0.0)
    rows = bt.run_backtest(fcfg(chunk_symbols=2, max_minutes=30), insts, NOW,
                           fake_fetcher(make_data(names), slow=lambda: setattr(clock, "t", clock.t + 3600)),
                           3.0, ["1d"], clock=lambda: clock.t)
    status = [r["status"] for r in full(rows)]
    assert status[:2] == ["ok", "ok"] and set(status[2:]) == {"not tested: the time limit was reached"}


def test_tradingview_is_given_another_chance_during_a_long_run():
    names = [f"S{i}.NS" for i in range(6)]
    insts = [inst(s, s[:-3], tfs=("1d",)) for s in names]
    tv = SimpleNamespace(down="no answer from TradingView", _streak=3)
    inner = fake_fetcher(make_data(names))

    def fetch(symbols, interval):
        tv.down = "no answer from TradingView"            # it keeps going quiet
        return inner(symbols, interval)

    fetch.tv = tv
    naps = []
    bt.run_backtest(fcfg(chunk_symbols=1), insts, NOW, fetch, 3.0, ["1d"], sleep=naps.append)
    assert naps == [90, 90, 90, 90]                       # at most four rests, then it carries on without


def test_hourly_history_is_extended_from_yahoo_only_where_that_reaches_further():
    cfg = fcfg()
    cfg["data_source"] = "auto"

    def hourly(years):
        idx = pd.date_range("2024-01-01", periods=int(24 * 365.25 * years), freq="1h", tz="UTC")
        return pd.DataFrame({"close": 1.0}, index=idx)

    asked = []
    long_, short_ = hourly(2.0), hourly(0.55)

    class Feed:
        def _yahoo_fetch(self, symbols, interval):
            asked.append((list(symbols), interval))
            return {"BTC-USD": long_, "ETH-USD": hourly(0.6)}, []

    data = {"BTC-USD": short_, "ETH-USD": short_, "AAA.NS": hourly(2.8), "MCX:X1!": short_}
    out = bt.deepen(Feed(), cfg, list(data), data)
    assert asked == [(["BTC-USD", "ETH-USD"], "1h")]       # not the 2.8-year stock, not the TradingView-only name
    assert out["BTC-USD"] is long_ and out["ETH-USD"] is short_ and out["MCX:X1!"] is short_

    cfg["data_source"] = "tradingview"
    asked.clear()
    assert bt.deepen(Feed(), cfg, list(data), data) is data and asked == []
    cfg["data_source"] = "auto"
    cfg["backtest"]["extend_with_yahoo"] = False
    assert bt.deepen(Feed(), cfg, list(data), data) is data and asked == []


def test_yahoo_trouble_during_the_extension_is_harmless():
    cfg = fcfg()
    cfg["data_source"] = "auto"
    idx = pd.date_range("2024-01-01", periods=2000, freq="1h", tz="UTC")
    data = {"BTC-USD": pd.DataFrame({"close": 1.0}, index=idx)}

    class Feed:
        def _yahoo_fetch(self, symbols, interval):
            raise RuntimeError("429 Too Many Requests")

    assert bt.deepen(Feed(), cfg, ["BTC-USD"], data) is data


def test_period_text_and_limit_helpers():
    assert bt.period_years("730d") == pytest.approx(2.0, abs=0.01) and bt.period_years("720d") < 2.0
    assert bt.period_years("5y") == 5.0 and bt.period_years("6mo") == 0.5 and bt.period_years("max") == 0.0
    cfg = load_config()
    insts = [inst(f"S{i}.NS", f"S{i}") for i in range(5)] + [inst("BTC-USD", "Bitcoin", "CRYPTO", unis=("crypto",))]
    kept = bt.limit_instruments(insts, cfg, 2)
    assert [i.symbol for i in kept] == ["S0.NS", "S1.NS", "BTC-USD"]


# ----------------------------------------------------------------------------------------------- reports
def row(symbol, tf, cagr=10.0, trades=20, years=3.0, status="ok", bh=5.0, pf=1.5, uni="nifty500", **kw):
    base = {"symbol": symbol, "display": symbol.replace(".NS", ""), "name": symbol, "market": "NSE", "universes": uni,
            "timeframe": tf, "status": status}
    if status == "ok":
        wins = int(trades * 0.5)
        base.update({"years": years, "bars": 500, "trades": trades, "wins": wins, "win_rate_pct": 50.0,
                     "avg_trade_pct": 0.5, "gross_avg_trade_pct": 0.6, "pos_sum_pct": 20.0, "neg_sum_pct": -10.0,
                     "profit_factor": pf, "total_return_pct": cagr * years, "cagr_pct": cagr, "max_dd_pct": -15.0,
                     "bh_return_pct": bh * years, "bh_cagr_pct": bh, "bh_max_dd_pct": -25.0, "exposure_pct": 40.0,
                     "avg_bars_held": 10.0, "open_trade": False, "window_from": "2023-11-01", "window_to": "2026-10-30"})
    base.update(kw)
    return base


BT = {"min_trades": 3, "min_years": 0.5}


def test_best_timeframe_needs_enough_trades_and_history():
    rows = [row("A.NS", "15m", cagr=50, years=0.8, trades=200), row("A.NS", "1h", cagr=20, years=2.8),
            row("A.NS", "4h", status="no data from the data feed"),
            row("A.NS", "1d", cagr=10), row("A.NS", "1w", cagr=80, trades=2),                 # too few trades
            row("B.NS", "15m", cagr=900, years=0.14, trades=300), row("B.NS", "1d", cagr=4, trades=1),
            row("C.NS", "1d", status="no data from the data feed")]
    best = rep.best_per_security(rep.results_frame(rows), BT).set_index("symbol")
    a = best.loc["A.NS"]
    assert a["best_timeframe"] == "15m" and a["best_cagr_pct"] == 50 and "under 1 year of data" in a["flags"]
    assert a["cagr_1h"] == 20 and a["cagr_1w"] == 80 and pd.isna(a["cagr_4h"]) and a["trades_1w"] == 2
    assert best.loc["B.NS", "best_timeframe"] == "" and "too few trades" in best.loc["B.NS", "flags"]
    assert best.loc["C.NS", "best_timeframe"] == "" and best.loc["C.NS", "flags"] == "no data"


def test_flags_say_when_the_best_still_lost_money_or_lost_to_buy_and_hold():
    rows = [row("L.NS", "1h", cagr=-5, bh=3), row("L.NS", "1d", cagr=-2, bh=3),
            row("H.NS", "1d", cagr=4, bh=12, trades=5), row("H.NS", "1w", cagr=2, bh=12, trades=4)]
    best = rep.best_per_security(rep.results_frame(rows), BT).set_index("symbol")
    assert best.loc["L.NS", "best_timeframe"] == "1d" and "lost money on every timeframe" in best.loc["L.NS", "flags"]
    assert best.loc["H.NS", "best_timeframe"] == "1d"
    assert "buy & hold did better" in best.loc["H.NS", "flags"] and "few trades" in best.loc["H.NS", "flags"]


def test_ties_go_to_the_better_profit_factor():
    rows = [row("T.NS", "1h", cagr=10, pf=1.2), row("T.NS", "1d", cagr=10, pf=2.0)]
    assert rep.best_per_security(rep.results_frame(rows), BT).iloc[0]["best_timeframe"] == "1d"


def test_group_numbers_pool_all_trades_and_use_medians_across_securities():
    rows = []
    for k, cagr in enumerate((30, 10, -10)):
        rows += [row(f"S{k}.NS", "1d", cagr=cagr, bh=8, trades=10), row(f"S{k}.NS", "1h", cagr=cagr - 20, bh=8, trades=40)]
    df = rep.results_frame(rows)
    bests = rep.best_per_security(df, BT)
    st = rep.group_stats(df, bests, ["15m", "1h", "1d"])
    assert st["15m"] is None
    d = st["1d"]
    assert d["symbols"] == 3 and d["trades_total"] == 30 and d["ret_med"] == 10 and d["bh_ret_med"] == 8
    assert d["win_rate"] == pytest.approx(50.0) and d["avg_trade"] == pytest.approx(30.0 / 30 * 1.0)
    assert d["profit_factor"] == pytest.approx(60.0 / 30.0)
    assert d["profitable"] == pytest.approx(200 / 3) and d["beat_bh"] == pytest.approx(200 / 3)
    assert d["best_for"] == 3 and st["1h"]["best_for"] == 0
    assert rep.group_best(st, BT) == "1d"


def test_group_best_ignores_timeframes_without_history_or_trades():
    base = {"ret_med": 5.0, "years": 3.0, "trades_total": 300}
    stats = {"15m": {**base, "ret_med": 90.0, "years": 0.2}, "1h": {**base, "ret_med": 70.0, "trades_total": 12},
             "1d": base, "1w": None}
    assert rep.group_best(stats, {"min_years": 1.0}) == "1d"
    assert rep.group_best(stats, {"min_years": 1.0}, recent=True) == "15m"            # same period: history is equal by design
    assert rep.group_best({"1d": None}, BT) is None


def test_verdict_wording():
    def stats(c, b, dd=-10.0, bdd=-30.0):
        return {"1d": {"ret_med": c, "bh_ret_med": b, "dd_med": dd, "bh_dd_med": bdd}}
    assert "beat buy & hold" in rep.verdict(stats(12, 8), "1d")
    v = rep.verdict(stats(5, 14), "1d")
    assert "made money" in v and "buy & hold made more" in v and "smaller worst drop (10% vs 30%)" in v
    assert "worst drop" not in rep.verdict(stats(5, 14, dd=-40.0), "1d")
    assert "lost money after costs" in rep.verdict(stats(-3, 8), "1d")
    assert "not enough" in rep.verdict({}, None)
    assert "(+12% vs +8%)" in rep.verdict(stats(12, 8), "1d", recent=True) and "a year" not in rep.verdict(stats(12, 8), "1d", True)


def test_summary_and_markdown_read_well():
    cfg = load_config()
    insts = [inst(f"S{k}.NS", f"S{k}") for k in range(3)]
    rows = []
    for k in range(3):
        for tf, cagr, yrs in (("15m", 40, 0.8), ("1h", 5, 2.8), ("1d", 12 + k, 3.0), ("1w", 6, 3.0)):
            rows.append(row(f"S{k}.NS", tf, cagr=cagr, years=yrs, trades=8 if tf == "1w" else 30))
    rows.append(row("S2.NS", "4h", status="only 30 closed candles (need 80)"))
    df = rep.results_frame(rows)
    bests = rep.best_per_security(df, cfg["backtest"])
    groups = rep.analyse(df, bests, insts, cfg, list(ALL_TFS))
    now = pd.Timestamp("2026-11-02 10:00", tz="UTC")
    md = rep.build_markdown(df, bests, groups, insts, cfg, now, 3.0, list(ALL_TFS), skipped=1)
    for needle in ("# EMA 10/20 Crossover – Backtest", "## 1. The short answer", "## 2. Each group in detail",
                   "## 3. Best timeframe for each security", "## 4. How to read this", "## 5. What could not be tested",
                   "Nifty 500", "S0", "S1", "S2", "only 30 closed candles", "NSE 0.05%"):
        assert needle in md, needle
    assert "40% ⚠" in md or "+40% ⚠" in md                                  # a short-history number is marked
    text = rep.summary_text(groups, cfg, now, 3.0, list(ALL_TFS), skipped=1)
    assert text.startswith("🧪") and "Nifty 500" in text and "best <b>" in text and "⚠" in text and len(text) < 3900


def test_summary_text_is_cut_to_fit_telegram():
    cfg = load_config()
    st = {"1d": {"ret_med": 5.0, "bh_ret_med": 6.0, "years": 3.0, "dd_med": -10, "bh_dd_med": -20}}
    groups = [{"label": f"Group {i} " + "x" * 60, "tested": 10, "stats": st, "best": "1d", "recent_stats": st,
               "recent_best": "1d"} for i in range(80)]
    text = rep.summary_text(groups, cfg, pd.Timestamp("2026-11-02", tz="UTC"), 3.0, ["1d"], 0)
    assert len(text) <= 3900 and text.endswith("…")


def test_files_are_written(tmp_path):
    df = rep.results_frame([row("A.NS", "1d", cagr=3.14159)])
    bests = rep.best_per_security(df, BT)
    paths = rep.write_files(tmp_path / "bt", "# hi", df, bests, "2026-11-02")
    assert paths["md"].read_text(encoding="utf-8") == "# hi"
    assert (tmp_path / "bt" / "archive" / "2026-11-02.md").exists()
    back = pd.read_csv(paths["results"])
    assert back.loc[0, "cagr_pct"] == pytest.approx(3.1416) and "_trades" not in back.columns
    assert pd.read_csv(paths["best"]).loc[0, "best_timeframe"] == "1d"


# ------------------------------------------------------------------------------------------- the command
class Resp:
    def __init__(self, status, body):
        self.status_code, self._body = status, body

    def json(self):
        return self._body


@pytest.fixture
def cmd_env(tmp_path, monkeypatch):
    cfg = load_config()
    cfg["data_source"] = "yahoo"
    cfg["backtest"]["chunk_symbols"] = 2
    monkeypatch.setattr(cli, "load_config", lambda path=None: cfg)
    monkeypatch.setattr(cli, "ROOT", tmp_path)
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "123:SECRET")
    monkeypatch.setenv("TELEGRAM_CHAT_ID", "42")
    monkeypatch.setattr("time.sleep", lambda s: None)
    box = {"messages": [], "docs": [], "fail": False}

    def fake_post(url, json=None, data=None, files=None, timeout=None):
        if box["fail"]:
            return Resp(400, {"ok": False, "description": "Bad Request: chat not found"})
        if url.endswith("sendMessage"):
            box["messages"].append(json["text"])
        elif url.endswith("sendDocument"):
            box["docs"].append(data["caption"])
        return Resp(200, {"ok": True, "result": {}})

    monkeypatch.setattr(telegram.requests, "post", fake_post)
    insts = [inst("AAA.NS", "AAA"), inst("BBB.NS", "BBB"), inst("ZZZ.NS", "ZZZ"),
             inst("^NSEI", "Nifty 50", unis=("indian_indices",), tfs=("1d", "1w")),
             inst("BTC-USD", "Bitcoin", market="CRYPTO", unis=("crypto",))]
    raw = {}
    for k, s in enumerate(("AAA.NS", "BBB.NS", "^NSEI")):
        raw[(s, "15m")] = intraday_raw("NSE", 15, FRI, 30, lambda n, k=k: walk(k, n, vol=0.002))
        raw[(s, "1h")] = intraday_raw("NSE", 60, FRI, 120, lambda n, k=k: walk(10 + k, n, vol=0.004))
        raw[(s, "1d")] = daily_raw("NSE", FRI, 900, lambda n, k=k: walk(20 + k, n))
    raw[("BTC-USD", "15m")] = intraday_raw("CRYPTO", 15, date(2026, 10, 31), 20, lambda n: walk(31, n, vol=0.002))
    raw[("BTC-USD", "1h")] = intraday_raw("CRYPTO", 60, date(2026, 10, 31), 70, lambda n: walk(32, n, vol=0.004))
    raw[("BTC-USD", "1d")] = daily_raw("CRYPTO", date(2026, 10, 31), 900, lambda n: walk(33, n, vol=0.02))
    monkeypatch.setattr(cli, "build", lambda c, only=None, **kw: (list(insts), {"nifty500": "3 symbols (test)"}))
    monkeypatch.setattr(cli, "make_fetcher", lambda c, i=None, **kw: fake_fetcher(raw))
    return {"cfg": cfg, "box": box, "out": tmp_path / "reports" / "backtest", "insts": insts}


NOW_ARG = "2026-11-01T00:00:00"


def test_backtest_command_writes_reports_and_sends_digest_and_files(cmd_env):
    assert cli.main(["backtest", "--now", NOW_ARG]) == 0
    out, box = cmd_env["out"], cmd_env["box"]
    assert {p.name for p in out.iterdir()} == {"latest.md", "results.csv", "best_by_security.csv", "archive"}
    res_all = pd.read_csv(out / "results.csv")
    res = res_all[res_all["window"] == "full"]
    assert len(res) == 5 + 5 + 5 + 2 + 5                                  # security x timeframe
    recent = res_all[res_all["window"] == "recent"]
    assert len(recent) > 0 and set(recent["status"]) == {"ok"} and set(recent["timeframe"]) >= {"1d"}
    assert set(res[res["symbol"] == "ZZZ.NS"]["status"]) == {"no data from the data feed"}
    assert set(res[res["symbol"] == "AAA.NS"]["status"]) == {"ok"}
    best = pd.read_csv(out / "best_by_security.csv")
    assert set(best["symbol"]) == {"AAA.NS", "BBB.NS", "ZZZ.NS", "^NSEI", "BTC-USD"}
    assert best.set_index("symbol").loc["ZZZ.NS", "flags"] == "no data"
    md = (out / "latest.md").read_text(encoding="utf-8")
    assert cmd_env["cfg"]["universes"]["nifty500"]["label"] in md and "AAA" in md and "Bitcoin" in md or "BTC" in md
    assert box["messages"][-1].startswith("🧪") and len(box["docs"]) == 2
    assert "SECRET" not in md and "SECRET" not in box["messages"][-1]


def test_backtest_command_options(cmd_env, capsys):
    box = cmd_env["box"]
    assert cli.main(["backtest", "--now", NOW_ARG, "--no-telegram", "--limit", "1", "--years", "1.5"]) == 0
    assert box["messages"] == [] and box["docs"] == []
    res = pd.read_csv(cmd_env["out"] / "results.csv")
    assert set(res["symbol"]) == {"AAA.NS", "^NSEI", "BTC-USD"}            # first security of each group
    assert res[res["status"] == "ok"]["years"].max() <= 1.5
    assert "recent_years" in cmd_env["cfg"]["backtest"]
    assert cli.main(["backtest", "--now", NOW_ARG, "--dry-run", "--limit", "1"]) == 0
    assert "(dry run)" in capsys.readouterr().out and box["messages"] == []
    assert cli.main(["backtest", "--now", NOW_ARG, "--years", "abc"]) == 2
    assert cli.main(["backtest", "--now", NOW_ARG, "--years", "50"]) == 2


def test_backtest_command_failures_are_loud(cmd_env, monkeypatch):
    monkeypatch.delenv("TELEGRAM_BOT_TOKEN")
    assert cli.main(["backtest", "--now", NOW_ARG]) == 2                   # secrets missing
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "123:SECRET")
    cmd_env["box"]["fail"] = True
    assert cli.main(["backtest", "--now", NOW_ARG, "--limit", "1"]) == 1   # Telegram refuses: red run, files still written
    assert (cmd_env["out"] / "latest.md").exists()
    monkeypatch.setattr(cli, "build", lambda c, only=None, **kw: ([], {"x": "FAILED"}))
    cmd_env["box"]["fail"] = False
    assert cli.main(["backtest", "--now", NOW_ARG]) == 2


# ------------------------------------------------------------------------------------------------ config
def test_backtest_settings_have_safe_defaults_and_can_be_overridden(tmp_path):
    cfg = load_config()
    b = cfg["backtest"]
    assert b["years"] == 3 and b["recent_years"] == 0.5 and b["min_years"] == 1.0
    assert b["tradingview"]["bars"] == {"15m": 5000, "1h": 5000, "1d": 1500}
    assert b["cost_pct_per_side"]["CRYPTO"] > b["cost_pct_per_side"]["US"]
    f = bt.fetch_cfg(cfg)
    assert f["tradingview"]["bars"]["1h"] == 5000 and cfg["tradingview"]["bars"]["1h"] == 400    # scanner untouched
    assert f["yahoo"]["periods"]["1h"] == "720d" and cfg["yahoo"]["periods"]["1h"] == "90d"
    assert f["run_budget_seconds"] > b["max_minutes"] * 60
    p = tmp_path / "mine.yaml"
    p.write_text("backtest:\n  years: 2\n  cost_pct_per_side:\n    NSE: 0.1\nuniverses:\n"
                 "  crypto: {enabled: true, label: Crypto, market: CRYPTO, source: list, list: crypto}\n"
                 "lists:\n  crypto: [{symbol: BTC-USD, name: Bitcoin}]\n")
    mine = load_config(p)["backtest"]
    assert mine["years"] == 2 and mine["cost_pct_per_side"]["NSE"] == 0.1 and mine["cost_pct_per_side"]["US"] == 0.02


@pytest.mark.parametrize("text", ["years: 0", "years: 40", "years: soon", "timeframes: [2h]", "cost_pct_per_side: 0.1",
                                  "recent_years: 9", "recent_years: soon"])
def test_bad_backtest_settings_are_explained(tmp_path, text):
    p = tmp_path / "bad.yaml"
    p.write_text("backtest:\n  " + text + "\nuniverses:\n"
                 "  crypto: {enabled: true, label: Crypto, market: CRYPTO, source: list, list: crypto}\n"
                 "lists:\n  crypto: [{symbol: BTC-USD, name: Bitcoin}]\n")
    with pytest.raises(ConfigError, match="backtest"):
        load_config(p)


# ------------------------------------------------------------------------------------- the same-period window
def test_every_series_is_also_replayed_over_the_common_recent_period():
    cfg = fcfg()
    raw = daily_raw("NSE", FRI, 900, lambda n: walk(8, n))
    res = bt.backtest_series(raw, "NSE", "1d", cfg, NOW, 3.0, 0.0005)
    rec = res["_recent"]
    assert res["status"] == rec["status"] == "ok"
    assert 0.45 <= rec["years"] <= 0.5 and res["years"] > 2.9
    assert rec["window_to"] == res["window_to"] and rec["window_from"] > res["window_from"]
    # no recent view when it is switched off, when it is not shorter than the main one, or when the data cannot cover it
    off = fcfg(recent_years=0)
    assert "_recent" not in bt.backtest_series(raw, "NSE", "1d", off, NOW, 3.0, 0.0005)
    assert "_recent" not in bt.backtest_series(raw, "NSE", "1d", cfg, NOW, 0.4, 0.0005)
    thin = daily_raw("NSE", FRI, 130, lambda n: walk(8, n))                                  # about 0.27 years of candles
    assert "_recent" not in bt.backtest_series(thin, "NSE", "1d", cfg, NOW, 3.0, 0.0005)


def test_run_rows_carry_a_window_and_no_internal_lists():
    insts = [inst("A.NS", "A", tfs=("1d", "1w"))]
    rows = bt.run_backtest(fcfg(), insts, NOW, fake_fetcher(make_data(["A.NS"])), 3.0, ["1d", "1w"])
    assert sorted((r["timeframe"], r["window"]) for r in rows) == [("1d", "full"), ("1d", "recent"), ("1w", "full"), ("1w", "recent")]
    assert all(not k.startswith("_") for r in rows for k in r)
    full = next(r for r in rows if r["window"] == "full" and r["timeframe"] == "1d")
    recent = next(r for r in rows if r["window"] == "recent" and r["timeframe"] == "1d")
    assert recent["years"] < full["years"] and recent["trades"] <= full["trades"]
    skipped = bt.run_backtest(fcfg(), [inst("GONE.NS", "GONE", tfs=("1d",))], NOW, fake_fetcher({}), 3.0, ["1d"])
    assert [r["window"] for r in skipped] == ["full"]


def test_same_period_numbers_use_total_return_and_have_their_own_best():
    rows = []
    for k in range(3):
        rows += [row(f"S{k}.NS", "1d", cagr=10, years=3.0, trades=12),
                 row(f"S{k}.NS", "15m", cagr=80, years=0.8, trades=100),
                 row(f"S{k}.NS", "15m", cagr=0, years=0.5, trades=60, window="recent", total_return_pct=-6.0, bh_return_pct=4.0),
                 row(f"S{k}.NS", "1d", cagr=0, years=0.5, trades=4, window="recent", total_return_pct=3.0, bh_return_pct=4.0)]
    df = rep.results_frame(rows)
    bests = rep.best_per_security(df, {"min_trades": 3, "min_years": 1.0}).set_index("symbol")
    assert bests.loc["S0.NS", "best_timeframe"] == "1d"                      # 15m has under a year: shown, not ranked
    assert bests.loc["S0.NS", "cagr_15m"] == 80 and "under 1 year" not in bests.loc["S0.NS", "flags"]
    assert bests.loc["S0.NS", "recent_best_timeframe"] == "1d" and bests.loc["S0.NS", "recent_best_return_pct"] == 3.0
    assert bests.loc["S0.NS", "recent_15m"] == -6.0 and bests.loc["S0.NS", "recent_1d"] == 3.0
    sub = df
    st = rep.group_stats(sub, bests.reset_index(), ["15m", "1d"], recent=True)
    assert st["15m"]["ret_med"] == -6.0 and st["1d"]["ret_med"] == 3.0 and st["1d"]["bh_ret_med"] == 4.0
    assert st["1d"]["best_for"] == 3 and st["15m"]["best_for"] == 0
    full = rep.group_stats(sub, bests.reset_index(), ["15m", "1d"])
    assert full["15m"]["ret_med"] == 80 and full["1d"]["years"] == 3.0                # the full view ignores recent rows


def test_markdown_has_the_same_period_view_only_when_there_is_one():
    cfg = load_config()
    insts = [inst(f"S{k}.NS", f"S{k}") for k in range(3)]
    rows = []
    for k in range(3):
        rows += [row(f"S{k}.NS", "15m", cagr=80, years=0.8, trades=100), row(f"S{k}.NS", "1d", cagr=10, years=3.0, trades=12),
                 row(f"S{k}.NS", "15m", years=0.5, trades=60, window="recent", total_return_pct=-6.0, bh_return_pct=4.0),
                 row(f"S{k}.NS", "1d", years=0.5, trades=12, window="recent", total_return_pct=3.0, bh_return_pct=4.0)]
    now = pd.Timestamp("2026-11-02 10:00", tz="UTC")
    tfs = ["15m", "1d"]

    def render(df):
        bests = rep.best_per_security(df, cfg["backtest"])
        groups = rep.analyse(df, bests, insts, cfg, tfs)
        return rep.build_markdown(df, bests, groups, insts, cfg, now, 3.0, tfs, 0), rep.summary_text(groups, cfg, now, 3.0, tfs, 0)

    md, text = render(rep.results_frame(rows))
    assert "**A. Longest history" in md and "**B. Same period for every timeframe (the last 6 months)" in md
    assert "Last 6 months - best **1d**" in md and "Return over the period" in md
    assert "Last 6 months, same period: best <b>1d</b>" in text and "Longest history (3y max): best <b>1d</b>" in text
    md2, text2 = render(rep.results_frame([r for r in rows if r.get("window", "full") == "full"]))
    assert "**B. Same period" not in md2 and "same period" not in text2
