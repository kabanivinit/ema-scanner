import json
from datetime import date

import numpy as np
import pandas as pd
import pytest

from scanner import alerts, bars, cli, engine, report, telegram
from scanner.config import load_config
from scanner.markets import MARKETS
from scanner.universe import Instrument
from synth import daily_raw, first_cross, intraday_raw, uptrend, vshape

NSE = MARKETS["NSE"]
FRI = date(2026, 10, 30)


def plain(text):
    """What Telegram shows: the message without its HTML tags."""
    import re
    return re.sub(r"<[^>]+>", "", text).replace("&amp;", "&")


def inst(symbol, name, market="NSE", unis=("nifty500",), tfs=("15m",), cur="₹", tv=""):
    return Instrument(symbol=symbol, name=name, market=market, universes=list(unis), tv=tv or f"NSE:{name}",
                      currency=cur, tfs=set(tfs))


class FakeResp:
    def __init__(self, status, body):
        self.status_code, self._body = status, body

    def json(self):
        return self._body


@pytest.fixture
def env(tmp_path, monkeypatch):
    cfg = load_config()
    cfg["timeframes"] = ["15m"]
    cfg["data_source"] = "yahoo"          # no feed delay: these tests are about timing to the minute
    state_file = tmp_path / "state.json"
    monkeypatch.setenv("SCANNER_STATE", str(state_file))
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "123:SECRET")
    monkeypatch.setenv("TELEGRAM_CHAT_ID", "42")
    monkeypatch.setattr(cli, "PAUSE", 0)
    monkeypatch.setattr("time.sleep", lambda s: None)
    box = {"messages": [], "fail": False, "docs": []}

    def fake_post(url, json=None, data=None, files=None, timeout=None):
        if box["fail"]:
            return FakeResp(400, {"ok": False, "description": "Bad Request: chat not found"})
        if url.endswith("sendMessage"):
            box["messages"].append(json["text"])
        elif url.endswith("sendDocument"):
            box["docs"].append(data["caption"])
        return FakeResp(200, {"ok": True, "result": {"username": "testbot"}})

    monkeypatch.setattr(telegram.requests, "post", fake_post)
    monkeypatch.setattr(cli, "load_config", lambda path=None: cfg)

    # data: AAA has a bullish cross at bar k, BBB trends up, ^NSEI is the readiness benchmark
    n_probe = intraday_raw("NSE", 15, FRI, 30, lambda n: np.zeros(n)).shape[0]
    close_aaa = vshape(n_probe)
    k = first_cross(close_aaa)
    data = {
        "AAA.NS": intraday_raw("NSE", 15, FRI, 30, lambda n: close_aaa),
        "BBB.NS": intraday_raw("NSE", 15, FRI, 30, lambda n: uptrend(n)),
        "^NSEI": intraday_raw("NSE", 15, FRI, 30, lambda n: uptrend(n)),
    }
    calls = []

    def fetcher(symbols, interval):
        calls.append((tuple(symbols), interval))
        out = {s: data[s] for s in symbols if s in data and interval == "15m"}
        return out, [s for s in symbols if s not in out]

    monkeypatch.setattr(cli, "make_fetcher", lambda c, i=None, **kw: fetcher)
    insts = [inst("^NSEI", "Nifty 50", unis=("indian_indices",), cur=""), inst("AAA.NS", "AAA"), inst("BBB.NS", "BBB")]
    monkeypatch.setattr(cli, "build", lambda c, only=None, **kw: (insts, {"nifty500": "3 symbols (test)"}))
    ends = bars.intraday_bars(data["AAA.NS"], NSE, 15)["end"]
    return {"cfg": cfg, "box": box, "state": state_file, "k": k, "ends": ends, "calls": calls, "data": data,
            "insts": insts, "fetcher": fetcher}


def run(env, when):
    return cli.main(["scan", "--now", when.isoformat()])


def at(env, offset):
    return env["ends"].iloc[env["k"] + offset] + pd.Timedelta(minutes=2)


def test_first_run_is_silent_baseline_then_one_message_per_candle_and_no_duplicates(env):
    msgs = env["box"]["messages"]
    assert run(env, at(env, -6)) == 0
    assert len(msgs) == 1 and "scanner is live" in msgs[0]            # baseline only, no alert flood
    assert run(env, at(env, 0)) == 0
    assert len(msgs) == 2
    alert = plain(msgs[1])
    assert alert.startswith("⏱ 15 MIN") and "candle closed" in alert
    assert "15 Min Crossover in AAA, Bullish" in alert and "BBB" not in alert
    assert "1 crossover: 🟢 1 bullish" in alert and "Checked: Nifty 500 (2) · Indian Indices (1)" in alert
    assert run(env, at(env, 1)) == 0                                    # next candle: the cross is old news ...
    assert len(msgs) == 3 and "No crossovers in this candle" in msgs[2] and "AAA" not in msgs[2]   # ... but silence is announced
    saved = json.loads(env["state"].read_text())
    assert any(key.startswith("AAA.NS|15m|") for key in saved["sent"]["15m"])


def test_no_crossover_messages_can_be_switched_off_per_timeframe(env):
    env["cfg"]["alerts"]["empty_messages"] = []
    run(env, at(env, -6))
    run(env, at(env, -3))
    assert len(env["box"]["messages"]) == 1                             # nothing crossed, nothing said
    run(env, at(env, 0))
    assert len(env["box"]["messages"]) == 2 and "15 Min Crossover in AAA, Bullish" in plain(env["box"]["messages"][1])


def test_a_late_run_still_finds_the_crossover_and_names_its_candle(env):
    run(env, at(env, -6))
    run(env, at(env, 4))                                                # the run for the cross candle never happened
    alert = plain(env["box"]["messages"][-1])
    assert "15 Min Crossover in AAA, Bullish" in alert
    when = env["ends"].iloc[env["k"]].tz_convert("Asia/Kolkata").strftime("%d %b %H:%M")
    assert when in alert                                                # a line from an earlier candle says which one


def test_same_moment_twice_does_nothing_and_fetches_nothing(env):
    run(env, at(env, -6))
    run(env, at(env, 0))
    n_calls = len(env["calls"])
    run(env, at(env, 0))
    assert len(env["box"]["messages"]) == 2 and len(env["calls"]) == n_calls     # checkpoint skip


def test_forming_candle_is_never_used(env):
    run(env, at(env, -6))
    # one minute BEFORE the cross candle closes: no alert even though data already contains that candle
    run(env, env["ends"].iloc[env["k"]] - pd.Timedelta(minutes=1))
    assert len(env["box"]["messages"]) == 2 and "Crossover in AAA" not in env["box"]["messages"][1]
    assert "No crossovers in this candle" in env["box"]["messages"][1]


def test_memory_from_an_older_scanner_version_restarts_silently_once(env):
    # the alert memory exactly as the previous scanner version saved it: no "format" marker, old checkpoints, old alerts
    old = {"version": 1, "created": "2026-10-30T10:00:00+00:00", "health_last": 0,
           "checkpoints": {"NSE|15m": at(env, -40).isoformat()}, "sent": {"15m": {"AAA.NS|15m|1|bull": 1}}}
    env["state"].write_text(json.dumps(old))
    msgs = env["box"]["messages"]
    assert run(env, at(env, 0)) == 0
    assert len(msgs) == 1 and "scanner is live" in msgs[0]              # no burst of old alerts after the update
    saved = json.loads(env["state"].read_text())
    assert saved["format"] == 2 and saved["last_run"] == at(env, 0).isoformat()
    assert pd.Timestamp(saved["checkpoints"]["NSE|15m"]) == env["ends"].iloc[env["k"]]
    assert "AAA.NS|15m|1|bull" not in saved["sent"].get("15m", {})
    assert run(env, at(env, 1)) == 0                                    # from then on it behaves normally
    assert len(msgs) == 2 and "No crossovers in this candle" in msgs[1] and "not running" not in msgs[1]


def test_after_a_long_absence_the_message_says_what_was_skipped(env):
    run(env, at(env, -6))                                               # baseline
    run(env, at(env, 20))                                               # five hours later: the cross candle is far too old
    text = plain(env["box"]["messages"][-1])
    assert "Crossover in AAA" not in text and "No crossovers in this candle" in text
    when = at(env, -6).tz_convert("Asia/Kolkata").strftime("%d %b %H:%M IST")
    assert f"The scanner was not running from {when}." in text
    assert "more than 75 minutes before this message were not sent" in text


def test_runs_an_hour_apart_lose_nothing_and_carry_no_absence_note(env):
    for offset in (-6, -2, 2):                                          # each run 4 candles (one hour) after the previous
        run(env, at(env, offset))
    msgs = env["box"]["messages"]
    assert any("15 Min Crossover in AAA, Bullish" in plain(m) for m in msgs)    # the cross candle fell between two runs
    assert all("not running" not in plain(m) for m in msgs)


def test_outage_since_only_reports_absences_longer_than_the_alert_age_limit():
    cfg = load_config()
    now = pd.Timestamp("2026-11-03 10:00", tz="UTC")
    ago = lambda **kw: now - pd.Timedelta(**kw)
    assert engine.outage_since(cfg, "15m", ago(minutes=60).isoformat(), now) is None
    assert engine.outage_since(cfg, "15m", ago(minutes=80).isoformat(), now) == ago(minutes=80)
    assert engine.outage_since(cfg, "1h", ago(hours=4).isoformat(), now) is None
    assert engine.outage_since(cfg, "1h", ago(hours=6).isoformat(), now) == ago(hours=6)
    assert engine.outage_since(cfg, "1d", ago(days=2).isoformat(), now) is None
    assert engine.outage_since(cfg, "1d", ago(days=4).isoformat(), now) == ago(days=4)
    assert engine.outage_since(cfg, "15m", None, now) is None and engine.outage_since(cfg, "15m", "garbage", now) is None
    naive = ago(hours=3).tz_convert(None).isoformat()                    # a time without a zone counts as UTC
    assert engine.outage_since(cfg, "15m", naive, now) == ago(hours=3)


def test_state_files_are_recognised_by_their_format_marker(tmp_path):
    from scanner.state import STATE_FORMAT, load_state
    p = tmp_path / "s.json"
    p.write_text(json.dumps({"created": "2026-10-30T10:00:00+00:00", "checkpoints": {"a": "b"}}))
    assert load_state(p)["format"] == 0 and load_state(p)["created"] is not None      # saved by an older scanner
    p.write_text(json.dumps({"format": STATE_FORMAT, "created": "x"}))
    assert load_state(p)["format"] == STATE_FORMAT
    p.write_text("[1, 2, 3]")                                                           # not a state file at all
    assert load_state(p)["created"] is None and load_state(p)["format"] == STATE_FORMAT
    assert load_state(tmp_path / "missing.json")["format"] == STATE_FORMAT


def test_failed_telegram_does_not_lose_the_alert(env):
    run(env, at(env, -6))
    env["box"]["fail"] = True
    assert run(env, at(env, 0)) == 1                                   # red run so the owner notices
    env["box"]["fail"] = False
    assert run(env, at(env, 0)) == 0                                   # same moment: retried, not skipped
    assert any("15 Min Crossover in AAA, Bullish" in plain(m) for m in env["box"]["messages"])
    n = len(env["box"]["messages"])
    run(env, at(env, 0))
    assert len(env["box"]["messages"]) == n


def test_failed_no_crossover_message_is_retried_too(env):
    run(env, at(env, -6))
    env["box"]["fail"] = True
    assert run(env, at(env, -3)) == 1
    env["box"]["fail"] = False
    assert run(env, at(env, -3)) == 0
    assert "No crossovers in this candle" in env["box"]["messages"][-1]
    n = len(env["box"]["messages"])
    assert run(env, at(env, -3)) == 0 and len(env["box"]["messages"]) == n


def test_low_data_coverage_pauses_checkpoint_and_warns(env, monkeypatch):
    run(env, at(env, -6))
    full = env["fetcher"]

    def thin(symbols, interval):
        out, failed = full(symbols, interval)
        out = {s: v for s, v in out.items() if s in ("^NSEI",)}
        return out, [s for s in symbols if s not in out]

    monkeypatch.setattr(cli, "make_fetcher", lambda c, i=None, **kw: thin)
    run(env, at(env, 0))
    assert any("data problem" in m.lower() for m in env["box"]["messages"][1:])
    saved = json.loads(env["state"].read_text())
    assert saved["checkpoints"]["NSE|15m"] != at(env, 0).isoformat()   # not advanced -> retried later


def test_not_ready_benchmark_skips_the_whole_market(env):
    run(env, at(env, -6))
    env["calls"].clear()
    monday_open = pd.Timestamp("2026-11-02 09:32", tz="Asia/Kolkata").tz_convert("UTC")
    run(env, monday_open)                                               # data ends Friday -> not ready yet
    assert all(c[0] == ("^NSEI",) for c in env["calls"])               # only the 1-symbol probe was made
    assert len(env["box"]["messages"]) == 1


def test_missing_telegram_secrets_fail_loudly(env, monkeypatch):
    monkeypatch.delenv("TELEGRAM_BOT_TOKEN")
    assert run(env, at(env, 0)) == 2


def test_dry_run_prints_and_saves_nothing(env, capsys):
    cli.main(["scan", "--dry-run", "--now", at(env, 0).isoformat()])
    assert "(dry run)" in capsys.readouterr().out
    assert not env["state"].exists() and env["box"]["messages"] == []


def test_test_telegram_command(env):
    assert cli.main(["test-telegram"]) == 0
    assert "Telegram connected" in env["box"]["messages"][-1]
    env["box"]["fail"] = True
    assert cli.main(["test-telegram"]) == 1


# --------------------------------------------------------------------- all timeframes, all markets
def _multi_data(market, end):
    m = MARKETS[market]
    if market == "CRYPTO":
        return {"15m": intraday_raw(market, 15, end, 20, lambda n: vshape(n)),
                "1h": intraday_raw(market, 60, end, 60, lambda n: vshape(n)),
                "1d": daily_raw(market, end, 900, lambda n: vshape(n))}
    return {"15m": intraday_raw(market, 15, end, 30, lambda n: vshape(n)),
            "1h": intraday_raw(market, 60, end, 90, lambda n: vshape(n)),
            "1d": daily_raw(market, end, 800, lambda n: vshape(n))}


@pytest.mark.parametrize("market,sym,now", [
    ("NSE", "XYZ.NS", "2026-10-30 16:10"),
    ("US", "XYZ", "2026-10-30 21:00"),
    ("CRYPTO", "XYZ-USD", "2026-10-31 19:40"),
    ("FUT", "XY=F", "2026-10-30 23:00"),
    ("MCX", "MCX:XY1!", "2026-10-31 00:40"),
])
def test_every_market_and_timeframe_evaluates(market, sym, now):
    cfg = load_config()
    tz = {"NSE": "Asia/Kolkata", "US": "Asia/Kolkata", "CRYPTO": "UTC", "FUT": "Asia/Kolkata", "MCX": "Asia/Kolkata"}[market]
    t = pd.Timestamp(now, tz=tz).tz_convert("UTC")
    end = {"NSE": FRI, "US": FRI, "CRYPTO": date(2026, 10, 31), "FUT": FRI, "MCX": FRI}[market]
    raw = _multi_data(market, end)
    i = inst(sym, "XYZ", market=market, tfs=("15m", "1h", "4h", "1d", "1w"))
    fetch = lambda syms, itv: ({s: raw[itv] for s in syms}, [])
    coll = engine.collect(cfg, [i], {market: ["15m", "1h", "4h", "1d", "1w"]}, t, fetch)
    assert len(coll.results) == 5
    for r in coll.results:
        assert r.summary is not None, (market, r.tf, r.reason)
        assert r.summary["last_end"] <= t
        assert r.summary["bars"] >= 60


def test_report_and_digest_from_collected_results():
    cfg = load_config()
    cfg["timeframes"] = ["15m", "1d"]
    now = pd.Timestamp("2026-10-30 16:10", tz="Asia/Kolkata").tz_convert("UTC")
    raw = _multi_data("NSE", FRI)
    insts = [inst("XYZ.NS", "XYZ", tfs=("15m", "1d")), inst("MISSING.NS", "MISSING", tfs=("15m", "1d"))]

    def fetch(syms, itv):
        out = {s: raw[itv] for s in syms if s == "XYZ.NS"}
        return out, [s for s in syms if s not in out]

    coll = engine.collect(cfg, insts, {"NSE": ["15m", "1d"]}, now, fetch)
    md, df = report.build_report(coll, insts, cfg, now, {"nifty500": "2 symbols (test)"})
    assert "# EMA 10/20 Crossover Report" in md and "Market breadth" in md and "Data coverage" in md
    assert "MISSING" in md                                              # listed under 'No data'
    assert len(df) == 4 and set(df["state"]) <= {"bull", "bear", "flat", "n/a"}
    assert report.summary_text(coll, cfg, now, {}).startswith("📊")


def test_report_command_writes_files_and_sends_summary_and_documents(env, tmp_path, monkeypatch):
    monkeypatch.setattr(cli, "ROOT", tmp_path)
    assert cli.main(["report", "--now", at(env, 0).isoformat()]) == 0
    out = tmp_path / "reports"
    assert (out / "latest.md").exists() and (out / "latest.csv").exists()
    assert len(list((out / "archive").glob("*.md"))) == 1
    md = (out / "latest.md").read_text(encoding="utf-8")
    assert "AAA" in md and "Bullish" in md                              # the fresh bullish cross is listed
    assert len(pd.read_csv(out / "latest.csv")) == 3                    # 3 symbols x 1 timeframe
    assert env["box"]["messages"][-1].startswith("📊") and len(env["box"]["docs"]) == 2
    assert cli.main(["report", "--no-telegram", "--now", at(env, 0).isoformat()]) == 0


# ---- Fyers' free plan: the slow Indian round must not hold back crypto / US alerts -----------------------------------
from types import SimpleNamespace


def crypto_cross_at(end_ts, days=60):
    """24x7 crypto candles with a bullish cross exactly on the candle that ends at `end_ts`."""
    probe = intraday_raw("CRYPTO", 15, FRI, days, lambda n: np.zeros(n))
    ends = bars.intraday_bars(probe, MARKETS["CRYPTO"], 15)["end"]
    target = int(np.flatnonzero((ends == end_ts).to_numpy())[0])
    n = len(probe)
    for turn in range(target - 40, target):
        closes = np.concatenate([np.linspace(100, 80, turn), np.linspace(80, 120, n - turn)])
        if first_cross(closes) == target:
            return intraday_raw("CRYPTO", 15, FRI, days, lambda m: closes)
    raise AssertionError("could not build the test series")


@pytest.fixture
def split(env, monkeypatch):
    t = env["ends"].iloc[env["k"]]
    btc = inst("BTC-USD", "Bitcoin", market="CRYPTO", unis=("crypto",), cur="$", tv="BINANCE:BTCUSDT")
    insts = env["insts"] + [btc]
    monkeypatch.setattr(cli, "build", lambda c, only=None, **kw: (insts, {"nifty500": "3 symbols", "crypto": "1 symbols"}))
    data = dict(env["data"], **{"BTC-USD": crypto_cross_at(t)})
    seen = []

    class Slow:                                           # looks like the real fetcher on Fyers' free plan
        fy = SimpleNamespace(plan="standard", skip={"15m"})
        boom = False

        def __call__(self, symbols, interval):
            indian = any(s.endswith(".NS") or s == "^NSEI" for s in symbols)
            if indian:
                seen.append(len(env["box"]["messages"]))        # messages already out when the Indian round starts
                if self.boom:
                    raise RuntimeError("Fyers went away")
            out = {s: data[s] for s in symbols if s in data and interval == "15m"}
            return out, [s for s in symbols if s not in out]

    f = Slow()
    monkeypatch.setattr(cli, "make_fetcher", lambda c, i=None, **kw: f)
    return {"f": f, "seen": seen}


def test_on_the_free_plan_crypto_is_announced_before_the_slow_indian_round_starts(env, split):
    msgs = env["box"]["messages"]
    run(env, at(env, -6))
    assert len(msgs) == 1                                               # silent baseline: only "scanner is live"
    split["seen"].clear()
    assert run(env, at(env, 0)) == 0
    assert len(msgs) == 3
    assert "15 Min Crossover in Bitcoin, Bullish" in plain(msgs[1]) and "Checked: Crypto (1)" in plain(msgs[1])
    assert "15 Min Crossover in AAA, Bullish" in plain(msgs[2]) and "Bitcoin" not in plain(msgs[2])
    assert split["seen"] and min(split["seen"]) == 2                    # the Indian round began after the crypto message went out


def test_a_slow_group_that_fails_does_not_lose_or_repeat_the_fast_groups_alert(env, split):
    msgs = env["box"]["messages"]
    run(env, at(env, -6))
    split["f"].boom = True
    with pytest.raises(RuntimeError):
        run(env, at(env, 0))
    assert len(msgs) == 2 and "Crossover in Bitcoin, Bullish" in plain(msgs[1])          # crypto got out before the crash
    saved = json.loads(env["state"].read_text())
    t = env["ends"].iloc[env["k"]]
    assert pd.Timestamp(saved["checkpoints"]["CRYPTO|15m"]) == t         # the fast group's progress was saved ...
    assert pd.Timestamp(saved["checkpoints"]["NSE|15m"]) < t              # ... the failed group's was not moved on
    split["f"].boom = False
    assert run(env, at(env, 0)) == 0
    assert len(msgs) == 3 and "Crossover in AAA, Bullish" in plain(msgs[2])
    assert sum("Bitcoin" in plain(m) for m in msgs) == 1                # Bitcoin is not announced a second time


def test_everything_is_one_message_per_timeframe_when_nothing_is_slow(env, monkeypatch, split):
    split["f"].fy = None                                                # no free-plan Fyers: one group, one message
    msgs = env["box"]["messages"]
    run(env, at(env, -6))
    assert run(env, at(env, 0)) == 0
    assert len(msgs) == 2
    text = plain(msgs[1])
    assert "Crossover in Bitcoin, Bullish" in text and "Crossover in AAA, Bullish" in text and text.count("⏱ 15 MIN") == 1
